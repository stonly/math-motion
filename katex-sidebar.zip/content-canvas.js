const P = {
  INIT: "CANVAS_FRAME_INIT",
  REQUEST_STATE: "CANVAS_FRAME_REQUEST_STATE",
  EXPORT_REQUEST: "CANVAS_FRAME_EXPORT_REQUEST",
  SET_MATHML: "CANVAS_FRAME_SET_MATHML",
  APPLY_OPERATION: "CANVAS_FRAME_APPLY_OPERATION",
  IMPORT_LATEX: "CANVAS_FRAME_IMPORT_LATEX",
  IMPORT_MATHML: "CANVAS_FRAME_IMPORT_MATHML",
  SET_FEEDBACK: "CANVAS_FRAME_SET_FEEDBACK",
  CLEAR: "CANVAS_FRAME_CLEAR",
  CLOSE: "CANVAS_FRAME_CLOSE",
  READY: "CANVAS_FRAME_READY",
  STATE_RESPONSE: "CANVAS_FRAME_STATE_RESPONSE",
  EXPORT_RESPONSE: "CANVAS_FRAME_EXPORT_RESPONSE",
  SNAPSHOT: "CANVAS_FRAME_SNAPSHOT",
  OPERATION_APPLIED: "CANVAS_FRAME_OPERATION_APPLIED",
  ACTION_PASTE_LATEX: "CANVAS_FRAME_ACTION_PASTE_LATEX",
  ACTION_PASTE_MATHML: "CANVAS_FRAME_ACTION_PASTE_MATHML",
  ACTION_COPY_IMAGE_PNG: "CANVAS_FRAME_ACTION_COPY_IMAGE_PNG",
  ACTION_PASTE_IMAGE_PNG: "CANVAS_FRAME_ACTION_PASTE_IMAGE_PNG",
  ACTION_PASTE_IMAGE_SVG: "CANVAS_FRAME_ACTION_PASTE_IMAGE_SVG",
  ACTION_CLEAR: "CANVAS_FRAME_ACTION_CLEAR",
  ACTION_CLOSE: "CANVAS_FRAME_ACTION_CLOSE",
  RENDER_STATUS: "CANVAS_FRAME_RENDER_STATUS"
};
function we(r) {
  return typeof r == "object" && r !== null;
}
function bn(r) {
  return r === "image-png" || r === "image-svg";
}
function yn(r) {
  return r === "foreign-object" || r === "mathjax-svg";
}
function pt(r) {
  return !(!we(r) || typeof r.open != "boolean" || typeof r.mathml != "string" || typeof r.latexExport != "string" || r.pasteMode !== "inline" && r.pasteMode !== "display" || r.exportFormat !== void 0 && r.exportFormat !== "latex" && r.exportFormat !== "mathml" && r.exportFormat !== "image-png" && r.exportFormat !== "image-svg" || r.lastFeedback !== void 0 && typeof r.lastFeedback != "string" || r.editorKind !== void 0 && r.editorKind !== "canvas-core" && r.editorKind !== "fallback" || r.directEditing !== void 0 && typeof r.directEditing != "boolean" || r.bootDiagnostics !== void 0 && (!we(r.bootDiagnostics) || typeof r.bootDiagnostics.ready != "boolean" || r.bootDiagnostics.bootId !== void 0 && typeof r.bootDiagnostics.bootId != "string" || r.bootDiagnostics.runtimeInstanceId !== void 0 && typeof r.bootDiagnostics.runtimeInstanceId != "string" || r.bootDiagnostics.openNoopReuse !== void 0 && typeof r.bootDiagnostics.openNoopReuse != "boolean" || r.bootDiagnostics.lastInsertRequestId !== void 0 && typeof r.bootDiagnostics.lastInsertRequestId != "string" || r.bootDiagnostics.lastInsertDispatch !== void 0 && r.bootDiagnostics.lastInsertDispatch !== "apply-operation" && r.bootDiagnostics.lastInsertDispatch !== "replace-selection" && r.bootDiagnostics.lastInsertDispatch !== "failed" || r.bootDiagnostics.lastFrameEvent !== void 0 && r.bootDiagnostics.lastFrameEvent !== "ready" && r.bootDiagnostics.lastFrameEvent !== "snapshot" && r.bootDiagnostics.lastFrameEvent !== "render-status" && r.bootDiagnostics.lastFrameEvent !== "operation-applied") || r.editorDiagnostics !== void 0 && (!we(r.editorDiagnostics) || typeof r.editorDiagnostics.mounted != "boolean" || typeof r.editorDiagnostics.focused != "boolean" || typeof r.editorDiagnostics.supportsDirectEditing != "boolean" || r.editorDiagnostics.lastInputEvent !== void 0 && r.editorDiagnostics.lastInputEvent !== "input" && r.editorDiagnostics.lastInputEvent !== "change" && r.editorDiagnostics.lastInputEvent !== "selection-change" || r.editorDiagnostics.selectionPath !== void 0 && typeof r.editorDiagnostics.selectionPath != "string" || r.editorDiagnostics.selectionOffset !== void 0 && typeof r.editorDiagnostics.selectionOffset != "number") || r.runtimeDiagnostics !== void 0 && (!we(r.runtimeDiagnostics) || typeof r.runtimeDiagnostics.instanceId != "string" || typeof r.runtimeDiagnostics.registered != "boolean" || typeof r.runtimeDiagnostics.reusedExistingInstance != "boolean") || r.notionDiagnostics !== void 0 && (!we(r.notionDiagnostics) || typeof r.notionDiagnostics.canvasSessionOpen != "boolean" || r.notionDiagnostics.lastMathContextEnteredAt !== void 0 && typeof r.notionDiagnostics.lastMathContextEnteredAt != "number" || r.notionDiagnostics.lastEditableFocusKind !== void 0 && typeof r.notionDiagnostics.lastEditableFocusKind != "string" || r.notionDiagnostics.targetNodeStable !== void 0 && typeof r.notionDiagnostics.targetNodeStable != "boolean" || r.notionDiagnostics.entryTargetKind !== void 0 && typeof r.notionDiagnostics.entryTargetKind != "string" || r.notionDiagnostics.selectionRestoreOk !== void 0 && typeof r.notionDiagnostics.selectionRestoreOk != "boolean" || r.notionDiagnostics.postReturnTargetKind !== void 0 && typeof r.notionDiagnostics.postReturnTargetKind != "string" || r.notionDiagnostics.slashInsertAttempted !== void 0 && typeof r.notionDiagnostics.slashInsertAttempted != "boolean" || r.notionDiagnostics.slashInsertRetried !== void 0 && typeof r.notionDiagnostics.slashInsertRetried != "boolean" || r.notionDiagnostics.menuItemFound !== void 0 && typeof r.notionDiagnostics.menuItemFound != "boolean" || r.notionDiagnostics.mathEditorOpened !== void 0 && typeof r.notionDiagnostics.mathEditorOpened != "boolean" || r.notionDiagnostics.lastEquationFailureStep !== void 0 && typeof r.notionDiagnostics.lastEquationFailureStep != "string"));
}
function xn(r) {
  if (!we(r) || typeof r.type != "string")
    return !1;
  switch (r.type) {
    case P.READY:
      return we(r.payload) && typeof r.payload.bootId == "string";
    case P.STATE_RESPONSE:
      return we(r.payload) && typeof r.payload.requestId == "string" && pt(r.payload.state);
    case P.EXPORT_RESPONSE:
      return we(r.payload) && typeof r.payload.requestId == "string" && bn(r.payload.format) && yn(r.payload.renderBackend) && (r.payload.svgText === void 0 || typeof r.payload.svgText == "string") && (r.payload.svgDataUrl === void 0 || typeof r.payload.svgDataUrl == "string") && (r.payload.pngDataUrl === void 0 || typeof r.payload.pngDataUrl == "string") && (r.payload.error === void 0 || typeof r.payload.error == "string");
    case P.ACTION_PASTE_LATEX:
    case P.ACTION_PASTE_MATHML:
    case P.ACTION_COPY_IMAGE_PNG:
    case P.ACTION_PASTE_IMAGE_PNG:
    case P.ACTION_PASTE_IMAGE_SVG:
    case P.ACTION_CLEAR:
    case P.ACTION_CLOSE:
      return !0;
    case P.SNAPSHOT:
      return pt(r.payload);
    case P.OPERATION_APPLIED:
      return we(r.payload) && typeof r.payload.requestId == "string" && pt(r.payload.state);
    case P.RENDER_STATUS:
      return we(r.payload) && (r.payload.editorKind === "canvas-core" || r.payload.editorKind === "fallback") && typeof r.payload.directEditing == "boolean" && (r.payload.editorDiagnostics === void 0 || we(r.payload.editorDiagnostics) && typeof r.payload.editorDiagnostics.mounted == "boolean" && typeof r.payload.editorDiagnostics.focused == "boolean" && typeof r.payload.editorDiagnostics.supportsDirectEditing == "boolean" && (r.payload.editorDiagnostics.lastInputEvent === void 0 || r.payload.editorDiagnostics.lastInputEvent === "input" || r.payload.editorDiagnostics.lastInputEvent === "change" || r.payload.editorDiagnostics.lastInputEvent === "selection-change"));
    default:
      return !1;
  }
}
const wn = /\{\{\{(\d+)\}\}\}/g, Sn = " ";
function da(r, e = Sn) {
  const t = [];
  let a = "", n = 0;
  for (const i of r.matchAll(wn)) {
    const l = i[0], u = i.index ?? 0, h = Number(i[1]);
    a += r.slice(n, u), a += "{";
    const f = a.length;
    a += e;
    const v = a.length;
    a += "}", t.push({ index: h, start: f, end: v }), n = u + l.length;
  }
  return a += r.slice(n), t.sort((i, l) => i.index - l.index), { text: a, slots: t };
}
function An(r, e) {
  return e === "inline" ? `$${r}$` : e === "display" ? `$$${r}$$` : r;
}
let yr = 0;
function De(r = "canvas") {
  return yr += 1, `${r}-${yr}`;
}
function X0() {
  return {
    kind: "placeholder",
    id: De("placeholder")
  };
}
function pa(r) {
  const e = r.filter((n) => n.kind !== "row"), t = e.length === 0 ? [X0()] : e;
  return t.some((n) => n.kind !== "placeholder") ? t.filter((n) => n.kind !== "placeholder") : [X0()];
}
function le(r = []) {
  return {
    kind: "row",
    id: De("row"),
    children: pa(r)
  };
}
function d0(r = []) {
  const e = r.length > 0 ? r.map((t) => ({ ...t, children: pa(t.children) })) : [le()];
  return {
    kind: "document",
    id: De("document"),
    rows: e
  };
}
function Se(r, e = Cn(r)) {
  return {
    kind: "token",
    id: De("token"),
    role: e,
    value: r
  };
}
function kn() {
  return {
    kind: "fraction",
    id: De("fraction"),
    numerator: le(),
    denominator: le()
  };
}
function xr(r = !1) {
  return {
    kind: "root",
    id: De("root"),
    radicand: le(),
    ...r ? { index: le() } : {}
  };
}
function wr(r) {
  return {
    kind: "script",
    id: De("script"),
    base: le(),
    ...r === "superscript" ? { superscript: le() } : { subscript: le() }
  };
}
function B0(r) {
  return {
    kind: "script",
    id: De("script"),
    base: r.base ?? le(),
    ...r.superscript ? { superscript: r.superscript } : {},
    ...r.subscript ? { subscript: r.subscript } : {},
    ...r.latexCommand ? { latexCommand: r.latexCommand } : {}
  };
}
function Tn(r, e) {
  return {
    kind: "delimited",
    id: De("delimited"),
    left: r,
    right: e,
    body: le()
  };
}
function Mn(r, e, t) {
  const a = Math.max(1, Math.trunc(r)), n = Math.max(1, Math.trunc(e));
  return {
    kind: "matrix",
    id: De("matrix"),
    environment: t,
    rows: Array.from({ length: a }, () => Array.from({ length: n }, () => le())),
    ...t === "array" ? { alignment: Array.from({ length: n }, () => "c") } : {}
  };
}
function Cn(r) {
  return /^\d+$/.test(r) ? "number" : /^[a-zA-Z]$/.test(r) || /^[\u0370-\u03FF]$/.test(r) ? "identifier" : /^[+\-*/=<>≤≥±×÷·∑∏∫_^[\](){}|⟨⟩⌊⌋⌈⌉‖!'%\u2190-\u21FF\u2200-\u22FF\u27C0-\u27FF\u2900-\u297F\u2A00-\u2AFF]$/.test(r) ? "operator" : "text";
}
let En = null;
function zn() {
  return typeof DOMParser < "u" ? DOMParser : En;
}
function re(r) {
  return Array.from(r.children);
}
function Ce(r) {
  return (r.textContent ?? "").trim();
}
function h0(r) {
  const e = r.map(J0).flatMap((t) => t.kind === "row" ? t.children : [t]);
  return le(e);
}
function te(r) {
  if (!r)
    return le();
  const e = r.tagName.toLowerCase();
  return e === "math" || e === "semantics" || e === "mrow" || e === "mtd" ? h0(
    re(r).filter((t) => {
      const a = t.tagName.toLowerCase();
      return a !== "annotation" && a !== "annotation-xml";
    })
  ) : le([J0(r)]);
}
function Dn(r, e) {
  return r === "(" && e === ")" ? "pmatrix" : r === "[" && e === "]" ? "bmatrix" : r === "{" && e === "}" ? "Bmatrix" : r === "|" && e === "|" ? "vmatrix" : r === "\u2225" && e === "\u2225" ? "Vmatrix" : "matrix";
}
function Sr(r, e) {
  const t = re(r).filter((n) => n.tagName.toLowerCase() === "mtr").map(
    (n) => re(n).filter((i) => i.tagName.toLowerCase() === "mtd").map((i) => h0(re(i)))
  ), a = Mn(t.length || 1, t[0]?.length || 1, e);
  return t.length > 0 && (a.rows = t), a;
}
const Rn = {
  "\u2192": "\\xrightarrow",
  "\u2190": "\\xleftarrow",
  "\u2194": "\\xleftrightarrow",
  "\u21D2": "\\xRightarrow",
  "\u21D0": "\\xLeftarrow",
  "\u21D4": "\\xLeftrightarrow",
  "\u21A6": "\\xmapsto"
};
function ft(r) {
  return r.tagName.toLowerCase() !== "mo" ? null : Rn[Ce(r)] ?? null;
}
function J0(r) {
  switch (r.tagName.toLowerCase()) {
    case "math":
    case "semantics":
      return h0(
        re(r).filter((t) => {
          const a = t.tagName.toLowerCase();
          return a !== "annotation" && a !== "annotation-xml";
        })
      );
    case "mrow": {
      const t = re(r);
      if (t.length === 3 && t[0]?.tagName.toLowerCase() === "mo" && t[2]?.tagName.toLowerCase() === "mo" && t[1]?.tagName.toLowerCase() === "mtable")
        return Sr(
          t[1],
          Dn(Ce(t[0]), Ce(t[2]))
        );
      if (t.length === 3 && t[0]?.tagName.toLowerCase() === "mo" && t[2]?.tagName.toLowerCase() === "mo") {
        const a = Tn(Ce(t[0]) || "(", Ce(t[2]) || ")");
        return a.body = te(t[1]), a;
      }
      return h0(t);
    }
    case "mi": {
      const t = Ce(r);
      return t === "\u25A1" ? X0() : Se(t || "x", "identifier");
    }
    case "mn":
      return Se(Ce(r) || "0", "number");
    case "mo":
      return Se(Ce(r) || "+", "operator");
    case "mtext": {
      const t = Ce(r);
      return t === "\u25A1" ? X0() : Se(t || "", "text");
    }
    case "mfrac": {
      const t = re(r), a = kn();
      return a.numerator = te(t[0]), a.denominator = te(t[1]), a;
    }
    case "msqrt": {
      const t = xr(!1);
      return t.radicand = h0(re(r)), t;
    }
    case "mroot": {
      const t = re(r), a = xr(!0);
      return a.radicand = te(t[0]), a.index = te(t[1]), a;
    }
    case "msup": {
      const t = re(r), a = wr("superscript");
      return a.base = te(t[0]), a.superscript = te(t[1]), a;
    }
    case "msub": {
      const t = re(r), a = wr("subscript");
      return a.base = te(t[0]), a.subscript = te(t[1]), a;
    }
    case "msubsup": {
      const t = re(r);
      return B0({
        base: te(t[0]),
        subscript: te(t[1]),
        superscript: te(t[2])
      });
    }
    case "mtable":
      return Sr(r, "matrix");
    case "mstyle":
    case "mpadded":
      return h0(re(r));
    case "mover": {
      const t = re(r), a = t[0], n = t[1], i = a ? ft(a) : null;
      return B0({
        base: te(a),
        superscript: te(n),
        ...i ? { latexCommand: i } : {}
      });
    }
    case "munder": {
      const t = re(r), a = t[0], n = t[1], i = a ? ft(a) : null;
      return B0({
        base: te(a),
        subscript: te(n),
        ...i ? { latexCommand: i } : {}
      });
    }
    case "munderover": {
      const t = re(r), a = t[0], n = t[1], i = t[2], l = a ? ft(a) : null;
      return B0({
        base: te(a),
        subscript: te(n),
        superscript: te(i),
        ...l ? { latexCommand: l } : {}
      });
    }
    default: {
      const t = re(r).find((n) => n.tagName.toLowerCase() === "math");
      if (t)
        return J0(t);
      const a = Ce(r);
      return a ? Se(a, "text") : le();
    }
  }
}
function Fn(r) {
  const e = re(r).find((a) => a.tagName.toLowerCase() === "mtable" && a.getAttribute("data-canvas-document") === "true");
  if (e) {
    const a = re(e).filter((n) => n.tagName.toLowerCase() === "mtr").map((n) => {
      const i = re(n).find((l) => l.tagName.toLowerCase() === "mtd");
      return te(i);
    });
    return d0(a);
  }
  const t = J0(r);
  return d0([t.kind === "row" ? t : le([t])]);
}
function x0(r) {
  const e = r.trim();
  if (!e)
    return {
      ok: !0,
      value: d0()
    };
  const t = zn();
  if (!t)
    return {
      ok: !1,
      error: "DOMParser is not available for MathML import."
    };
  try {
    const n = new t().parseFromString(e, "application/xml").querySelector("math");
    return n ? {
      ok: !0,
      value: Fn(n)
    } : {
      ok: !1,
      error: "Could not parse MathML."
    };
  } catch (a) {
    return {
      ok: !1,
      error: a instanceof Error ? a.message : "MathML import failed."
    };
  }
}
class ve {
  // The + prefix indicates that these fields aren't writeable
  // Lexer holding the input string.
  // Start offset, zero-based inclusive.
  // End offset, zero-based exclusive.
  constructor(e, t, a) {
    this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = a;
  }
  /**
   * Merges two `SourceLocation`s from location providers, given they are
   * provided in order of appearance.
   * - Returns the first one's location if only the first is provided.
   * - Returns a merged range of the first and the last if both are provided
   *   and their lexers match.
   * - Otherwise, returns null.
   */
  static range(e, t) {
    return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new ve(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc;
  }
}
class be {
  // don't expand the token
  // used in \noexpand
  constructor(e, t) {
    this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
  }
  /**
   * Given a pair of tokens (this and endToken), compute a `Token` encompassing
   * the whole input range enclosed by these two.
   */
  range(e, t) {
    return new be(t, ve.range(this, e));
  }
}
class k {
  // Error start position based on passed-in Token or ParseNode.
  // Length of affected text based on passed-in Token or ParseNode.
  // The underlying error message without any context added.
  constructor(e, t) {
    this.name = void 0, this.position = void 0, this.length = void 0, this.rawMessage = void 0;
    var a = "KaTeX parse error: " + e, n, i, l = t && t.loc;
    if (l && l.start <= l.end) {
      var u = l.lexer.input;
      n = l.start, i = l.end, n === u.length ? a += " at end of input: " : a += " at position " + (n + 1) + ": ";
      var h = u.slice(n, i).replace(/[^]/g, "$&\u0332"), f;
      n > 15 ? f = "\u2026" + u.slice(n - 15, n) : f = u.slice(0, n);
      var v;
      i + 15 < u.length ? v = u.slice(i, i + 15) + "\u2026" : v = u.slice(i), a += f + h + v;
    }
    var b = new Error(a);
    return b.name = "ParseError", b.__proto__ = k.prototype, b.position = n, n != null && i != null && (b.length = i - n), b.rawMessage = e, b;
  }
}
k.prototype.__proto__ = Error.prototype;
var In = /([A-Z])/g, Zt = (r) => r.replace(In, "-$1").toLowerCase(), Bn = {
  "&": "&amp;",
  ">": "&gt;",
  "<": "&lt;",
  '"': "&quot;",
  "'": "&#x27;"
}, Nn = /[&><"']/g, ue = (r) => String(r).replace(Nn, (e) => Bn[e]), w0 = (r) => r.type === "ordgroup" || r.type === "color" ? r.body.length === 1 ? w0(r.body[0]) : r : r.type === "font" ? w0(r.body) : r, qn = /* @__PURE__ */ new Set(["mathord", "textord", "atom"]), Pe = (r) => qn.has(w0(r).type), On = (r) => {
  var e = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(r);
  return e ? e[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(e[1]) ? null : e[1].toLowerCase() : "_relative";
}, vt = {
  displayMode: {
    type: "boolean",
    description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
    cli: "-d, --display-mode"
  },
  output: {
    type: {
      enum: ["htmlAndMathml", "html", "mathml"]
    },
    description: "Determines the markup language of the output.",
    cli: "-F, --format <type>"
  },
  leqno: {
    type: "boolean",
    description: "Render display math in leqno style (left-justified tags)."
  },
  fleqn: {
    type: "boolean",
    description: "Render display math flush left."
  },
  throwOnError: {
    type: "boolean",
    default: !0,
    cli: "-t, --no-throw-on-error",
    cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
  },
  errorColor: {
    type: "string",
    default: "#cc0000",
    cli: "-c, --error-color <color>",
    cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
    cliProcessor: (r) => "#" + r
  },
  macros: {
    type: "object",
    cli: "-m, --macro <def>",
    cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
    cliDefault: [],
    cliProcessor: (r, e) => (e.push(r), e)
  },
  minRuleThickness: {
    type: "number",
    description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
    processor: (r) => Math.max(0, r),
    cli: "--min-rule-thickness <size>",
    cliProcessor: parseFloat
  },
  colorIsTextColor: {
    type: "boolean",
    description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
    cli: "-b, --color-is-text-color"
  },
  strict: {
    type: [{
      enum: ["warn", "ignore", "error"]
    }, "boolean", "function"],
    description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
    cli: "-S, --strict",
    cliDefault: !1
  },
  trust: {
    type: ["boolean", "function"],
    description: "Trust the input, enabling all HTML features such as \\url.",
    cli: "-T, --trust"
  },
  maxSize: {
    type: "number",
    default: 1 / 0,
    description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
    processor: (r) => Math.max(0, r),
    cli: "-s, --max-size <n>",
    cliProcessor: parseInt
  },
  maxExpand: {
    type: "number",
    default: 1e3,
    description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
    processor: (r) => Math.max(0, r),
    cli: "-e, --max-expand <n>",
    cliProcessor: (r) => r === "Infinity" ? 1 / 0 : parseInt(r)
  },
  globalGroup: {
    type: "boolean",
    cli: !1
  }
};
function Ln(r) {
  if (r.default)
    return r.default;
  var e = r.type, t = Array.isArray(e) ? e[0] : e;
  if (typeof t != "string")
    return t.enum[0];
  switch (t) {
    case "boolean":
      return !1;
    case "string":
      return "";
    case "number":
      return 0;
    case "object":
      return {};
  }
}
class Pn {
  constructor(e) {
    this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, e = e || {};
    for (var t in vt)
      if (vt.hasOwnProperty(t)) {
        var a = vt[t];
        this[t] = e[t] !== void 0 ? a.processor ? a.processor(e[t]) : e[t] : Ln(a);
      }
  }
  /**
   * Report nonstrict (non-LaTeX-compatible) input.
   * Can safely not be called if `this.strict` is false in JavaScript.
   */
  reportNonstrict(e, t, a) {
    var n = this.strict;
    if (typeof n == "function" && (n = n(e, t, a)), !(!n || n === "ignore")) {
      if (n === !0 || n === "error")
        throw new k("LaTeX-incompatible input and strict mode is set to 'error': " + (t + " [" + e + "]"), a);
      n === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + n + "': " + t + " [" + e + "]"));
    }
  }
  /**
   * Check whether to apply strict (LaTeX-adhering) behavior for unusual
   * input (like `\\`).  Unlike `nonstrict`, will not throw an error;
   * instead, "error" translates to a return value of `true`, while "ignore"
   * translates to a return value of `false`.  May still print a warning:
   * "warn" prints a warning and returns `false`.
   * This is for the second category of `errorCode`s listed in the README.
   */
  useStrictBehavior(e, t, a) {
    var n = this.strict;
    if (typeof n == "function")
      try {
        n = n(e, t, a);
      } catch {
        n = "error";
      }
    return !n || n === "ignore" ? !1 : n === !0 || n === "error" ? !0 : n === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + n + "': " + t + " [" + e + "]")), !1);
  }
  /**
   * Check whether to test potentially dangerous input, and return
   * `true` (trusted) or `false` (untrusted).  The sole argument `context`
   * should be an object with `command` field specifying the relevant LaTeX
   * command (as a string starting with `\`), and any other arguments, etc.
   * If `context` has a `url` field, a `protocol` field will automatically
   * get added by this function (changing the specified object).
   */
  isTrusted(e) {
    if (e.url && !e.protocol) {
      var t = On(e.url);
      if (t == null)
        return !1;
      e.protocol = t;
    }
    var a = typeof this.trust == "function" ? this.trust(e) : this.trust;
    return !!a;
  }
}
class Xe {
  constructor(e, t, a) {
    this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = a;
  }
  /**
   * Get the style of a superscript given a base in the current style.
   */
  sup() {
    return ze[Hn[this.id]];
  }
  /**
   * Get the style of a subscript given a base in the current style.
   */
  sub() {
    return ze[Gn[this.id]];
  }
  /**
   * Get the style of a fraction numerator given the fraction in the current
   * style.
   */
  fracNum() {
    return ze[Un[this.id]];
  }
  /**
   * Get the style of a fraction denominator given the fraction in the current
   * style.
   */
  fracDen() {
    return ze[Vn[this.id]];
  }
  /**
   * Get the cramped version of a style (in particular, cramping a cramped style
   * doesn't change the style).
   */
  cramp() {
    return ze[$n[this.id]];
  }
  /**
   * Get a text or display version of this style.
   */
  text() {
    return ze[Xn[this.id]];
  }
  /**
   * Return true if this style is tightly spaced (scriptstyle/scriptscriptstyle)
   */
  isTight() {
    return this.size >= 2;
  }
}
var Jt = 0, W0 = 1, m0 = 2, Le = 3, T0 = 4, Ae = 5, p0 = 6, de = 7, ze = [new Xe(Jt, 0, !1), new Xe(W0, 0, !0), new Xe(m0, 1, !1), new Xe(Le, 1, !0), new Xe(T0, 2, !1), new Xe(Ae, 2, !0), new Xe(p0, 3, !1), new Xe(de, 3, !0)], Hn = [T0, Ae, T0, Ae, p0, de, p0, de], Gn = [Ae, Ae, Ae, Ae, de, de, de, de], Un = [m0, Le, T0, Ae, p0, de, p0, de], Vn = [Le, Le, Ae, Ae, de, de, de, de], $n = [W0, W0, Le, Le, Ae, Ae, de, de], Xn = [Jt, W0, m0, Le, m0, Le, m0, Le], N = {
  DISPLAY: ze[Jt],
  TEXT: ze[m0],
  SCRIPT: ze[T0],
  SCRIPTSCRIPT: ze[p0]
}, qt = [{
  // Latin characters beyond the Latin-1 characters we have metrics for.
  // Needed for Czech, Hungarian and Turkish text, for example.
  name: "latin",
  blocks: [
    [256, 591],
    // Latin Extended-A and Latin Extended-B
    [768, 879]
    // Combining Diacritical marks
  ]
}, {
  // The Cyrillic script used by Russian and related languages.
  // A Cyrillic subset used to be supported as explicitly defined
  // symbols in symbols.js
  name: "cyrillic",
  blocks: [[1024, 1279]]
}, {
  // Armenian
  name: "armenian",
  blocks: [[1328, 1423]]
}, {
  // The Brahmic scripts of South and Southeast Asia
  // Devanagari (0900–097F)
  // Bengali (0980–09FF)
  // Gurmukhi (0A00–0A7F)
  // Gujarati (0A80–0AFF)
  // Oriya (0B00–0B7F)
  // Tamil (0B80–0BFF)
  // Telugu (0C00–0C7F)
  // Kannada (0C80–0CFF)
  // Malayalam (0D00–0D7F)
  // Sinhala (0D80–0DFF)
  // Thai (0E00–0E7F)
  // Lao (0E80–0EFF)
  // Tibetan (0F00–0FFF)
  // Myanmar (1000–109F)
  name: "brahmic",
  blocks: [[2304, 4255]]
}, {
  name: "georgian",
  blocks: [[4256, 4351]]
}, {
  // Chinese and Japanese.
  // The "k" in cjk is for Korean, but we've separated Korean out
  name: "cjk",
  blocks: [
    [12288, 12543],
    // CJK symbols and punctuation, Hiragana, Katakana
    [19968, 40879],
    // CJK ideograms
    [65280, 65376]
    // Fullwidth punctuation
    // TODO: add halfwidth Katakana and Romanji glyphs
  ]
}, {
  // Korean
  name: "hangul",
  blocks: [[44032, 55215]]
}];
function Wn(r) {
  for (var e = 0; e < qt.length; e++)
    for (var t = qt[e], a = 0; a < t.blocks.length; a++) {
      var n = t.blocks[a];
      if (r >= n[0] && r <= n[1])
        return t.name;
    }
  return null;
}
var $0 = [];
qt.forEach((r) => r.blocks.forEach((e) => $0.push(...e)));
function fa(r) {
  for (var e = 0; e < $0.length; e += 2)
    if (r >= $0[e] && r <= $0[e + 1])
      return !0;
  return !1;
}
var u0 = 80, Yn = function(e, t) {
  return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, Kn = function(e, t) {
  return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, _n = function(e, t) {
  return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, jn = function(e, t) {
  return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, Zn = function(e, t) {
  return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, Jn = function(e) {
  var t = e / 2;
  return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, Qn = function(e, t, a) {
  var n = a - 54 - t - e;
  return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + n + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, ei = function(e, t, a) {
  t = 1e3 * t;
  var n = "";
  switch (e) {
    case "sqrtMain":
      n = Yn(t, u0);
      break;
    case "sqrtSize1":
      n = Kn(t, u0);
      break;
    case "sqrtSize2":
      n = _n(t, u0);
      break;
    case "sqrtSize3":
      n = jn(t, u0);
      break;
    case "sqrtSize4":
      n = Zn(t, u0);
      break;
    case "sqrtTall":
      n = Qn(t, u0, a);
  }
  return n;
}, ti = function(e, t) {
  switch (e) {
    case "\u239C":
      return "M291 0 H417 V" + t + " H291z M291 0 H417 V" + t + " H291z";
    case "\u2223":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z";
    case "\u2225":
      return "M145 0 H188 V" + t + " H145z M145 0 H188 V" + t + " H145z" + ("M367 0 H410 V" + t + " H367z M367 0 H410 V" + t + " H367z");
    case "\u239F":
      return "M457 0 H583 V" + t + " H457z M457 0 H583 V" + t + " H457z";
    case "\u23A2":
      return "M319 0 H403 V" + t + " H319z M319 0 H403 V" + t + " H319z";
    case "\u23A5":
      return "M263 0 H347 V" + t + " H263z M263 0 H347 V" + t + " H263z";
    case "\u23AA":
      return "M384 0 H504 V" + t + " H384z M384 0 H504 V" + t + " H384z";
    case "\u23D0":
      return "M312 0 H355 V" + t + " H312z M312 0 H355 V" + t + " H312z";
    case "\u2016":
      return "M257 0 H300 V" + t + " H257z M257 0 H300 V" + t + " H257z" + ("M478 0 H521 V" + t + " H478z M478 0 H521 V" + t + " H478z");
    default:
      return "";
  }
}, Ar = {
  // The doubleleftarrow geometry is from glyph U+21D0 in the font KaTeX Main
  doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`,
  // doublerightarrow is from glyph U+21D2 in font KaTeX Main
  doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`,
  // leftarrow is from glyph U+2190 in font KaTeX Main
  leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`,
  // overbrace is from glyphs U+23A9/23A8/23A7 in font KaTeX_Size4-Regular
  leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`,
  leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`,
  // overgroup is from the MnSymbol package (public domain)
  leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`,
  leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`,
  // Harpoons are from glyph U+21BD in font KaTeX Main
  leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`,
  leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`,
  leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`,
  leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`,
  // hook is from glyph U+21A9 in font KaTeX Main
  lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`,
  leftlinesegment: `M40 281 V428 H0 V94 H40 V241 H400000 v40z
M40 281 V428 H0 V94 H40 V241 H400000 v40z`,
  leftmapsto: `M40 281 V448H0V74H40V241H400000v40z
M40 281 V448H0V74H40V241H400000v40z`,
  // tofrom is from glyph U+21C4 in font KaTeX AMS Regular
  leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`,
  longequal: `M0 50 h400000 v40H0z m0 194h40000v40H0z
M0 50 h400000 v40H0z m0 194h40000v40H0z`,
  midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`,
  midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`,
  oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`,
  oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`,
  oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`,
  oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`,
  rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`,
  rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`,
  rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`,
  rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`,
  rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`,
  rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`,
  rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`,
  rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`,
  rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`,
  righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`,
  rightlinesegment: `M399960 241 V94 h40 V428 h-40 V281 H0 v-40z
M399960 241 V94 h40 V428 h-40 V281 H0 v-40z`,
  rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`,
  // twoheadleftarrow is from glyph U+219E in font KaTeX AMS Regular
  twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`,
  twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`,
  // tilde1 is a modified version of a glyph from the MnSymbol package
  tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`,
  // ditto tilde2, tilde3, & tilde4
  tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`,
  tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`,
  tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`,
  // vec is from glyph U+20D7 in font KaTeX Main
  vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`,
  // widehat1 is a modified version of a glyph from the MnSymbol package
  widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`,
  // ditto widehat2, widehat3, & widehat4
  widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`,
  // widecheck paths are all inverted versions of widehat
  widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`,
  widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`,
  // The next ten paths support reaction arrows from the mhchem package.
  // Arrows for \ce{<-->} are offset from xAxis by 0.22ex, per mhchem in LaTeX
  // baraboveleftarrow is mostly from glyph U+2190 in font KaTeX Main
  baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`,
  // rightarrowabovebar is mostly from glyph U+2192, KaTeX Main
  rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`,
  // The short left harpoon has 0.5em (i.e. 500 units) kern on the left end.
  // Ref from mhchem.sty: \rlap{\raisebox{-.22ex}{$\kern0.5em
  baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`,
  rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`,
  shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`,
  shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z`
}, ri = function(e, t) {
  switch (e) {
    case "lbrack":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 h84z";
    case "rbrack":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
    case "vert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
    case "doublevert":
      return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
    case "lfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "rfloor":
      return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
    case "lceil":
      return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
    case "rceil":
      return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
    case "lparen":
      return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
    case "rparen":
      return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
    default:
      throw new Error("Unknown stretchy delimiter.");
  }
};
class C0 {
  // Never used; needed for satisfying interface.
  constructor(e) {
    this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  /** Convert the fragment into a node. */
  toNode() {
    for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
      e.appendChild(this.children[t].toNode());
    return e;
  }
  /** Convert the fragment into HTML markup. */
  toMarkup() {
    for (var e = "", t = 0; t < this.children.length; t++)
      e += this.children[t].toMarkup();
    return e;
  }
  /**
   * Converts the math node into a string, similar to innerText. Applies to
   * MathDomNode's only.
   */
  toText() {
    var e = (t) => t.toText();
    return this.children.map(e).join("");
  }
}
var Oe = {
  "AMS-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68889, 0, 0, 0.72222],
    66: [0, 0.68889, 0, 0, 0.66667],
    67: [0, 0.68889, 0, 0, 0.72222],
    68: [0, 0.68889, 0, 0, 0.72222],
    69: [0, 0.68889, 0, 0, 0.66667],
    70: [0, 0.68889, 0, 0, 0.61111],
    71: [0, 0.68889, 0, 0, 0.77778],
    72: [0, 0.68889, 0, 0, 0.77778],
    73: [0, 0.68889, 0, 0, 0.38889],
    74: [0.16667, 0.68889, 0, 0, 0.5],
    75: [0, 0.68889, 0, 0, 0.77778],
    76: [0, 0.68889, 0, 0, 0.66667],
    77: [0, 0.68889, 0, 0, 0.94445],
    78: [0, 0.68889, 0, 0, 0.72222],
    79: [0.16667, 0.68889, 0, 0, 0.77778],
    80: [0, 0.68889, 0, 0, 0.61111],
    81: [0.16667, 0.68889, 0, 0, 0.77778],
    82: [0, 0.68889, 0, 0, 0.72222],
    83: [0, 0.68889, 0, 0, 0.55556],
    84: [0, 0.68889, 0, 0, 0.66667],
    85: [0, 0.68889, 0, 0, 0.72222],
    86: [0, 0.68889, 0, 0, 0.72222],
    87: [0, 0.68889, 0, 0, 1],
    88: [0, 0.68889, 0, 0, 0.72222],
    89: [0, 0.68889, 0, 0, 0.72222],
    90: [0, 0.68889, 0, 0, 0.66667],
    107: [0, 0.68889, 0, 0, 0.55556],
    160: [0, 0, 0, 0, 0.25],
    165: [0, 0.675, 0.025, 0, 0.75],
    174: [0.15559, 0.69224, 0, 0, 0.94666],
    240: [0, 0.68889, 0, 0, 0.55556],
    295: [0, 0.68889, 0, 0, 0.54028],
    710: [0, 0.825, 0, 0, 2.33334],
    732: [0, 0.9, 0, 0, 2.33334],
    770: [0, 0.825, 0, 0, 2.33334],
    771: [0, 0.9, 0, 0, 2.33334],
    989: [0.08167, 0.58167, 0, 0, 0.77778],
    1008: [0, 0.43056, 0.04028, 0, 0.66667],
    8245: [0, 0.54986, 0, 0, 0.275],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8487: [0, 0.68889, 0, 0, 0.72222],
    8498: [0, 0.68889, 0, 0, 0.55556],
    8502: [0, 0.68889, 0, 0, 0.66667],
    8503: [0, 0.68889, 0, 0, 0.44445],
    8504: [0, 0.68889, 0, 0, 0.66667],
    8513: [0, 0.68889, 0, 0, 0.63889],
    8592: [-0.03598, 0.46402, 0, 0, 0.5],
    8594: [-0.03598, 0.46402, 0, 0, 0.5],
    8602: [-0.13313, 0.36687, 0, 0, 1],
    8603: [-0.13313, 0.36687, 0, 0, 1],
    8606: [0.01354, 0.52239, 0, 0, 1],
    8608: [0.01354, 0.52239, 0, 0, 1],
    8610: [0.01354, 0.52239, 0, 0, 1.11111],
    8611: [0.01354, 0.52239, 0, 0, 1.11111],
    8619: [0, 0.54986, 0, 0, 1],
    8620: [0, 0.54986, 0, 0, 1],
    8621: [-0.13313, 0.37788, 0, 0, 1.38889],
    8622: [-0.13313, 0.36687, 0, 0, 1],
    8624: [0, 0.69224, 0, 0, 0.5],
    8625: [0, 0.69224, 0, 0, 0.5],
    8630: [0, 0.43056, 0, 0, 1],
    8631: [0, 0.43056, 0, 0, 1],
    8634: [0.08198, 0.58198, 0, 0, 0.77778],
    8635: [0.08198, 0.58198, 0, 0, 0.77778],
    8638: [0.19444, 0.69224, 0, 0, 0.41667],
    8639: [0.19444, 0.69224, 0, 0, 0.41667],
    8642: [0.19444, 0.69224, 0, 0, 0.41667],
    8643: [0.19444, 0.69224, 0, 0, 0.41667],
    8644: [0.1808, 0.675, 0, 0, 1],
    8646: [0.1808, 0.675, 0, 0, 1],
    8647: [0.1808, 0.675, 0, 0, 1],
    8648: [0.19444, 0.69224, 0, 0, 0.83334],
    8649: [0.1808, 0.675, 0, 0, 1],
    8650: [0.19444, 0.69224, 0, 0, 0.83334],
    8651: [0.01354, 0.52239, 0, 0, 1],
    8652: [0.01354, 0.52239, 0, 0, 1],
    8653: [-0.13313, 0.36687, 0, 0, 1],
    8654: [-0.13313, 0.36687, 0, 0, 1],
    8655: [-0.13313, 0.36687, 0, 0, 1],
    8666: [0.13667, 0.63667, 0, 0, 1],
    8667: [0.13667, 0.63667, 0, 0, 1],
    8669: [-0.13313, 0.37788, 0, 0, 1],
    8672: [-0.064, 0.437, 0, 0, 1.334],
    8674: [-0.064, 0.437, 0, 0, 1.334],
    8705: [0, 0.825, 0, 0, 0.5],
    8708: [0, 0.68889, 0, 0, 0.55556],
    8709: [0.08167, 0.58167, 0, 0, 0.77778],
    8717: [0, 0.43056, 0, 0, 0.42917],
    8722: [-0.03598, 0.46402, 0, 0, 0.5],
    8724: [0.08198, 0.69224, 0, 0, 0.77778],
    8726: [0.08167, 0.58167, 0, 0, 0.77778],
    8733: [0, 0.69224, 0, 0, 0.77778],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8737: [0, 0.69224, 0, 0, 0.72222],
    8738: [0.03517, 0.52239, 0, 0, 0.72222],
    8739: [0.08167, 0.58167, 0, 0, 0.22222],
    8740: [0.25142, 0.74111, 0, 0, 0.27778],
    8741: [0.08167, 0.58167, 0, 0, 0.38889],
    8742: [0.25142, 0.74111, 0, 0, 0.5],
    8756: [0, 0.69224, 0, 0, 0.66667],
    8757: [0, 0.69224, 0, 0, 0.66667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8765: [-0.13313, 0.37788, 0, 0, 0.77778],
    8769: [-0.13313, 0.36687, 0, 0, 0.77778],
    8770: [-0.03625, 0.46375, 0, 0, 0.77778],
    8774: [0.30274, 0.79383, 0, 0, 0.77778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8778: [0.08167, 0.58167, 0, 0, 0.77778],
    8782: [0.06062, 0.54986, 0, 0, 0.77778],
    8783: [0.06062, 0.54986, 0, 0, 0.77778],
    8785: [0.08198, 0.58198, 0, 0, 0.77778],
    8786: [0.08198, 0.58198, 0, 0, 0.77778],
    8787: [0.08198, 0.58198, 0, 0, 0.77778],
    8790: [0, 0.69224, 0, 0, 0.77778],
    8791: [0.22958, 0.72958, 0, 0, 0.77778],
    8796: [0.08198, 0.91667, 0, 0, 0.77778],
    8806: [0.25583, 0.75583, 0, 0, 0.77778],
    8807: [0.25583, 0.75583, 0, 0, 0.77778],
    8808: [0.25142, 0.75726, 0, 0, 0.77778],
    8809: [0.25142, 0.75726, 0, 0, 0.77778],
    8812: [0.25583, 0.75583, 0, 0, 0.5],
    8814: [0.20576, 0.70576, 0, 0, 0.77778],
    8815: [0.20576, 0.70576, 0, 0, 0.77778],
    8816: [0.30274, 0.79383, 0, 0, 0.77778],
    8817: [0.30274, 0.79383, 0, 0, 0.77778],
    8818: [0.22958, 0.72958, 0, 0, 0.77778],
    8819: [0.22958, 0.72958, 0, 0, 0.77778],
    8822: [0.1808, 0.675, 0, 0, 0.77778],
    8823: [0.1808, 0.675, 0, 0, 0.77778],
    8828: [0.13667, 0.63667, 0, 0, 0.77778],
    8829: [0.13667, 0.63667, 0, 0, 0.77778],
    8830: [0.22958, 0.72958, 0, 0, 0.77778],
    8831: [0.22958, 0.72958, 0, 0, 0.77778],
    8832: [0.20576, 0.70576, 0, 0, 0.77778],
    8833: [0.20576, 0.70576, 0, 0, 0.77778],
    8840: [0.30274, 0.79383, 0, 0, 0.77778],
    8841: [0.30274, 0.79383, 0, 0, 0.77778],
    8842: [0.13597, 0.63597, 0, 0, 0.77778],
    8843: [0.13597, 0.63597, 0, 0, 0.77778],
    8847: [0.03517, 0.54986, 0, 0, 0.77778],
    8848: [0.03517, 0.54986, 0, 0, 0.77778],
    8858: [0.08198, 0.58198, 0, 0, 0.77778],
    8859: [0.08198, 0.58198, 0, 0, 0.77778],
    8861: [0.08198, 0.58198, 0, 0, 0.77778],
    8862: [0, 0.675, 0, 0, 0.77778],
    8863: [0, 0.675, 0, 0, 0.77778],
    8864: [0, 0.675, 0, 0, 0.77778],
    8865: [0, 0.675, 0, 0, 0.77778],
    8872: [0, 0.69224, 0, 0, 0.61111],
    8873: [0, 0.69224, 0, 0, 0.72222],
    8874: [0, 0.69224, 0, 0, 0.88889],
    8876: [0, 0.68889, 0, 0, 0.61111],
    8877: [0, 0.68889, 0, 0, 0.61111],
    8878: [0, 0.68889, 0, 0, 0.72222],
    8879: [0, 0.68889, 0, 0, 0.72222],
    8882: [0.03517, 0.54986, 0, 0, 0.77778],
    8883: [0.03517, 0.54986, 0, 0, 0.77778],
    8884: [0.13667, 0.63667, 0, 0, 0.77778],
    8885: [0.13667, 0.63667, 0, 0, 0.77778],
    8888: [0, 0.54986, 0, 0, 1.11111],
    8890: [0.19444, 0.43056, 0, 0, 0.55556],
    8891: [0.19444, 0.69224, 0, 0, 0.61111],
    8892: [0.19444, 0.69224, 0, 0, 0.61111],
    8901: [0, 0.54986, 0, 0, 0.27778],
    8903: [0.08167, 0.58167, 0, 0, 0.77778],
    8905: [0.08167, 0.58167, 0, 0, 0.77778],
    8906: [0.08167, 0.58167, 0, 0, 0.77778],
    8907: [0, 0.69224, 0, 0, 0.77778],
    8908: [0, 0.69224, 0, 0, 0.77778],
    8909: [-0.03598, 0.46402, 0, 0, 0.77778],
    8910: [0, 0.54986, 0, 0, 0.76042],
    8911: [0, 0.54986, 0, 0, 0.76042],
    8912: [0.03517, 0.54986, 0, 0, 0.77778],
    8913: [0.03517, 0.54986, 0, 0, 0.77778],
    8914: [0, 0.54986, 0, 0, 0.66667],
    8915: [0, 0.54986, 0, 0, 0.66667],
    8916: [0, 0.69224, 0, 0, 0.66667],
    8918: [0.0391, 0.5391, 0, 0, 0.77778],
    8919: [0.0391, 0.5391, 0, 0, 0.77778],
    8920: [0.03517, 0.54986, 0, 0, 1.33334],
    8921: [0.03517, 0.54986, 0, 0, 1.33334],
    8922: [0.38569, 0.88569, 0, 0, 0.77778],
    8923: [0.38569, 0.88569, 0, 0, 0.77778],
    8926: [0.13667, 0.63667, 0, 0, 0.77778],
    8927: [0.13667, 0.63667, 0, 0, 0.77778],
    8928: [0.30274, 0.79383, 0, 0, 0.77778],
    8929: [0.30274, 0.79383, 0, 0, 0.77778],
    8934: [0.23222, 0.74111, 0, 0, 0.77778],
    8935: [0.23222, 0.74111, 0, 0, 0.77778],
    8936: [0.23222, 0.74111, 0, 0, 0.77778],
    8937: [0.23222, 0.74111, 0, 0, 0.77778],
    8938: [0.20576, 0.70576, 0, 0, 0.77778],
    8939: [0.20576, 0.70576, 0, 0, 0.77778],
    8940: [0.30274, 0.79383, 0, 0, 0.77778],
    8941: [0.30274, 0.79383, 0, 0, 0.77778],
    8994: [0.19444, 0.69224, 0, 0, 0.77778],
    8995: [0.19444, 0.69224, 0, 0, 0.77778],
    9416: [0.15559, 0.69224, 0, 0, 0.90222],
    9484: [0, 0.69224, 0, 0, 0.5],
    9488: [0, 0.69224, 0, 0, 0.5],
    9492: [0, 0.37788, 0, 0, 0.5],
    9496: [0, 0.37788, 0, 0, 0.5],
    9585: [0.19444, 0.68889, 0, 0, 0.88889],
    9586: [0.19444, 0.74111, 0, 0, 0.88889],
    9632: [0, 0.675, 0, 0, 0.77778],
    9633: [0, 0.675, 0, 0, 0.77778],
    9650: [0, 0.54986, 0, 0, 0.72222],
    9651: [0, 0.54986, 0, 0, 0.72222],
    9654: [0.03517, 0.54986, 0, 0, 0.77778],
    9660: [0, 0.54986, 0, 0, 0.72222],
    9661: [0, 0.54986, 0, 0, 0.72222],
    9664: [0.03517, 0.54986, 0, 0, 0.77778],
    9674: [0.11111, 0.69224, 0, 0, 0.66667],
    9733: [0.19444, 0.69224, 0, 0, 0.94445],
    10003: [0, 0.69224, 0, 0, 0.83334],
    10016: [0, 0.69224, 0, 0, 0.83334],
    10731: [0.11111, 0.69224, 0, 0, 0.66667],
    10846: [0.19444, 0.75583, 0, 0, 0.61111],
    10877: [0.13667, 0.63667, 0, 0, 0.77778],
    10878: [0.13667, 0.63667, 0, 0, 0.77778],
    10885: [0.25583, 0.75583, 0, 0, 0.77778],
    10886: [0.25583, 0.75583, 0, 0, 0.77778],
    10887: [0.13597, 0.63597, 0, 0, 0.77778],
    10888: [0.13597, 0.63597, 0, 0, 0.77778],
    10889: [0.26167, 0.75726, 0, 0, 0.77778],
    10890: [0.26167, 0.75726, 0, 0, 0.77778],
    10891: [0.48256, 0.98256, 0, 0, 0.77778],
    10892: [0.48256, 0.98256, 0, 0, 0.77778],
    10901: [0.13667, 0.63667, 0, 0, 0.77778],
    10902: [0.13667, 0.63667, 0, 0, 0.77778],
    10933: [0.25142, 0.75726, 0, 0, 0.77778],
    10934: [0.25142, 0.75726, 0, 0, 0.77778],
    10935: [0.26167, 0.75726, 0, 0, 0.77778],
    10936: [0.26167, 0.75726, 0, 0, 0.77778],
    10937: [0.26167, 0.75726, 0, 0, 0.77778],
    10938: [0.26167, 0.75726, 0, 0, 0.77778],
    10949: [0.25583, 0.75583, 0, 0, 0.77778],
    10950: [0.25583, 0.75583, 0, 0, 0.77778],
    10955: [0.28481, 0.79383, 0, 0, 0.77778],
    10956: [0.28481, 0.79383, 0, 0, 0.77778],
    57350: [0.08167, 0.58167, 0, 0, 0.22222],
    57351: [0.08167, 0.58167, 0, 0, 0.38889],
    57352: [0.08167, 0.58167, 0, 0, 0.77778],
    57353: [0, 0.43056, 0.04028, 0, 0.66667],
    57356: [0.25142, 0.75726, 0, 0, 0.77778],
    57357: [0.25142, 0.75726, 0, 0, 0.77778],
    57358: [0.41951, 0.91951, 0, 0, 0.77778],
    57359: [0.30274, 0.79383, 0, 0, 0.77778],
    57360: [0.30274, 0.79383, 0, 0, 0.77778],
    57361: [0.41951, 0.91951, 0, 0, 0.77778],
    57366: [0.25142, 0.75726, 0, 0, 0.77778],
    57367: [0.25142, 0.75726, 0, 0, 0.77778],
    57368: [0.25142, 0.75726, 0, 0, 0.77778],
    57369: [0.25142, 0.75726, 0, 0, 0.77778],
    57370: [0.13597, 0.63597, 0, 0, 0.77778],
    57371: [0.13597, 0.63597, 0, 0, 0.77778]
  },
  "Caligraphic-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.68333, 0, 0.19445, 0.79847],
    66: [0, 0.68333, 0.03041, 0.13889, 0.65681],
    67: [0, 0.68333, 0.05834, 0.13889, 0.52653],
    68: [0, 0.68333, 0.02778, 0.08334, 0.77139],
    69: [0, 0.68333, 0.08944, 0.11111, 0.52778],
    70: [0, 0.68333, 0.09931, 0.11111, 0.71875],
    71: [0.09722, 0.68333, 0.0593, 0.11111, 0.59487],
    72: [0, 0.68333, 965e-5, 0.11111, 0.84452],
    73: [0, 0.68333, 0.07382, 0, 0.54452],
    74: [0.09722, 0.68333, 0.18472, 0.16667, 0.67778],
    75: [0, 0.68333, 0.01445, 0.05556, 0.76195],
    76: [0, 0.68333, 0, 0.13889, 0.68972],
    77: [0, 0.68333, 0, 0.13889, 1.2009],
    78: [0, 0.68333, 0.14736, 0.08334, 0.82049],
    79: [0, 0.68333, 0.02778, 0.11111, 0.79611],
    80: [0, 0.68333, 0.08222, 0.08334, 0.69556],
    81: [0.09722, 0.68333, 0, 0.11111, 0.81667],
    82: [0, 0.68333, 0, 0.08334, 0.8475],
    83: [0, 0.68333, 0.075, 0.13889, 0.60556],
    84: [0, 0.68333, 0.25417, 0, 0.54464],
    85: [0, 0.68333, 0.09931, 0.08334, 0.62583],
    86: [0, 0.68333, 0.08222, 0, 0.61278],
    87: [0, 0.68333, 0.08222, 0.08334, 0.98778],
    88: [0, 0.68333, 0.14643, 0.13889, 0.7133],
    89: [0.09722, 0.68333, 0.08222, 0.08334, 0.66834],
    90: [0, 0.68333, 0.07944, 0.13889, 0.72473],
    160: [0, 0, 0, 0, 0.25]
  },
  "Fraktur-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69141, 0, 0, 0.29574],
    34: [0, 0.69141, 0, 0, 0.21471],
    38: [0, 0.69141, 0, 0, 0.73786],
    39: [0, 0.69141, 0, 0, 0.21201],
    40: [0.24982, 0.74947, 0, 0, 0.38865],
    41: [0.24982, 0.74947, 0, 0, 0.38865],
    42: [0, 0.62119, 0, 0, 0.27764],
    43: [0.08319, 0.58283, 0, 0, 0.75623],
    44: [0, 0.10803, 0, 0, 0.27764],
    45: [0.08319, 0.58283, 0, 0, 0.75623],
    46: [0, 0.10803, 0, 0, 0.27764],
    47: [0.24982, 0.74947, 0, 0, 0.50181],
    48: [0, 0.47534, 0, 0, 0.50181],
    49: [0, 0.47534, 0, 0, 0.50181],
    50: [0, 0.47534, 0, 0, 0.50181],
    51: [0.18906, 0.47534, 0, 0, 0.50181],
    52: [0.18906, 0.47534, 0, 0, 0.50181],
    53: [0.18906, 0.47534, 0, 0, 0.50181],
    54: [0, 0.69141, 0, 0, 0.50181],
    55: [0.18906, 0.47534, 0, 0, 0.50181],
    56: [0, 0.69141, 0, 0, 0.50181],
    57: [0.18906, 0.47534, 0, 0, 0.50181],
    58: [0, 0.47534, 0, 0, 0.21606],
    59: [0.12604, 0.47534, 0, 0, 0.21606],
    61: [-0.13099, 0.36866, 0, 0, 0.75623],
    63: [0, 0.69141, 0, 0, 0.36245],
    65: [0, 0.69141, 0, 0, 0.7176],
    66: [0, 0.69141, 0, 0, 0.88397],
    67: [0, 0.69141, 0, 0, 0.61254],
    68: [0, 0.69141, 0, 0, 0.83158],
    69: [0, 0.69141, 0, 0, 0.66278],
    70: [0.12604, 0.69141, 0, 0, 0.61119],
    71: [0, 0.69141, 0, 0, 0.78539],
    72: [0.06302, 0.69141, 0, 0, 0.7203],
    73: [0, 0.69141, 0, 0, 0.55448],
    74: [0.12604, 0.69141, 0, 0, 0.55231],
    75: [0, 0.69141, 0, 0, 0.66845],
    76: [0, 0.69141, 0, 0, 0.66602],
    77: [0, 0.69141, 0, 0, 1.04953],
    78: [0, 0.69141, 0, 0, 0.83212],
    79: [0, 0.69141, 0, 0, 0.82699],
    80: [0.18906, 0.69141, 0, 0, 0.82753],
    81: [0.03781, 0.69141, 0, 0, 0.82699],
    82: [0, 0.69141, 0, 0, 0.82807],
    83: [0, 0.69141, 0, 0, 0.82861],
    84: [0, 0.69141, 0, 0, 0.66899],
    85: [0, 0.69141, 0, 0, 0.64576],
    86: [0, 0.69141, 0, 0, 0.83131],
    87: [0, 0.69141, 0, 0, 1.04602],
    88: [0, 0.69141, 0, 0, 0.71922],
    89: [0.18906, 0.69141, 0, 0, 0.83293],
    90: [0.12604, 0.69141, 0, 0, 0.60201],
    91: [0.24982, 0.74947, 0, 0, 0.27764],
    93: [0.24982, 0.74947, 0, 0, 0.27764],
    94: [0, 0.69141, 0, 0, 0.49965],
    97: [0, 0.47534, 0, 0, 0.50046],
    98: [0, 0.69141, 0, 0, 0.51315],
    99: [0, 0.47534, 0, 0, 0.38946],
    100: [0, 0.62119, 0, 0, 0.49857],
    101: [0, 0.47534, 0, 0, 0.40053],
    102: [0.18906, 0.69141, 0, 0, 0.32626],
    103: [0.18906, 0.47534, 0, 0, 0.5037],
    104: [0.18906, 0.69141, 0, 0, 0.52126],
    105: [0, 0.69141, 0, 0, 0.27899],
    106: [0, 0.69141, 0, 0, 0.28088],
    107: [0, 0.69141, 0, 0, 0.38946],
    108: [0, 0.69141, 0, 0, 0.27953],
    109: [0, 0.47534, 0, 0, 0.76676],
    110: [0, 0.47534, 0, 0, 0.52666],
    111: [0, 0.47534, 0, 0, 0.48885],
    112: [0.18906, 0.52396, 0, 0, 0.50046],
    113: [0.18906, 0.47534, 0, 0, 0.48912],
    114: [0, 0.47534, 0, 0, 0.38919],
    115: [0, 0.47534, 0, 0, 0.44266],
    116: [0, 0.62119, 0, 0, 0.33301],
    117: [0, 0.47534, 0, 0, 0.5172],
    118: [0, 0.52396, 0, 0, 0.5118],
    119: [0, 0.52396, 0, 0, 0.77351],
    120: [0.18906, 0.47534, 0, 0, 0.38865],
    121: [0.18906, 0.47534, 0, 0, 0.49884],
    122: [0.18906, 0.47534, 0, 0, 0.39054],
    160: [0, 0, 0, 0, 0.25],
    8216: [0, 0.69141, 0, 0, 0.21471],
    8217: [0, 0.69141, 0, 0, 0.21471],
    58112: [0, 0.62119, 0, 0, 0.49749],
    58113: [0, 0.62119, 0, 0, 0.4983],
    58114: [0.18906, 0.69141, 0, 0, 0.33328],
    58115: [0.18906, 0.69141, 0, 0, 0.32923],
    58116: [0.18906, 0.47534, 0, 0, 0.50343],
    58117: [0, 0.69141, 0, 0, 0.33301],
    58118: [0, 0.62119, 0, 0, 0.33409],
    58119: [0, 0.47534, 0, 0, 0.50073]
  },
  "Main-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.35],
    34: [0, 0.69444, 0, 0, 0.60278],
    35: [0.19444, 0.69444, 0, 0, 0.95833],
    36: [0.05556, 0.75, 0, 0, 0.575],
    37: [0.05556, 0.75, 0, 0, 0.95833],
    38: [0, 0.69444, 0, 0, 0.89444],
    39: [0, 0.69444, 0, 0, 0.31944],
    40: [0.25, 0.75, 0, 0, 0.44722],
    41: [0.25, 0.75, 0, 0, 0.44722],
    42: [0, 0.75, 0, 0, 0.575],
    43: [0.13333, 0.63333, 0, 0, 0.89444],
    44: [0.19444, 0.15556, 0, 0, 0.31944],
    45: [0, 0.44444, 0, 0, 0.38333],
    46: [0, 0.15556, 0, 0, 0.31944],
    47: [0.25, 0.75, 0, 0, 0.575],
    48: [0, 0.64444, 0, 0, 0.575],
    49: [0, 0.64444, 0, 0, 0.575],
    50: [0, 0.64444, 0, 0, 0.575],
    51: [0, 0.64444, 0, 0, 0.575],
    52: [0, 0.64444, 0, 0, 0.575],
    53: [0, 0.64444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0, 0.64444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0, 0.64444, 0, 0, 0.575],
    58: [0, 0.44444, 0, 0, 0.31944],
    59: [0.19444, 0.44444, 0, 0, 0.31944],
    60: [0.08556, 0.58556, 0, 0, 0.89444],
    61: [-0.10889, 0.39111, 0, 0, 0.89444],
    62: [0.08556, 0.58556, 0, 0, 0.89444],
    63: [0, 0.69444, 0, 0, 0.54305],
    64: [0, 0.69444, 0, 0, 0.89444],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0, 0, 0.81805],
    67: [0, 0.68611, 0, 0, 0.83055],
    68: [0, 0.68611, 0, 0, 0.88194],
    69: [0, 0.68611, 0, 0, 0.75555],
    70: [0, 0.68611, 0, 0, 0.72361],
    71: [0, 0.68611, 0, 0, 0.90416],
    72: [0, 0.68611, 0, 0, 0.9],
    73: [0, 0.68611, 0, 0, 0.43611],
    74: [0, 0.68611, 0, 0, 0.59444],
    75: [0, 0.68611, 0, 0, 0.90138],
    76: [0, 0.68611, 0, 0, 0.69166],
    77: [0, 0.68611, 0, 0, 1.09166],
    78: [0, 0.68611, 0, 0, 0.9],
    79: [0, 0.68611, 0, 0, 0.86388],
    80: [0, 0.68611, 0, 0, 0.78611],
    81: [0.19444, 0.68611, 0, 0, 0.86388],
    82: [0, 0.68611, 0, 0, 0.8625],
    83: [0, 0.68611, 0, 0, 0.63889],
    84: [0, 0.68611, 0, 0, 0.8],
    85: [0, 0.68611, 0, 0, 0.88472],
    86: [0, 0.68611, 0.01597, 0, 0.86944],
    87: [0, 0.68611, 0.01597, 0, 1.18888],
    88: [0, 0.68611, 0, 0, 0.86944],
    89: [0, 0.68611, 0.02875, 0, 0.86944],
    90: [0, 0.68611, 0, 0, 0.70277],
    91: [0.25, 0.75, 0, 0, 0.31944],
    92: [0.25, 0.75, 0, 0, 0.575],
    93: [0.25, 0.75, 0, 0, 0.31944],
    94: [0, 0.69444, 0, 0, 0.575],
    95: [0.31, 0.13444, 0.03194, 0, 0.575],
    97: [0, 0.44444, 0, 0, 0.55902],
    98: [0, 0.69444, 0, 0, 0.63889],
    99: [0, 0.44444, 0, 0, 0.51111],
    100: [0, 0.69444, 0, 0, 0.63889],
    101: [0, 0.44444, 0, 0, 0.52708],
    102: [0, 0.69444, 0.10903, 0, 0.35139],
    103: [0.19444, 0.44444, 0.01597, 0, 0.575],
    104: [0, 0.69444, 0, 0, 0.63889],
    105: [0, 0.69444, 0, 0, 0.31944],
    106: [0.19444, 0.69444, 0, 0, 0.35139],
    107: [0, 0.69444, 0, 0, 0.60694],
    108: [0, 0.69444, 0, 0, 0.31944],
    109: [0, 0.44444, 0, 0, 0.95833],
    110: [0, 0.44444, 0, 0, 0.63889],
    111: [0, 0.44444, 0, 0, 0.575],
    112: [0.19444, 0.44444, 0, 0, 0.63889],
    113: [0.19444, 0.44444, 0, 0, 0.60694],
    114: [0, 0.44444, 0, 0, 0.47361],
    115: [0, 0.44444, 0, 0, 0.45361],
    116: [0, 0.63492, 0, 0, 0.44722],
    117: [0, 0.44444, 0, 0, 0.63889],
    118: [0, 0.44444, 0.01597, 0, 0.60694],
    119: [0, 0.44444, 0.01597, 0, 0.83055],
    120: [0, 0.44444, 0, 0, 0.60694],
    121: [0.19444, 0.44444, 0.01597, 0, 0.60694],
    122: [0, 0.44444, 0, 0, 0.51111],
    123: [0.25, 0.75, 0, 0, 0.575],
    124: [0.25, 0.75, 0, 0, 0.31944],
    125: [0.25, 0.75, 0, 0, 0.575],
    126: [0.35, 0.34444, 0, 0, 0.575],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.86853],
    168: [0, 0.69444, 0, 0, 0.575],
    172: [0, 0.44444, 0, 0, 0.76666],
    176: [0, 0.69444, 0, 0, 0.86944],
    177: [0.13333, 0.63333, 0, 0, 0.89444],
    184: [0.17014, 0, 0, 0, 0.51111],
    198: [0, 0.68611, 0, 0, 1.04166],
    215: [0.13333, 0.63333, 0, 0, 0.89444],
    216: [0.04861, 0.73472, 0, 0, 0.89444],
    223: [0, 0.69444, 0, 0, 0.59722],
    230: [0, 0.44444, 0, 0, 0.83055],
    247: [0.13333, 0.63333, 0, 0, 0.89444],
    248: [0.09722, 0.54167, 0, 0, 0.575],
    305: [0, 0.44444, 0, 0, 0.31944],
    338: [0, 0.68611, 0, 0, 1.16944],
    339: [0, 0.44444, 0, 0, 0.89444],
    567: [0.19444, 0.44444, 0, 0, 0.35139],
    710: [0, 0.69444, 0, 0, 0.575],
    711: [0, 0.63194, 0, 0, 0.575],
    713: [0, 0.59611, 0, 0, 0.575],
    714: [0, 0.69444, 0, 0, 0.575],
    715: [0, 0.69444, 0, 0, 0.575],
    728: [0, 0.69444, 0, 0, 0.575],
    729: [0, 0.69444, 0, 0, 0.31944],
    730: [0, 0.69444, 0, 0, 0.86944],
    732: [0, 0.69444, 0, 0, 0.575],
    733: [0, 0.69444, 0, 0, 0.575],
    915: [0, 0.68611, 0, 0, 0.69166],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0, 0, 0.89444],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0, 0, 0.76666],
    928: [0, 0.68611, 0, 0, 0.9],
    931: [0, 0.68611, 0, 0, 0.83055],
    933: [0, 0.68611, 0, 0, 0.89444],
    934: [0, 0.68611, 0, 0, 0.83055],
    936: [0, 0.68611, 0, 0, 0.89444],
    937: [0, 0.68611, 0, 0, 0.83055],
    8211: [0, 0.44444, 0.03194, 0, 0.575],
    8212: [0, 0.44444, 0.03194, 0, 1.14999],
    8216: [0, 0.69444, 0, 0, 0.31944],
    8217: [0, 0.69444, 0, 0, 0.31944],
    8220: [0, 0.69444, 0, 0, 0.60278],
    8221: [0, 0.69444, 0, 0, 0.60278],
    8224: [0.19444, 0.69444, 0, 0, 0.51111],
    8225: [0.19444, 0.69444, 0, 0, 0.51111],
    8242: [0, 0.55556, 0, 0, 0.34444],
    8407: [0, 0.72444, 0.15486, 0, 0.575],
    8463: [0, 0.69444, 0, 0, 0.66759],
    8465: [0, 0.69444, 0, 0, 0.83055],
    8467: [0, 0.69444, 0, 0, 0.47361],
    8472: [0.19444, 0.44444, 0, 0, 0.74027],
    8476: [0, 0.69444, 0, 0, 0.83055],
    8501: [0, 0.69444, 0, 0, 0.70277],
    8592: [-0.10889, 0.39111, 0, 0, 1.14999],
    8593: [0.19444, 0.69444, 0, 0, 0.575],
    8594: [-0.10889, 0.39111, 0, 0, 1.14999],
    8595: [0.19444, 0.69444, 0, 0, 0.575],
    8596: [-0.10889, 0.39111, 0, 0, 1.14999],
    8597: [0.25, 0.75, 0, 0, 0.575],
    8598: [0.19444, 0.69444, 0, 0, 1.14999],
    8599: [0.19444, 0.69444, 0, 0, 1.14999],
    8600: [0.19444, 0.69444, 0, 0, 1.14999],
    8601: [0.19444, 0.69444, 0, 0, 1.14999],
    8636: [-0.10889, 0.39111, 0, 0, 1.14999],
    8637: [-0.10889, 0.39111, 0, 0, 1.14999],
    8640: [-0.10889, 0.39111, 0, 0, 1.14999],
    8641: [-0.10889, 0.39111, 0, 0, 1.14999],
    8656: [-0.10889, 0.39111, 0, 0, 1.14999],
    8657: [0.19444, 0.69444, 0, 0, 0.70277],
    8658: [-0.10889, 0.39111, 0, 0, 1.14999],
    8659: [0.19444, 0.69444, 0, 0, 0.70277],
    8660: [-0.10889, 0.39111, 0, 0, 1.14999],
    8661: [0.25, 0.75, 0, 0, 0.70277],
    8704: [0, 0.69444, 0, 0, 0.63889],
    8706: [0, 0.69444, 0.06389, 0, 0.62847],
    8707: [0, 0.69444, 0, 0, 0.63889],
    8709: [0.05556, 0.75, 0, 0, 0.575],
    8711: [0, 0.68611, 0, 0, 0.95833],
    8712: [0.08556, 0.58556, 0, 0, 0.76666],
    8715: [0.08556, 0.58556, 0, 0, 0.76666],
    8722: [0.13333, 0.63333, 0, 0, 0.89444],
    8723: [0.13333, 0.63333, 0, 0, 0.89444],
    8725: [0.25, 0.75, 0, 0, 0.575],
    8726: [0.25, 0.75, 0, 0, 0.575],
    8727: [-0.02778, 0.47222, 0, 0, 0.575],
    8728: [-0.02639, 0.47361, 0, 0, 0.575],
    8729: [-0.02639, 0.47361, 0, 0, 0.575],
    8730: [0.18, 0.82, 0, 0, 0.95833],
    8733: [0, 0.44444, 0, 0, 0.89444],
    8734: [0, 0.44444, 0, 0, 1.14999],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.31944],
    8741: [0.25, 0.75, 0, 0, 0.575],
    8743: [0, 0.55556, 0, 0, 0.76666],
    8744: [0, 0.55556, 0, 0, 0.76666],
    8745: [0, 0.55556, 0, 0, 0.76666],
    8746: [0, 0.55556, 0, 0, 0.76666],
    8747: [0.19444, 0.69444, 0.12778, 0, 0.56875],
    8764: [-0.10889, 0.39111, 0, 0, 0.89444],
    8768: [0.19444, 0.69444, 0, 0, 0.31944],
    8771: [222e-5, 0.50222, 0, 0, 0.89444],
    8773: [0.027, 0.638, 0, 0, 0.894],
    8776: [0.02444, 0.52444, 0, 0, 0.89444],
    8781: [222e-5, 0.50222, 0, 0, 0.89444],
    8801: [222e-5, 0.50222, 0, 0, 0.89444],
    8804: [0.19667, 0.69667, 0, 0, 0.89444],
    8805: [0.19667, 0.69667, 0, 0, 0.89444],
    8810: [0.08556, 0.58556, 0, 0, 1.14999],
    8811: [0.08556, 0.58556, 0, 0, 1.14999],
    8826: [0.08556, 0.58556, 0, 0, 0.89444],
    8827: [0.08556, 0.58556, 0, 0, 0.89444],
    8834: [0.08556, 0.58556, 0, 0, 0.89444],
    8835: [0.08556, 0.58556, 0, 0, 0.89444],
    8838: [0.19667, 0.69667, 0, 0, 0.89444],
    8839: [0.19667, 0.69667, 0, 0, 0.89444],
    8846: [0, 0.55556, 0, 0, 0.76666],
    8849: [0.19667, 0.69667, 0, 0, 0.89444],
    8850: [0.19667, 0.69667, 0, 0, 0.89444],
    8851: [0, 0.55556, 0, 0, 0.76666],
    8852: [0, 0.55556, 0, 0, 0.76666],
    8853: [0.13333, 0.63333, 0, 0, 0.89444],
    8854: [0.13333, 0.63333, 0, 0, 0.89444],
    8855: [0.13333, 0.63333, 0, 0, 0.89444],
    8856: [0.13333, 0.63333, 0, 0, 0.89444],
    8857: [0.13333, 0.63333, 0, 0, 0.89444],
    8866: [0, 0.69444, 0, 0, 0.70277],
    8867: [0, 0.69444, 0, 0, 0.70277],
    8868: [0, 0.69444, 0, 0, 0.89444],
    8869: [0, 0.69444, 0, 0, 0.89444],
    8900: [-0.02639, 0.47361, 0, 0, 0.575],
    8901: [-0.02639, 0.47361, 0, 0, 0.31944],
    8902: [-0.02778, 0.47222, 0, 0, 0.575],
    8968: [0.25, 0.75, 0, 0, 0.51111],
    8969: [0.25, 0.75, 0, 0, 0.51111],
    8970: [0.25, 0.75, 0, 0, 0.51111],
    8971: [0.25, 0.75, 0, 0, 0.51111],
    8994: [-0.13889, 0.36111, 0, 0, 1.14999],
    8995: [-0.13889, 0.36111, 0, 0, 1.14999],
    9651: [0.19444, 0.69444, 0, 0, 1.02222],
    9657: [-0.02778, 0.47222, 0, 0, 0.575],
    9661: [0.19444, 0.69444, 0, 0, 1.02222],
    9667: [-0.02778, 0.47222, 0, 0, 0.575],
    9711: [0.19444, 0.69444, 0, 0, 1.14999],
    9824: [0.12963, 0.69444, 0, 0, 0.89444],
    9825: [0.12963, 0.69444, 0, 0, 0.89444],
    9826: [0.12963, 0.69444, 0, 0, 0.89444],
    9827: [0.12963, 0.69444, 0, 0, 0.89444],
    9837: [0, 0.75, 0, 0, 0.44722],
    9838: [0.19444, 0.69444, 0, 0, 0.44722],
    9839: [0.19444, 0.69444, 0, 0, 0.44722],
    10216: [0.25, 0.75, 0, 0, 0.44722],
    10217: [0.25, 0.75, 0, 0, 0.44722],
    10815: [0, 0.68611, 0, 0, 0.9],
    10927: [0.19667, 0.69667, 0, 0, 0.89444],
    10928: [0.19667, 0.69667, 0, 0, 0.89444],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Main-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.11417, 0, 0.38611],
    34: [0, 0.69444, 0.07939, 0, 0.62055],
    35: [0.19444, 0.69444, 0.06833, 0, 0.94444],
    37: [0.05556, 0.75, 0.12861, 0, 0.94444],
    38: [0, 0.69444, 0.08528, 0, 0.88555],
    39: [0, 0.69444, 0.12945, 0, 0.35555],
    40: [0.25, 0.75, 0.15806, 0, 0.47333],
    41: [0.25, 0.75, 0.03306, 0, 0.47333],
    42: [0, 0.75, 0.14333, 0, 0.59111],
    43: [0.10333, 0.60333, 0.03306, 0, 0.88555],
    44: [0.19444, 0.14722, 0, 0, 0.35555],
    45: [0, 0.44444, 0.02611, 0, 0.41444],
    46: [0, 0.14722, 0, 0, 0.35555],
    47: [0.25, 0.75, 0.15806, 0, 0.59111],
    48: [0, 0.64444, 0.13167, 0, 0.59111],
    49: [0, 0.64444, 0.13167, 0, 0.59111],
    50: [0, 0.64444, 0.13167, 0, 0.59111],
    51: [0, 0.64444, 0.13167, 0, 0.59111],
    52: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    53: [0, 0.64444, 0.13167, 0, 0.59111],
    54: [0, 0.64444, 0.13167, 0, 0.59111],
    55: [0.19444, 0.64444, 0.13167, 0, 0.59111],
    56: [0, 0.64444, 0.13167, 0, 0.59111],
    57: [0, 0.64444, 0.13167, 0, 0.59111],
    58: [0, 0.44444, 0.06695, 0, 0.35555],
    59: [0.19444, 0.44444, 0.06695, 0, 0.35555],
    61: [-0.10889, 0.39111, 0.06833, 0, 0.88555],
    63: [0, 0.69444, 0.11472, 0, 0.59111],
    64: [0, 0.69444, 0.09208, 0, 0.88555],
    65: [0, 0.68611, 0, 0, 0.86555],
    66: [0, 0.68611, 0.0992, 0, 0.81666],
    67: [0, 0.68611, 0.14208, 0, 0.82666],
    68: [0, 0.68611, 0.09062, 0, 0.87555],
    69: [0, 0.68611, 0.11431, 0, 0.75666],
    70: [0, 0.68611, 0.12903, 0, 0.72722],
    71: [0, 0.68611, 0.07347, 0, 0.89527],
    72: [0, 0.68611, 0.17208, 0, 0.8961],
    73: [0, 0.68611, 0.15681, 0, 0.47166],
    74: [0, 0.68611, 0.145, 0, 0.61055],
    75: [0, 0.68611, 0.14208, 0, 0.89499],
    76: [0, 0.68611, 0, 0, 0.69777],
    77: [0, 0.68611, 0.17208, 0, 1.07277],
    78: [0, 0.68611, 0.17208, 0, 0.8961],
    79: [0, 0.68611, 0.09062, 0, 0.85499],
    80: [0, 0.68611, 0.0992, 0, 0.78721],
    81: [0.19444, 0.68611, 0.09062, 0, 0.85499],
    82: [0, 0.68611, 0.02559, 0, 0.85944],
    83: [0, 0.68611, 0.11264, 0, 0.64999],
    84: [0, 0.68611, 0.12903, 0, 0.7961],
    85: [0, 0.68611, 0.17208, 0, 0.88083],
    86: [0, 0.68611, 0.18625, 0, 0.86555],
    87: [0, 0.68611, 0.18625, 0, 1.15999],
    88: [0, 0.68611, 0.15681, 0, 0.86555],
    89: [0, 0.68611, 0.19803, 0, 0.86555],
    90: [0, 0.68611, 0.14208, 0, 0.70888],
    91: [0.25, 0.75, 0.1875, 0, 0.35611],
    93: [0.25, 0.75, 0.09972, 0, 0.35611],
    94: [0, 0.69444, 0.06709, 0, 0.59111],
    95: [0.31, 0.13444, 0.09811, 0, 0.59111],
    97: [0, 0.44444, 0.09426, 0, 0.59111],
    98: [0, 0.69444, 0.07861, 0, 0.53222],
    99: [0, 0.44444, 0.05222, 0, 0.53222],
    100: [0, 0.69444, 0.10861, 0, 0.59111],
    101: [0, 0.44444, 0.085, 0, 0.53222],
    102: [0.19444, 0.69444, 0.21778, 0, 0.4],
    103: [0.19444, 0.44444, 0.105, 0, 0.53222],
    104: [0, 0.69444, 0.09426, 0, 0.59111],
    105: [0, 0.69326, 0.11387, 0, 0.35555],
    106: [0.19444, 0.69326, 0.1672, 0, 0.35555],
    107: [0, 0.69444, 0.11111, 0, 0.53222],
    108: [0, 0.69444, 0.10861, 0, 0.29666],
    109: [0, 0.44444, 0.09426, 0, 0.94444],
    110: [0, 0.44444, 0.09426, 0, 0.64999],
    111: [0, 0.44444, 0.07861, 0, 0.59111],
    112: [0.19444, 0.44444, 0.07861, 0, 0.59111],
    113: [0.19444, 0.44444, 0.105, 0, 0.53222],
    114: [0, 0.44444, 0.11111, 0, 0.50167],
    115: [0, 0.44444, 0.08167, 0, 0.48694],
    116: [0, 0.63492, 0.09639, 0, 0.385],
    117: [0, 0.44444, 0.09426, 0, 0.62055],
    118: [0, 0.44444, 0.11111, 0, 0.53222],
    119: [0, 0.44444, 0.11111, 0, 0.76777],
    120: [0, 0.44444, 0.12583, 0, 0.56055],
    121: [0.19444, 0.44444, 0.105, 0, 0.56166],
    122: [0, 0.44444, 0.13889, 0, 0.49055],
    126: [0.35, 0.34444, 0.11472, 0, 0.59111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0.11473, 0, 0.59111],
    176: [0, 0.69444, 0, 0, 0.94888],
    184: [0.17014, 0, 0, 0, 0.53222],
    198: [0, 0.68611, 0.11431, 0, 1.02277],
    216: [0.04861, 0.73472, 0.09062, 0, 0.88555],
    223: [0.19444, 0.69444, 0.09736, 0, 0.665],
    230: [0, 0.44444, 0.085, 0, 0.82666],
    248: [0.09722, 0.54167, 0.09458, 0, 0.59111],
    305: [0, 0.44444, 0.09426, 0, 0.35555],
    338: [0, 0.68611, 0.11431, 0, 1.14054],
    339: [0, 0.44444, 0.085, 0, 0.82666],
    567: [0.19444, 0.44444, 0.04611, 0, 0.385],
    710: [0, 0.69444, 0.06709, 0, 0.59111],
    711: [0, 0.63194, 0.08271, 0, 0.59111],
    713: [0, 0.59444, 0.10444, 0, 0.59111],
    714: [0, 0.69444, 0.08528, 0, 0.59111],
    715: [0, 0.69444, 0, 0, 0.59111],
    728: [0, 0.69444, 0.10333, 0, 0.59111],
    729: [0, 0.69444, 0.12945, 0, 0.35555],
    730: [0, 0.69444, 0, 0, 0.94888],
    732: [0, 0.69444, 0.11472, 0, 0.59111],
    733: [0, 0.69444, 0.11472, 0, 0.59111],
    915: [0, 0.68611, 0.12903, 0, 0.69777],
    916: [0, 0.68611, 0, 0, 0.94444],
    920: [0, 0.68611, 0.09062, 0, 0.88555],
    923: [0, 0.68611, 0, 0, 0.80666],
    926: [0, 0.68611, 0.15092, 0, 0.76777],
    928: [0, 0.68611, 0.17208, 0, 0.8961],
    931: [0, 0.68611, 0.11431, 0, 0.82666],
    933: [0, 0.68611, 0.10778, 0, 0.88555],
    934: [0, 0.68611, 0.05632, 0, 0.82666],
    936: [0, 0.68611, 0.10778, 0, 0.88555],
    937: [0, 0.68611, 0.0992, 0, 0.82666],
    8211: [0, 0.44444, 0.09811, 0, 0.59111],
    8212: [0, 0.44444, 0.09811, 0, 1.18221],
    8216: [0, 0.69444, 0.12945, 0, 0.35555],
    8217: [0, 0.69444, 0.12945, 0, 0.35555],
    8220: [0, 0.69444, 0.16772, 0, 0.62055],
    8221: [0, 0.69444, 0.07939, 0, 0.62055]
  },
  "Main-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.12417, 0, 0.30667],
    34: [0, 0.69444, 0.06961, 0, 0.51444],
    35: [0.19444, 0.69444, 0.06616, 0, 0.81777],
    37: [0.05556, 0.75, 0.13639, 0, 0.81777],
    38: [0, 0.69444, 0.09694, 0, 0.76666],
    39: [0, 0.69444, 0.12417, 0, 0.30667],
    40: [0.25, 0.75, 0.16194, 0, 0.40889],
    41: [0.25, 0.75, 0.03694, 0, 0.40889],
    42: [0, 0.75, 0.14917, 0, 0.51111],
    43: [0.05667, 0.56167, 0.03694, 0, 0.76666],
    44: [0.19444, 0.10556, 0, 0, 0.30667],
    45: [0, 0.43056, 0.02826, 0, 0.35778],
    46: [0, 0.10556, 0, 0, 0.30667],
    47: [0.25, 0.75, 0.16194, 0, 0.51111],
    48: [0, 0.64444, 0.13556, 0, 0.51111],
    49: [0, 0.64444, 0.13556, 0, 0.51111],
    50: [0, 0.64444, 0.13556, 0, 0.51111],
    51: [0, 0.64444, 0.13556, 0, 0.51111],
    52: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    53: [0, 0.64444, 0.13556, 0, 0.51111],
    54: [0, 0.64444, 0.13556, 0, 0.51111],
    55: [0.19444, 0.64444, 0.13556, 0, 0.51111],
    56: [0, 0.64444, 0.13556, 0, 0.51111],
    57: [0, 0.64444, 0.13556, 0, 0.51111],
    58: [0, 0.43056, 0.0582, 0, 0.30667],
    59: [0.19444, 0.43056, 0.0582, 0, 0.30667],
    61: [-0.13313, 0.36687, 0.06616, 0, 0.76666],
    63: [0, 0.69444, 0.1225, 0, 0.51111],
    64: [0, 0.69444, 0.09597, 0, 0.76666],
    65: [0, 0.68333, 0, 0, 0.74333],
    66: [0, 0.68333, 0.10257, 0, 0.70389],
    67: [0, 0.68333, 0.14528, 0, 0.71555],
    68: [0, 0.68333, 0.09403, 0, 0.755],
    69: [0, 0.68333, 0.12028, 0, 0.67833],
    70: [0, 0.68333, 0.13305, 0, 0.65277],
    71: [0, 0.68333, 0.08722, 0, 0.77361],
    72: [0, 0.68333, 0.16389, 0, 0.74333],
    73: [0, 0.68333, 0.15806, 0, 0.38555],
    74: [0, 0.68333, 0.14028, 0, 0.525],
    75: [0, 0.68333, 0.14528, 0, 0.76888],
    76: [0, 0.68333, 0, 0, 0.62722],
    77: [0, 0.68333, 0.16389, 0, 0.89666],
    78: [0, 0.68333, 0.16389, 0, 0.74333],
    79: [0, 0.68333, 0.09403, 0, 0.76666],
    80: [0, 0.68333, 0.10257, 0, 0.67833],
    81: [0.19444, 0.68333, 0.09403, 0, 0.76666],
    82: [0, 0.68333, 0.03868, 0, 0.72944],
    83: [0, 0.68333, 0.11972, 0, 0.56222],
    84: [0, 0.68333, 0.13305, 0, 0.71555],
    85: [0, 0.68333, 0.16389, 0, 0.74333],
    86: [0, 0.68333, 0.18361, 0, 0.74333],
    87: [0, 0.68333, 0.18361, 0, 0.99888],
    88: [0, 0.68333, 0.15806, 0, 0.74333],
    89: [0, 0.68333, 0.19383, 0, 0.74333],
    90: [0, 0.68333, 0.14528, 0, 0.61333],
    91: [0.25, 0.75, 0.1875, 0, 0.30667],
    93: [0.25, 0.75, 0.10528, 0, 0.30667],
    94: [0, 0.69444, 0.06646, 0, 0.51111],
    95: [0.31, 0.12056, 0.09208, 0, 0.51111],
    97: [0, 0.43056, 0.07671, 0, 0.51111],
    98: [0, 0.69444, 0.06312, 0, 0.46],
    99: [0, 0.43056, 0.05653, 0, 0.46],
    100: [0, 0.69444, 0.10333, 0, 0.51111],
    101: [0, 0.43056, 0.07514, 0, 0.46],
    102: [0.19444, 0.69444, 0.21194, 0, 0.30667],
    103: [0.19444, 0.43056, 0.08847, 0, 0.46],
    104: [0, 0.69444, 0.07671, 0, 0.51111],
    105: [0, 0.65536, 0.1019, 0, 0.30667],
    106: [0.19444, 0.65536, 0.14467, 0, 0.30667],
    107: [0, 0.69444, 0.10764, 0, 0.46],
    108: [0, 0.69444, 0.10333, 0, 0.25555],
    109: [0, 0.43056, 0.07671, 0, 0.81777],
    110: [0, 0.43056, 0.07671, 0, 0.56222],
    111: [0, 0.43056, 0.06312, 0, 0.51111],
    112: [0.19444, 0.43056, 0.06312, 0, 0.51111],
    113: [0.19444, 0.43056, 0.08847, 0, 0.46],
    114: [0, 0.43056, 0.10764, 0, 0.42166],
    115: [0, 0.43056, 0.08208, 0, 0.40889],
    116: [0, 0.61508, 0.09486, 0, 0.33222],
    117: [0, 0.43056, 0.07671, 0, 0.53666],
    118: [0, 0.43056, 0.10764, 0, 0.46],
    119: [0, 0.43056, 0.10764, 0, 0.66444],
    120: [0, 0.43056, 0.12042, 0, 0.46389],
    121: [0.19444, 0.43056, 0.08847, 0, 0.48555],
    122: [0, 0.43056, 0.12292, 0, 0.40889],
    126: [0.35, 0.31786, 0.11585, 0, 0.51111],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.66786, 0.10474, 0, 0.51111],
    176: [0, 0.69444, 0, 0, 0.83129],
    184: [0.17014, 0, 0, 0, 0.46],
    198: [0, 0.68333, 0.12028, 0, 0.88277],
    216: [0.04861, 0.73194, 0.09403, 0, 0.76666],
    223: [0.19444, 0.69444, 0.10514, 0, 0.53666],
    230: [0, 0.43056, 0.07514, 0, 0.71555],
    248: [0.09722, 0.52778, 0.09194, 0, 0.51111],
    338: [0, 0.68333, 0.12028, 0, 0.98499],
    339: [0, 0.43056, 0.07514, 0, 0.71555],
    710: [0, 0.69444, 0.06646, 0, 0.51111],
    711: [0, 0.62847, 0.08295, 0, 0.51111],
    713: [0, 0.56167, 0.10333, 0, 0.51111],
    714: [0, 0.69444, 0.09694, 0, 0.51111],
    715: [0, 0.69444, 0, 0, 0.51111],
    728: [0, 0.69444, 0.10806, 0, 0.51111],
    729: [0, 0.66786, 0.11752, 0, 0.30667],
    730: [0, 0.69444, 0, 0, 0.83129],
    732: [0, 0.66786, 0.11585, 0, 0.51111],
    733: [0, 0.69444, 0.1225, 0, 0.51111],
    915: [0, 0.68333, 0.13305, 0, 0.62722],
    916: [0, 0.68333, 0, 0, 0.81777],
    920: [0, 0.68333, 0.09403, 0, 0.76666],
    923: [0, 0.68333, 0, 0, 0.69222],
    926: [0, 0.68333, 0.15294, 0, 0.66444],
    928: [0, 0.68333, 0.16389, 0, 0.74333],
    931: [0, 0.68333, 0.12028, 0, 0.71555],
    933: [0, 0.68333, 0.11111, 0, 0.76666],
    934: [0, 0.68333, 0.05986, 0, 0.71555],
    936: [0, 0.68333, 0.11111, 0, 0.76666],
    937: [0, 0.68333, 0.10257, 0, 0.71555],
    8211: [0, 0.43056, 0.09208, 0, 0.51111],
    8212: [0, 0.43056, 0.09208, 0, 1.02222],
    8216: [0, 0.69444, 0.12417, 0, 0.30667],
    8217: [0, 0.69444, 0.12417, 0, 0.30667],
    8220: [0, 0.69444, 0.1685, 0, 0.51444],
    8221: [0, 0.69444, 0.06961, 0, 0.51444],
    8463: [0, 0.68889, 0, 0, 0.54028]
  },
  "Main-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.27778],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.77778],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.19444, 0.10556, 0, 0, 0.27778],
    45: [0, 0.43056, 0, 0, 0.33333],
    46: [0, 0.10556, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.64444, 0, 0, 0.5],
    49: [0, 0.64444, 0, 0, 0.5],
    50: [0, 0.64444, 0, 0, 0.5],
    51: [0, 0.64444, 0, 0, 0.5],
    52: [0, 0.64444, 0, 0, 0.5],
    53: [0, 0.64444, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0, 0.64444, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0, 0.64444, 0, 0, 0.5],
    58: [0, 0.43056, 0, 0, 0.27778],
    59: [0.19444, 0.43056, 0, 0, 0.27778],
    60: [0.0391, 0.5391, 0, 0, 0.77778],
    61: [-0.13313, 0.36687, 0, 0, 0.77778],
    62: [0.0391, 0.5391, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.77778],
    65: [0, 0.68333, 0, 0, 0.75],
    66: [0, 0.68333, 0, 0, 0.70834],
    67: [0, 0.68333, 0, 0, 0.72222],
    68: [0, 0.68333, 0, 0, 0.76389],
    69: [0, 0.68333, 0, 0, 0.68056],
    70: [0, 0.68333, 0, 0, 0.65278],
    71: [0, 0.68333, 0, 0, 0.78472],
    72: [0, 0.68333, 0, 0, 0.75],
    73: [0, 0.68333, 0, 0, 0.36111],
    74: [0, 0.68333, 0, 0, 0.51389],
    75: [0, 0.68333, 0, 0, 0.77778],
    76: [0, 0.68333, 0, 0, 0.625],
    77: [0, 0.68333, 0, 0, 0.91667],
    78: [0, 0.68333, 0, 0, 0.75],
    79: [0, 0.68333, 0, 0, 0.77778],
    80: [0, 0.68333, 0, 0, 0.68056],
    81: [0.19444, 0.68333, 0, 0, 0.77778],
    82: [0, 0.68333, 0, 0, 0.73611],
    83: [0, 0.68333, 0, 0, 0.55556],
    84: [0, 0.68333, 0, 0, 0.72222],
    85: [0, 0.68333, 0, 0, 0.75],
    86: [0, 0.68333, 0.01389, 0, 0.75],
    87: [0, 0.68333, 0.01389, 0, 1.02778],
    88: [0, 0.68333, 0, 0, 0.75],
    89: [0, 0.68333, 0.025, 0, 0.75],
    90: [0, 0.68333, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.27778],
    92: [0.25, 0.75, 0, 0, 0.5],
    93: [0.25, 0.75, 0, 0, 0.27778],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.31, 0.12056, 0.02778, 0, 0.5],
    97: [0, 0.43056, 0, 0, 0.5],
    98: [0, 0.69444, 0, 0, 0.55556],
    99: [0, 0.43056, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.55556],
    101: [0, 0.43056, 0, 0, 0.44445],
    102: [0, 0.69444, 0.07778, 0, 0.30556],
    103: [0.19444, 0.43056, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.55556],
    105: [0, 0.66786, 0, 0, 0.27778],
    106: [0.19444, 0.66786, 0, 0, 0.30556],
    107: [0, 0.69444, 0, 0, 0.52778],
    108: [0, 0.69444, 0, 0, 0.27778],
    109: [0, 0.43056, 0, 0, 0.83334],
    110: [0, 0.43056, 0, 0, 0.55556],
    111: [0, 0.43056, 0, 0, 0.5],
    112: [0.19444, 0.43056, 0, 0, 0.55556],
    113: [0.19444, 0.43056, 0, 0, 0.52778],
    114: [0, 0.43056, 0, 0, 0.39167],
    115: [0, 0.43056, 0, 0, 0.39445],
    116: [0, 0.61508, 0, 0, 0.38889],
    117: [0, 0.43056, 0, 0, 0.55556],
    118: [0, 0.43056, 0.01389, 0, 0.52778],
    119: [0, 0.43056, 0.01389, 0, 0.72222],
    120: [0, 0.43056, 0, 0, 0.52778],
    121: [0.19444, 0.43056, 0.01389, 0, 0.52778],
    122: [0, 0.43056, 0, 0, 0.44445],
    123: [0.25, 0.75, 0, 0, 0.5],
    124: [0.25, 0.75, 0, 0, 0.27778],
    125: [0.25, 0.75, 0, 0, 0.5],
    126: [0.35, 0.31786, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    163: [0, 0.69444, 0, 0, 0.76909],
    167: [0.19444, 0.69444, 0, 0, 0.44445],
    168: [0, 0.66786, 0, 0, 0.5],
    172: [0, 0.43056, 0, 0, 0.66667],
    176: [0, 0.69444, 0, 0, 0.75],
    177: [0.08333, 0.58333, 0, 0, 0.77778],
    182: [0.19444, 0.69444, 0, 0, 0.61111],
    184: [0.17014, 0, 0, 0, 0.44445],
    198: [0, 0.68333, 0, 0, 0.90278],
    215: [0.08333, 0.58333, 0, 0, 0.77778],
    216: [0.04861, 0.73194, 0, 0, 0.77778],
    223: [0, 0.69444, 0, 0, 0.5],
    230: [0, 0.43056, 0, 0, 0.72222],
    247: [0.08333, 0.58333, 0, 0, 0.77778],
    248: [0.09722, 0.52778, 0, 0, 0.5],
    305: [0, 0.43056, 0, 0, 0.27778],
    338: [0, 0.68333, 0, 0, 1.01389],
    339: [0, 0.43056, 0, 0, 0.77778],
    567: [0.19444, 0.43056, 0, 0, 0.30556],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.62847, 0, 0, 0.5],
    713: [0, 0.56778, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.66786, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.75],
    732: [0, 0.66786, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.68333, 0, 0, 0.625],
    916: [0, 0.68333, 0, 0, 0.83334],
    920: [0, 0.68333, 0, 0, 0.77778],
    923: [0, 0.68333, 0, 0, 0.69445],
    926: [0, 0.68333, 0, 0, 0.66667],
    928: [0, 0.68333, 0, 0, 0.75],
    931: [0, 0.68333, 0, 0, 0.72222],
    933: [0, 0.68333, 0, 0, 0.77778],
    934: [0, 0.68333, 0, 0, 0.72222],
    936: [0, 0.68333, 0, 0, 0.77778],
    937: [0, 0.68333, 0, 0, 0.72222],
    8211: [0, 0.43056, 0.02778, 0, 0.5],
    8212: [0, 0.43056, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5],
    8224: [0.19444, 0.69444, 0, 0, 0.44445],
    8225: [0.19444, 0.69444, 0, 0, 0.44445],
    8230: [0, 0.123, 0, 0, 1.172],
    8242: [0, 0.55556, 0, 0, 0.275],
    8407: [0, 0.71444, 0.15382, 0, 0.5],
    8463: [0, 0.68889, 0, 0, 0.54028],
    8465: [0, 0.69444, 0, 0, 0.72222],
    8467: [0, 0.69444, 0, 0.11111, 0.41667],
    8472: [0.19444, 0.43056, 0, 0.11111, 0.63646],
    8476: [0, 0.69444, 0, 0, 0.72222],
    8501: [0, 0.69444, 0, 0, 0.61111],
    8592: [-0.13313, 0.36687, 0, 0, 1],
    8593: [0.19444, 0.69444, 0, 0, 0.5],
    8594: [-0.13313, 0.36687, 0, 0, 1],
    8595: [0.19444, 0.69444, 0, 0, 0.5],
    8596: [-0.13313, 0.36687, 0, 0, 1],
    8597: [0.25, 0.75, 0, 0, 0.5],
    8598: [0.19444, 0.69444, 0, 0, 1],
    8599: [0.19444, 0.69444, 0, 0, 1],
    8600: [0.19444, 0.69444, 0, 0, 1],
    8601: [0.19444, 0.69444, 0, 0, 1],
    8614: [0.011, 0.511, 0, 0, 1],
    8617: [0.011, 0.511, 0, 0, 1.126],
    8618: [0.011, 0.511, 0, 0, 1.126],
    8636: [-0.13313, 0.36687, 0, 0, 1],
    8637: [-0.13313, 0.36687, 0, 0, 1],
    8640: [-0.13313, 0.36687, 0, 0, 1],
    8641: [-0.13313, 0.36687, 0, 0, 1],
    8652: [0.011, 0.671, 0, 0, 1],
    8656: [-0.13313, 0.36687, 0, 0, 1],
    8657: [0.19444, 0.69444, 0, 0, 0.61111],
    8658: [-0.13313, 0.36687, 0, 0, 1],
    8659: [0.19444, 0.69444, 0, 0, 0.61111],
    8660: [-0.13313, 0.36687, 0, 0, 1],
    8661: [0.25, 0.75, 0, 0, 0.61111],
    8704: [0, 0.69444, 0, 0, 0.55556],
    8706: [0, 0.69444, 0.05556, 0.08334, 0.5309],
    8707: [0, 0.69444, 0, 0, 0.55556],
    8709: [0.05556, 0.75, 0, 0, 0.5],
    8711: [0, 0.68333, 0, 0, 0.83334],
    8712: [0.0391, 0.5391, 0, 0, 0.66667],
    8715: [0.0391, 0.5391, 0, 0, 0.66667],
    8722: [0.08333, 0.58333, 0, 0, 0.77778],
    8723: [0.08333, 0.58333, 0, 0, 0.77778],
    8725: [0.25, 0.75, 0, 0, 0.5],
    8726: [0.25, 0.75, 0, 0, 0.5],
    8727: [-0.03472, 0.46528, 0, 0, 0.5],
    8728: [-0.05555, 0.44445, 0, 0, 0.5],
    8729: [-0.05555, 0.44445, 0, 0, 0.5],
    8730: [0.2, 0.8, 0, 0, 0.83334],
    8733: [0, 0.43056, 0, 0, 0.77778],
    8734: [0, 0.43056, 0, 0, 1],
    8736: [0, 0.69224, 0, 0, 0.72222],
    8739: [0.25, 0.75, 0, 0, 0.27778],
    8741: [0.25, 0.75, 0, 0, 0.5],
    8743: [0, 0.55556, 0, 0, 0.66667],
    8744: [0, 0.55556, 0, 0, 0.66667],
    8745: [0, 0.55556, 0, 0, 0.66667],
    8746: [0, 0.55556, 0, 0, 0.66667],
    8747: [0.19444, 0.69444, 0.11111, 0, 0.41667],
    8764: [-0.13313, 0.36687, 0, 0, 0.77778],
    8768: [0.19444, 0.69444, 0, 0, 0.27778],
    8771: [-0.03625, 0.46375, 0, 0, 0.77778],
    8773: [-0.022, 0.589, 0, 0, 0.778],
    8776: [-0.01688, 0.48312, 0, 0, 0.77778],
    8781: [-0.03625, 0.46375, 0, 0, 0.77778],
    8784: [-0.133, 0.673, 0, 0, 0.778],
    8801: [-0.03625, 0.46375, 0, 0, 0.77778],
    8804: [0.13597, 0.63597, 0, 0, 0.77778],
    8805: [0.13597, 0.63597, 0, 0, 0.77778],
    8810: [0.0391, 0.5391, 0, 0, 1],
    8811: [0.0391, 0.5391, 0, 0, 1],
    8826: [0.0391, 0.5391, 0, 0, 0.77778],
    8827: [0.0391, 0.5391, 0, 0, 0.77778],
    8834: [0.0391, 0.5391, 0, 0, 0.77778],
    8835: [0.0391, 0.5391, 0, 0, 0.77778],
    8838: [0.13597, 0.63597, 0, 0, 0.77778],
    8839: [0.13597, 0.63597, 0, 0, 0.77778],
    8846: [0, 0.55556, 0, 0, 0.66667],
    8849: [0.13597, 0.63597, 0, 0, 0.77778],
    8850: [0.13597, 0.63597, 0, 0, 0.77778],
    8851: [0, 0.55556, 0, 0, 0.66667],
    8852: [0, 0.55556, 0, 0, 0.66667],
    8853: [0.08333, 0.58333, 0, 0, 0.77778],
    8854: [0.08333, 0.58333, 0, 0, 0.77778],
    8855: [0.08333, 0.58333, 0, 0, 0.77778],
    8856: [0.08333, 0.58333, 0, 0, 0.77778],
    8857: [0.08333, 0.58333, 0, 0, 0.77778],
    8866: [0, 0.69444, 0, 0, 0.61111],
    8867: [0, 0.69444, 0, 0, 0.61111],
    8868: [0, 0.69444, 0, 0, 0.77778],
    8869: [0, 0.69444, 0, 0, 0.77778],
    8872: [0.249, 0.75, 0, 0, 0.867],
    8900: [-0.05555, 0.44445, 0, 0, 0.5],
    8901: [-0.05555, 0.44445, 0, 0, 0.27778],
    8902: [-0.03472, 0.46528, 0, 0, 0.5],
    8904: [5e-3, 0.505, 0, 0, 0.9],
    8942: [0.03, 0.903, 0, 0, 0.278],
    8943: [-0.19, 0.313, 0, 0, 1.172],
    8945: [-0.1, 0.823, 0, 0, 1.282],
    8968: [0.25, 0.75, 0, 0, 0.44445],
    8969: [0.25, 0.75, 0, 0, 0.44445],
    8970: [0.25, 0.75, 0, 0, 0.44445],
    8971: [0.25, 0.75, 0, 0, 0.44445],
    8994: [-0.14236, 0.35764, 0, 0, 1],
    8995: [-0.14236, 0.35764, 0, 0, 1],
    9136: [0.244, 0.744, 0, 0, 0.412],
    9137: [0.244, 0.745, 0, 0, 0.412],
    9651: [0.19444, 0.69444, 0, 0, 0.88889],
    9657: [-0.03472, 0.46528, 0, 0, 0.5],
    9661: [0.19444, 0.69444, 0, 0, 0.88889],
    9667: [-0.03472, 0.46528, 0, 0, 0.5],
    9711: [0.19444, 0.69444, 0, 0, 1],
    9824: [0.12963, 0.69444, 0, 0, 0.77778],
    9825: [0.12963, 0.69444, 0, 0, 0.77778],
    9826: [0.12963, 0.69444, 0, 0, 0.77778],
    9827: [0.12963, 0.69444, 0, 0, 0.77778],
    9837: [0, 0.75, 0, 0, 0.38889],
    9838: [0.19444, 0.69444, 0, 0, 0.38889],
    9839: [0.19444, 0.69444, 0, 0, 0.38889],
    10216: [0.25, 0.75, 0, 0, 0.38889],
    10217: [0.25, 0.75, 0, 0, 0.38889],
    10222: [0.244, 0.744, 0, 0, 0.412],
    10223: [0.244, 0.745, 0, 0, 0.412],
    10229: [0.011, 0.511, 0, 0, 1.609],
    10230: [0.011, 0.511, 0, 0, 1.638],
    10231: [0.011, 0.511, 0, 0, 1.859],
    10232: [0.024, 0.525, 0, 0, 1.609],
    10233: [0.024, 0.525, 0, 0, 1.638],
    10234: [0.024, 0.525, 0, 0, 1.858],
    10236: [0.011, 0.511, 0, 0, 1.638],
    10815: [0, 0.68333, 0, 0, 0.75],
    10927: [0.13597, 0.63597, 0, 0, 0.77778],
    10928: [0.13597, 0.63597, 0, 0, 0.77778],
    57376: [0.19444, 0.69444, 0, 0, 0]
  },
  "Math-BoldItalic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.44444, 0, 0, 0.575],
    49: [0, 0.44444, 0, 0, 0.575],
    50: [0, 0.44444, 0, 0, 0.575],
    51: [0.19444, 0.44444, 0, 0, 0.575],
    52: [0.19444, 0.44444, 0, 0, 0.575],
    53: [0.19444, 0.44444, 0, 0, 0.575],
    54: [0, 0.64444, 0, 0, 0.575],
    55: [0.19444, 0.44444, 0, 0, 0.575],
    56: [0, 0.64444, 0, 0, 0.575],
    57: [0.19444, 0.44444, 0, 0, 0.575],
    65: [0, 0.68611, 0, 0, 0.86944],
    66: [0, 0.68611, 0.04835, 0, 0.8664],
    67: [0, 0.68611, 0.06979, 0, 0.81694],
    68: [0, 0.68611, 0.03194, 0, 0.93812],
    69: [0, 0.68611, 0.05451, 0, 0.81007],
    70: [0, 0.68611, 0.15972, 0, 0.68889],
    71: [0, 0.68611, 0, 0, 0.88673],
    72: [0, 0.68611, 0.08229, 0, 0.98229],
    73: [0, 0.68611, 0.07778, 0, 0.51111],
    74: [0, 0.68611, 0.10069, 0, 0.63125],
    75: [0, 0.68611, 0.06979, 0, 0.97118],
    76: [0, 0.68611, 0, 0, 0.75555],
    77: [0, 0.68611, 0.11424, 0, 1.14201],
    78: [0, 0.68611, 0.11424, 0, 0.95034],
    79: [0, 0.68611, 0.03194, 0, 0.83666],
    80: [0, 0.68611, 0.15972, 0, 0.72309],
    81: [0.19444, 0.68611, 0, 0, 0.86861],
    82: [0, 0.68611, 421e-5, 0, 0.87235],
    83: [0, 0.68611, 0.05382, 0, 0.69271],
    84: [0, 0.68611, 0.15972, 0, 0.63663],
    85: [0, 0.68611, 0.11424, 0, 0.80027],
    86: [0, 0.68611, 0.25555, 0, 0.67778],
    87: [0, 0.68611, 0.15972, 0, 1.09305],
    88: [0, 0.68611, 0.07778, 0, 0.94722],
    89: [0, 0.68611, 0.25555, 0, 0.67458],
    90: [0, 0.68611, 0.06979, 0, 0.77257],
    97: [0, 0.44444, 0, 0, 0.63287],
    98: [0, 0.69444, 0, 0, 0.52083],
    99: [0, 0.44444, 0, 0, 0.51342],
    100: [0, 0.69444, 0, 0, 0.60972],
    101: [0, 0.44444, 0, 0, 0.55361],
    102: [0.19444, 0.69444, 0.11042, 0, 0.56806],
    103: [0.19444, 0.44444, 0.03704, 0, 0.5449],
    104: [0, 0.69444, 0, 0, 0.66759],
    105: [0, 0.69326, 0, 0, 0.4048],
    106: [0.19444, 0.69326, 0.0622, 0, 0.47083],
    107: [0, 0.69444, 0.01852, 0, 0.6037],
    108: [0, 0.69444, 88e-4, 0, 0.34815],
    109: [0, 0.44444, 0, 0, 1.0324],
    110: [0, 0.44444, 0, 0, 0.71296],
    111: [0, 0.44444, 0, 0, 0.58472],
    112: [0.19444, 0.44444, 0, 0, 0.60092],
    113: [0.19444, 0.44444, 0.03704, 0, 0.54213],
    114: [0, 0.44444, 0.03194, 0, 0.5287],
    115: [0, 0.44444, 0, 0, 0.53125],
    116: [0, 0.63492, 0, 0, 0.41528],
    117: [0, 0.44444, 0, 0, 0.68102],
    118: [0, 0.44444, 0.03704, 0, 0.56666],
    119: [0, 0.44444, 0.02778, 0, 0.83148],
    120: [0, 0.44444, 0, 0, 0.65903],
    121: [0.19444, 0.44444, 0.03704, 0, 0.59028],
    122: [0, 0.44444, 0.04213, 0, 0.55509],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68611, 0.15972, 0, 0.65694],
    916: [0, 0.68611, 0, 0, 0.95833],
    920: [0, 0.68611, 0.03194, 0, 0.86722],
    923: [0, 0.68611, 0, 0, 0.80555],
    926: [0, 0.68611, 0.07458, 0, 0.84125],
    928: [0, 0.68611, 0.08229, 0, 0.98229],
    931: [0, 0.68611, 0.05451, 0, 0.88507],
    933: [0, 0.68611, 0.15972, 0, 0.67083],
    934: [0, 0.68611, 0, 0, 0.76666],
    936: [0, 0.68611, 0.11653, 0, 0.71402],
    937: [0, 0.68611, 0.04835, 0, 0.8789],
    945: [0, 0.44444, 0, 0, 0.76064],
    946: [0.19444, 0.69444, 0.03403, 0, 0.65972],
    947: [0.19444, 0.44444, 0.06389, 0, 0.59003],
    948: [0, 0.69444, 0.03819, 0, 0.52222],
    949: [0, 0.44444, 0, 0, 0.52882],
    950: [0.19444, 0.69444, 0.06215, 0, 0.50833],
    951: [0.19444, 0.44444, 0.03704, 0, 0.6],
    952: [0, 0.69444, 0.03194, 0, 0.5618],
    953: [0, 0.44444, 0, 0, 0.41204],
    954: [0, 0.44444, 0, 0, 0.66759],
    955: [0, 0.69444, 0, 0, 0.67083],
    956: [0.19444, 0.44444, 0, 0, 0.70787],
    957: [0, 0.44444, 0.06898, 0, 0.57685],
    958: [0.19444, 0.69444, 0.03021, 0, 0.50833],
    959: [0, 0.44444, 0, 0, 0.58472],
    960: [0, 0.44444, 0.03704, 0, 0.68241],
    961: [0.19444, 0.44444, 0, 0, 0.6118],
    962: [0.09722, 0.44444, 0.07917, 0, 0.42361],
    963: [0, 0.44444, 0.03704, 0, 0.68588],
    964: [0, 0.44444, 0.13472, 0, 0.52083],
    965: [0, 0.44444, 0.03704, 0, 0.63055],
    966: [0.19444, 0.44444, 0, 0, 0.74722],
    967: [0.19444, 0.44444, 0, 0, 0.71805],
    968: [0.19444, 0.69444, 0.03704, 0, 0.75833],
    969: [0, 0.44444, 0.03704, 0, 0.71782],
    977: [0, 0.69444, 0, 0, 0.69155],
    981: [0.19444, 0.69444, 0, 0, 0.7125],
    982: [0, 0.44444, 0.03194, 0, 0.975],
    1009: [0.19444, 0.44444, 0, 0, 0.6118],
    1013: [0, 0.44444, 0, 0, 0.48333],
    57649: [0, 0.44444, 0, 0, 0.39352],
    57911: [0.19444, 0.44444, 0, 0, 0.43889]
  },
  "Math-Italic": {
    32: [0, 0, 0, 0, 0.25],
    48: [0, 0.43056, 0, 0, 0.5],
    49: [0, 0.43056, 0, 0, 0.5],
    50: [0, 0.43056, 0, 0, 0.5],
    51: [0.19444, 0.43056, 0, 0, 0.5],
    52: [0.19444, 0.43056, 0, 0, 0.5],
    53: [0.19444, 0.43056, 0, 0, 0.5],
    54: [0, 0.64444, 0, 0, 0.5],
    55: [0.19444, 0.43056, 0, 0, 0.5],
    56: [0, 0.64444, 0, 0, 0.5],
    57: [0.19444, 0.43056, 0, 0, 0.5],
    65: [0, 0.68333, 0, 0.13889, 0.75],
    66: [0, 0.68333, 0.05017, 0.08334, 0.75851],
    67: [0, 0.68333, 0.07153, 0.08334, 0.71472],
    68: [0, 0.68333, 0.02778, 0.05556, 0.82792],
    69: [0, 0.68333, 0.05764, 0.08334, 0.7382],
    70: [0, 0.68333, 0.13889, 0.08334, 0.64306],
    71: [0, 0.68333, 0, 0.08334, 0.78625],
    72: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    73: [0, 0.68333, 0.07847, 0.11111, 0.43958],
    74: [0, 0.68333, 0.09618, 0.16667, 0.55451],
    75: [0, 0.68333, 0.07153, 0.05556, 0.84931],
    76: [0, 0.68333, 0, 0.02778, 0.68056],
    77: [0, 0.68333, 0.10903, 0.08334, 0.97014],
    78: [0, 0.68333, 0.10903, 0.08334, 0.80347],
    79: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    80: [0, 0.68333, 0.13889, 0.08334, 0.64201],
    81: [0.19444, 0.68333, 0, 0.08334, 0.79056],
    82: [0, 0.68333, 773e-5, 0.08334, 0.75929],
    83: [0, 0.68333, 0.05764, 0.08334, 0.6132],
    84: [0, 0.68333, 0.13889, 0.08334, 0.58438],
    85: [0, 0.68333, 0.10903, 0.02778, 0.68278],
    86: [0, 0.68333, 0.22222, 0, 0.58333],
    87: [0, 0.68333, 0.13889, 0, 0.94445],
    88: [0, 0.68333, 0.07847, 0.08334, 0.82847],
    89: [0, 0.68333, 0.22222, 0, 0.58056],
    90: [0, 0.68333, 0.07153, 0.08334, 0.68264],
    97: [0, 0.43056, 0, 0, 0.52859],
    98: [0, 0.69444, 0, 0, 0.42917],
    99: [0, 0.43056, 0, 0.05556, 0.43276],
    100: [0, 0.69444, 0, 0.16667, 0.52049],
    101: [0, 0.43056, 0, 0.05556, 0.46563],
    102: [0.19444, 0.69444, 0.10764, 0.16667, 0.48959],
    103: [0.19444, 0.43056, 0.03588, 0.02778, 0.47697],
    104: [0, 0.69444, 0, 0, 0.57616],
    105: [0, 0.65952, 0, 0, 0.34451],
    106: [0.19444, 0.65952, 0.05724, 0, 0.41181],
    107: [0, 0.69444, 0.03148, 0, 0.5206],
    108: [0, 0.69444, 0.01968, 0.08334, 0.29838],
    109: [0, 0.43056, 0, 0, 0.87801],
    110: [0, 0.43056, 0, 0, 0.60023],
    111: [0, 0.43056, 0, 0.05556, 0.48472],
    112: [0.19444, 0.43056, 0, 0.08334, 0.50313],
    113: [0.19444, 0.43056, 0.03588, 0.08334, 0.44641],
    114: [0, 0.43056, 0.02778, 0.05556, 0.45116],
    115: [0, 0.43056, 0, 0.05556, 0.46875],
    116: [0, 0.61508, 0, 0.08334, 0.36111],
    117: [0, 0.43056, 0, 0.02778, 0.57246],
    118: [0, 0.43056, 0.03588, 0.02778, 0.48472],
    119: [0, 0.43056, 0.02691, 0.08334, 0.71592],
    120: [0, 0.43056, 0, 0.02778, 0.57153],
    121: [0.19444, 0.43056, 0.03588, 0.05556, 0.49028],
    122: [0, 0.43056, 0.04398, 0.05556, 0.46505],
    160: [0, 0, 0, 0, 0.25],
    915: [0, 0.68333, 0.13889, 0.08334, 0.61528],
    916: [0, 0.68333, 0, 0.16667, 0.83334],
    920: [0, 0.68333, 0.02778, 0.08334, 0.76278],
    923: [0, 0.68333, 0, 0.16667, 0.69445],
    926: [0, 0.68333, 0.07569, 0.08334, 0.74236],
    928: [0, 0.68333, 0.08125, 0.05556, 0.83125],
    931: [0, 0.68333, 0.05764, 0.08334, 0.77986],
    933: [0, 0.68333, 0.13889, 0.05556, 0.58333],
    934: [0, 0.68333, 0, 0.08334, 0.66667],
    936: [0, 0.68333, 0.11, 0.05556, 0.61222],
    937: [0, 0.68333, 0.05017, 0.08334, 0.7724],
    945: [0, 0.43056, 37e-4, 0.02778, 0.6397],
    946: [0.19444, 0.69444, 0.05278, 0.08334, 0.56563],
    947: [0.19444, 0.43056, 0.05556, 0, 0.51773],
    948: [0, 0.69444, 0.03785, 0.05556, 0.44444],
    949: [0, 0.43056, 0, 0.08334, 0.46632],
    950: [0.19444, 0.69444, 0.07378, 0.08334, 0.4375],
    951: [0.19444, 0.43056, 0.03588, 0.05556, 0.49653],
    952: [0, 0.69444, 0.02778, 0.08334, 0.46944],
    953: [0, 0.43056, 0, 0.05556, 0.35394],
    954: [0, 0.43056, 0, 0, 0.57616],
    955: [0, 0.69444, 0, 0, 0.58334],
    956: [0.19444, 0.43056, 0, 0.02778, 0.60255],
    957: [0, 0.43056, 0.06366, 0.02778, 0.49398],
    958: [0.19444, 0.69444, 0.04601, 0.11111, 0.4375],
    959: [0, 0.43056, 0, 0.05556, 0.48472],
    960: [0, 0.43056, 0.03588, 0, 0.57003],
    961: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    962: [0.09722, 0.43056, 0.07986, 0.08334, 0.36285],
    963: [0, 0.43056, 0.03588, 0, 0.57141],
    964: [0, 0.43056, 0.1132, 0.02778, 0.43715],
    965: [0, 0.43056, 0.03588, 0.02778, 0.54028],
    966: [0.19444, 0.43056, 0, 0.08334, 0.65417],
    967: [0.19444, 0.43056, 0, 0.05556, 0.62569],
    968: [0.19444, 0.69444, 0.03588, 0.11111, 0.65139],
    969: [0, 0.43056, 0.03588, 0, 0.62245],
    977: [0, 0.69444, 0, 0.08334, 0.59144],
    981: [0.19444, 0.69444, 0, 0.08334, 0.59583],
    982: [0, 0.43056, 0.02778, 0, 0.82813],
    1009: [0.19444, 0.43056, 0, 0.08334, 0.51702],
    1013: [0, 0.43056, 0, 0.05556, 0.4059],
    57649: [0, 0.43056, 0, 0.02778, 0.32246],
    57911: [0.19444, 0.43056, 0, 0.08334, 0.38403]
  },
  "SansSerif-Bold": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.36667],
    34: [0, 0.69444, 0, 0, 0.55834],
    35: [0.19444, 0.69444, 0, 0, 0.91667],
    36: [0.05556, 0.75, 0, 0, 0.55],
    37: [0.05556, 0.75, 0, 0, 1.02912],
    38: [0, 0.69444, 0, 0, 0.83056],
    39: [0, 0.69444, 0, 0, 0.30556],
    40: [0.25, 0.75, 0, 0, 0.42778],
    41: [0.25, 0.75, 0, 0, 0.42778],
    42: [0, 0.75, 0, 0, 0.55],
    43: [0.11667, 0.61667, 0, 0, 0.85556],
    44: [0.10556, 0.13056, 0, 0, 0.30556],
    45: [0, 0.45833, 0, 0, 0.36667],
    46: [0, 0.13056, 0, 0, 0.30556],
    47: [0.25, 0.75, 0, 0, 0.55],
    48: [0, 0.69444, 0, 0, 0.55],
    49: [0, 0.69444, 0, 0, 0.55],
    50: [0, 0.69444, 0, 0, 0.55],
    51: [0, 0.69444, 0, 0, 0.55],
    52: [0, 0.69444, 0, 0, 0.55],
    53: [0, 0.69444, 0, 0, 0.55],
    54: [0, 0.69444, 0, 0, 0.55],
    55: [0, 0.69444, 0, 0, 0.55],
    56: [0, 0.69444, 0, 0, 0.55],
    57: [0, 0.69444, 0, 0, 0.55],
    58: [0, 0.45833, 0, 0, 0.30556],
    59: [0.10556, 0.45833, 0, 0, 0.30556],
    61: [-0.09375, 0.40625, 0, 0, 0.85556],
    63: [0, 0.69444, 0, 0, 0.51945],
    64: [0, 0.69444, 0, 0, 0.73334],
    65: [0, 0.69444, 0, 0, 0.73334],
    66: [0, 0.69444, 0, 0, 0.73334],
    67: [0, 0.69444, 0, 0, 0.70278],
    68: [0, 0.69444, 0, 0, 0.79445],
    69: [0, 0.69444, 0, 0, 0.64167],
    70: [0, 0.69444, 0, 0, 0.61111],
    71: [0, 0.69444, 0, 0, 0.73334],
    72: [0, 0.69444, 0, 0, 0.79445],
    73: [0, 0.69444, 0, 0, 0.33056],
    74: [0, 0.69444, 0, 0, 0.51945],
    75: [0, 0.69444, 0, 0, 0.76389],
    76: [0, 0.69444, 0, 0, 0.58056],
    77: [0, 0.69444, 0, 0, 0.97778],
    78: [0, 0.69444, 0, 0, 0.79445],
    79: [0, 0.69444, 0, 0, 0.79445],
    80: [0, 0.69444, 0, 0, 0.70278],
    81: [0.10556, 0.69444, 0, 0, 0.79445],
    82: [0, 0.69444, 0, 0, 0.70278],
    83: [0, 0.69444, 0, 0, 0.61111],
    84: [0, 0.69444, 0, 0, 0.73334],
    85: [0, 0.69444, 0, 0, 0.76389],
    86: [0, 0.69444, 0.01528, 0, 0.73334],
    87: [0, 0.69444, 0.01528, 0, 1.03889],
    88: [0, 0.69444, 0, 0, 0.73334],
    89: [0, 0.69444, 0.0275, 0, 0.73334],
    90: [0, 0.69444, 0, 0, 0.67223],
    91: [0.25, 0.75, 0, 0, 0.34306],
    93: [0.25, 0.75, 0, 0, 0.34306],
    94: [0, 0.69444, 0, 0, 0.55],
    95: [0.35, 0.10833, 0.03056, 0, 0.55],
    97: [0, 0.45833, 0, 0, 0.525],
    98: [0, 0.69444, 0, 0, 0.56111],
    99: [0, 0.45833, 0, 0, 0.48889],
    100: [0, 0.69444, 0, 0, 0.56111],
    101: [0, 0.45833, 0, 0, 0.51111],
    102: [0, 0.69444, 0.07639, 0, 0.33611],
    103: [0.19444, 0.45833, 0.01528, 0, 0.55],
    104: [0, 0.69444, 0, 0, 0.56111],
    105: [0, 0.69444, 0, 0, 0.25556],
    106: [0.19444, 0.69444, 0, 0, 0.28611],
    107: [0, 0.69444, 0, 0, 0.53056],
    108: [0, 0.69444, 0, 0, 0.25556],
    109: [0, 0.45833, 0, 0, 0.86667],
    110: [0, 0.45833, 0, 0, 0.56111],
    111: [0, 0.45833, 0, 0, 0.55],
    112: [0.19444, 0.45833, 0, 0, 0.56111],
    113: [0.19444, 0.45833, 0, 0, 0.56111],
    114: [0, 0.45833, 0.01528, 0, 0.37222],
    115: [0, 0.45833, 0, 0, 0.42167],
    116: [0, 0.58929, 0, 0, 0.40417],
    117: [0, 0.45833, 0, 0, 0.56111],
    118: [0, 0.45833, 0.01528, 0, 0.5],
    119: [0, 0.45833, 0.01528, 0, 0.74445],
    120: [0, 0.45833, 0, 0, 0.5],
    121: [0.19444, 0.45833, 0.01528, 0, 0.5],
    122: [0, 0.45833, 0, 0, 0.47639],
    126: [0.35, 0.34444, 0, 0, 0.55],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.69444, 0, 0, 0.55],
    176: [0, 0.69444, 0, 0, 0.73334],
    180: [0, 0.69444, 0, 0, 0.55],
    184: [0.17014, 0, 0, 0, 0.48889],
    305: [0, 0.45833, 0, 0, 0.25556],
    567: [0.19444, 0.45833, 0, 0, 0.28611],
    710: [0, 0.69444, 0, 0, 0.55],
    711: [0, 0.63542, 0, 0, 0.55],
    713: [0, 0.63778, 0, 0, 0.55],
    728: [0, 0.69444, 0, 0, 0.55],
    729: [0, 0.69444, 0, 0, 0.30556],
    730: [0, 0.69444, 0, 0, 0.73334],
    732: [0, 0.69444, 0, 0, 0.55],
    733: [0, 0.69444, 0, 0, 0.55],
    915: [0, 0.69444, 0, 0, 0.58056],
    916: [0, 0.69444, 0, 0, 0.91667],
    920: [0, 0.69444, 0, 0, 0.85556],
    923: [0, 0.69444, 0, 0, 0.67223],
    926: [0, 0.69444, 0, 0, 0.73334],
    928: [0, 0.69444, 0, 0, 0.79445],
    931: [0, 0.69444, 0, 0, 0.79445],
    933: [0, 0.69444, 0, 0, 0.85556],
    934: [0, 0.69444, 0, 0, 0.79445],
    936: [0, 0.69444, 0, 0, 0.85556],
    937: [0, 0.69444, 0, 0, 0.79445],
    8211: [0, 0.45833, 0.03056, 0, 0.55],
    8212: [0, 0.45833, 0.03056, 0, 1.10001],
    8216: [0, 0.69444, 0, 0, 0.30556],
    8217: [0, 0.69444, 0, 0, 0.30556],
    8220: [0, 0.69444, 0, 0, 0.55834],
    8221: [0, 0.69444, 0, 0, 0.55834]
  },
  "SansSerif-Italic": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0.05733, 0, 0.31945],
    34: [0, 0.69444, 316e-5, 0, 0.5],
    35: [0.19444, 0.69444, 0.05087, 0, 0.83334],
    36: [0.05556, 0.75, 0.11156, 0, 0.5],
    37: [0.05556, 0.75, 0.03126, 0, 0.83334],
    38: [0, 0.69444, 0.03058, 0, 0.75834],
    39: [0, 0.69444, 0.07816, 0, 0.27778],
    40: [0.25, 0.75, 0.13164, 0, 0.38889],
    41: [0.25, 0.75, 0.02536, 0, 0.38889],
    42: [0, 0.75, 0.11775, 0, 0.5],
    43: [0.08333, 0.58333, 0.02536, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0.01946, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0.13164, 0, 0.5],
    48: [0, 0.65556, 0.11156, 0, 0.5],
    49: [0, 0.65556, 0.11156, 0, 0.5],
    50: [0, 0.65556, 0.11156, 0, 0.5],
    51: [0, 0.65556, 0.11156, 0, 0.5],
    52: [0, 0.65556, 0.11156, 0, 0.5],
    53: [0, 0.65556, 0.11156, 0, 0.5],
    54: [0, 0.65556, 0.11156, 0, 0.5],
    55: [0, 0.65556, 0.11156, 0, 0.5],
    56: [0, 0.65556, 0.11156, 0, 0.5],
    57: [0, 0.65556, 0.11156, 0, 0.5],
    58: [0, 0.44444, 0.02502, 0, 0.27778],
    59: [0.125, 0.44444, 0.02502, 0, 0.27778],
    61: [-0.13, 0.37, 0.05087, 0, 0.77778],
    63: [0, 0.69444, 0.11809, 0, 0.47222],
    64: [0, 0.69444, 0.07555, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0.08293, 0, 0.66667],
    67: [0, 0.69444, 0.11983, 0, 0.63889],
    68: [0, 0.69444, 0.07555, 0, 0.72223],
    69: [0, 0.69444, 0.11983, 0, 0.59722],
    70: [0, 0.69444, 0.13372, 0, 0.56945],
    71: [0, 0.69444, 0.11983, 0, 0.66667],
    72: [0, 0.69444, 0.08094, 0, 0.70834],
    73: [0, 0.69444, 0.13372, 0, 0.27778],
    74: [0, 0.69444, 0.08094, 0, 0.47222],
    75: [0, 0.69444, 0.11983, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0.08094, 0, 0.875],
    78: [0, 0.69444, 0.08094, 0, 0.70834],
    79: [0, 0.69444, 0.07555, 0, 0.73611],
    80: [0, 0.69444, 0.08293, 0, 0.63889],
    81: [0.125, 0.69444, 0.07555, 0, 0.73611],
    82: [0, 0.69444, 0.08293, 0, 0.64584],
    83: [0, 0.69444, 0.09205, 0, 0.55556],
    84: [0, 0.69444, 0.13372, 0, 0.68056],
    85: [0, 0.69444, 0.08094, 0, 0.6875],
    86: [0, 0.69444, 0.1615, 0, 0.66667],
    87: [0, 0.69444, 0.1615, 0, 0.94445],
    88: [0, 0.69444, 0.13372, 0, 0.66667],
    89: [0, 0.69444, 0.17261, 0, 0.66667],
    90: [0, 0.69444, 0.11983, 0, 0.61111],
    91: [0.25, 0.75, 0.15942, 0, 0.28889],
    93: [0.25, 0.75, 0.08719, 0, 0.28889],
    94: [0, 0.69444, 0.0799, 0, 0.5],
    95: [0.35, 0.09444, 0.08616, 0, 0.5],
    97: [0, 0.44444, 981e-5, 0, 0.48056],
    98: [0, 0.69444, 0.03057, 0, 0.51667],
    99: [0, 0.44444, 0.08336, 0, 0.44445],
    100: [0, 0.69444, 0.09483, 0, 0.51667],
    101: [0, 0.44444, 0.06778, 0, 0.44445],
    102: [0, 0.69444, 0.21705, 0, 0.30556],
    103: [0.19444, 0.44444, 0.10836, 0, 0.5],
    104: [0, 0.69444, 0.01778, 0, 0.51667],
    105: [0, 0.67937, 0.09718, 0, 0.23889],
    106: [0.19444, 0.67937, 0.09162, 0, 0.26667],
    107: [0, 0.69444, 0.08336, 0, 0.48889],
    108: [0, 0.69444, 0.09483, 0, 0.23889],
    109: [0, 0.44444, 0.01778, 0, 0.79445],
    110: [0, 0.44444, 0.01778, 0, 0.51667],
    111: [0, 0.44444, 0.06613, 0, 0.5],
    112: [0.19444, 0.44444, 0.0389, 0, 0.51667],
    113: [0.19444, 0.44444, 0.04169, 0, 0.51667],
    114: [0, 0.44444, 0.10836, 0, 0.34167],
    115: [0, 0.44444, 0.0778, 0, 0.38333],
    116: [0, 0.57143, 0.07225, 0, 0.36111],
    117: [0, 0.44444, 0.04169, 0, 0.51667],
    118: [0, 0.44444, 0.10836, 0, 0.46111],
    119: [0, 0.44444, 0.10836, 0, 0.68334],
    120: [0, 0.44444, 0.09169, 0, 0.46111],
    121: [0.19444, 0.44444, 0.10836, 0, 0.46111],
    122: [0, 0.44444, 0.08752, 0, 0.43472],
    126: [0.35, 0.32659, 0.08826, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0.06385, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.73752],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0.04169, 0, 0.23889],
    567: [0.19444, 0.44444, 0.04169, 0, 0.26667],
    710: [0, 0.69444, 0.0799, 0, 0.5],
    711: [0, 0.63194, 0.08432, 0, 0.5],
    713: [0, 0.60889, 0.08776, 0, 0.5],
    714: [0, 0.69444, 0.09205, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0.09483, 0, 0.5],
    729: [0, 0.67937, 0.07774, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.73752],
    732: [0, 0.67659, 0.08826, 0, 0.5],
    733: [0, 0.69444, 0.09205, 0, 0.5],
    915: [0, 0.69444, 0.13372, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0.07555, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0.12816, 0, 0.66667],
    928: [0, 0.69444, 0.08094, 0, 0.70834],
    931: [0, 0.69444, 0.11983, 0, 0.72222],
    933: [0, 0.69444, 0.09031, 0, 0.77778],
    934: [0, 0.69444, 0.04603, 0, 0.72222],
    936: [0, 0.69444, 0.09031, 0, 0.77778],
    937: [0, 0.69444, 0.08293, 0, 0.72222],
    8211: [0, 0.44444, 0.08616, 0, 0.5],
    8212: [0, 0.44444, 0.08616, 0, 1],
    8216: [0, 0.69444, 0.07816, 0, 0.27778],
    8217: [0, 0.69444, 0.07816, 0, 0.27778],
    8220: [0, 0.69444, 0.14205, 0, 0.5],
    8221: [0, 0.69444, 316e-5, 0, 0.5]
  },
  "SansSerif-Regular": {
    32: [0, 0, 0, 0, 0.25],
    33: [0, 0.69444, 0, 0, 0.31945],
    34: [0, 0.69444, 0, 0, 0.5],
    35: [0.19444, 0.69444, 0, 0, 0.83334],
    36: [0.05556, 0.75, 0, 0, 0.5],
    37: [0.05556, 0.75, 0, 0, 0.83334],
    38: [0, 0.69444, 0, 0, 0.75834],
    39: [0, 0.69444, 0, 0, 0.27778],
    40: [0.25, 0.75, 0, 0, 0.38889],
    41: [0.25, 0.75, 0, 0, 0.38889],
    42: [0, 0.75, 0, 0, 0.5],
    43: [0.08333, 0.58333, 0, 0, 0.77778],
    44: [0.125, 0.08333, 0, 0, 0.27778],
    45: [0, 0.44444, 0, 0, 0.33333],
    46: [0, 0.08333, 0, 0, 0.27778],
    47: [0.25, 0.75, 0, 0, 0.5],
    48: [0, 0.65556, 0, 0, 0.5],
    49: [0, 0.65556, 0, 0, 0.5],
    50: [0, 0.65556, 0, 0, 0.5],
    51: [0, 0.65556, 0, 0, 0.5],
    52: [0, 0.65556, 0, 0, 0.5],
    53: [0, 0.65556, 0, 0, 0.5],
    54: [0, 0.65556, 0, 0, 0.5],
    55: [0, 0.65556, 0, 0, 0.5],
    56: [0, 0.65556, 0, 0, 0.5],
    57: [0, 0.65556, 0, 0, 0.5],
    58: [0, 0.44444, 0, 0, 0.27778],
    59: [0.125, 0.44444, 0, 0, 0.27778],
    61: [-0.13, 0.37, 0, 0, 0.77778],
    63: [0, 0.69444, 0, 0, 0.47222],
    64: [0, 0.69444, 0, 0, 0.66667],
    65: [0, 0.69444, 0, 0, 0.66667],
    66: [0, 0.69444, 0, 0, 0.66667],
    67: [0, 0.69444, 0, 0, 0.63889],
    68: [0, 0.69444, 0, 0, 0.72223],
    69: [0, 0.69444, 0, 0, 0.59722],
    70: [0, 0.69444, 0, 0, 0.56945],
    71: [0, 0.69444, 0, 0, 0.66667],
    72: [0, 0.69444, 0, 0, 0.70834],
    73: [0, 0.69444, 0, 0, 0.27778],
    74: [0, 0.69444, 0, 0, 0.47222],
    75: [0, 0.69444, 0, 0, 0.69445],
    76: [0, 0.69444, 0, 0, 0.54167],
    77: [0, 0.69444, 0, 0, 0.875],
    78: [0, 0.69444, 0, 0, 0.70834],
    79: [0, 0.69444, 0, 0, 0.73611],
    80: [0, 0.69444, 0, 0, 0.63889],
    81: [0.125, 0.69444, 0, 0, 0.73611],
    82: [0, 0.69444, 0, 0, 0.64584],
    83: [0, 0.69444, 0, 0, 0.55556],
    84: [0, 0.69444, 0, 0, 0.68056],
    85: [0, 0.69444, 0, 0, 0.6875],
    86: [0, 0.69444, 0.01389, 0, 0.66667],
    87: [0, 0.69444, 0.01389, 0, 0.94445],
    88: [0, 0.69444, 0, 0, 0.66667],
    89: [0, 0.69444, 0.025, 0, 0.66667],
    90: [0, 0.69444, 0, 0, 0.61111],
    91: [0.25, 0.75, 0, 0, 0.28889],
    93: [0.25, 0.75, 0, 0, 0.28889],
    94: [0, 0.69444, 0, 0, 0.5],
    95: [0.35, 0.09444, 0.02778, 0, 0.5],
    97: [0, 0.44444, 0, 0, 0.48056],
    98: [0, 0.69444, 0, 0, 0.51667],
    99: [0, 0.44444, 0, 0, 0.44445],
    100: [0, 0.69444, 0, 0, 0.51667],
    101: [0, 0.44444, 0, 0, 0.44445],
    102: [0, 0.69444, 0.06944, 0, 0.30556],
    103: [0.19444, 0.44444, 0.01389, 0, 0.5],
    104: [0, 0.69444, 0, 0, 0.51667],
    105: [0, 0.67937, 0, 0, 0.23889],
    106: [0.19444, 0.67937, 0, 0, 0.26667],
    107: [0, 0.69444, 0, 0, 0.48889],
    108: [0, 0.69444, 0, 0, 0.23889],
    109: [0, 0.44444, 0, 0, 0.79445],
    110: [0, 0.44444, 0, 0, 0.51667],
    111: [0, 0.44444, 0, 0, 0.5],
    112: [0.19444, 0.44444, 0, 0, 0.51667],
    113: [0.19444, 0.44444, 0, 0, 0.51667],
    114: [0, 0.44444, 0.01389, 0, 0.34167],
    115: [0, 0.44444, 0, 0, 0.38333],
    116: [0, 0.57143, 0, 0, 0.36111],
    117: [0, 0.44444, 0, 0, 0.51667],
    118: [0, 0.44444, 0.01389, 0, 0.46111],
    119: [0, 0.44444, 0.01389, 0, 0.68334],
    120: [0, 0.44444, 0, 0, 0.46111],
    121: [0.19444, 0.44444, 0.01389, 0, 0.46111],
    122: [0, 0.44444, 0, 0, 0.43472],
    126: [0.35, 0.32659, 0, 0, 0.5],
    160: [0, 0, 0, 0, 0.25],
    168: [0, 0.67937, 0, 0, 0.5],
    176: [0, 0.69444, 0, 0, 0.66667],
    184: [0.17014, 0, 0, 0, 0.44445],
    305: [0, 0.44444, 0, 0, 0.23889],
    567: [0.19444, 0.44444, 0, 0, 0.26667],
    710: [0, 0.69444, 0, 0, 0.5],
    711: [0, 0.63194, 0, 0, 0.5],
    713: [0, 0.60889, 0, 0, 0.5],
    714: [0, 0.69444, 0, 0, 0.5],
    715: [0, 0.69444, 0, 0, 0.5],
    728: [0, 0.69444, 0, 0, 0.5],
    729: [0, 0.67937, 0, 0, 0.27778],
    730: [0, 0.69444, 0, 0, 0.66667],
    732: [0, 0.67659, 0, 0, 0.5],
    733: [0, 0.69444, 0, 0, 0.5],
    915: [0, 0.69444, 0, 0, 0.54167],
    916: [0, 0.69444, 0, 0, 0.83334],
    920: [0, 0.69444, 0, 0, 0.77778],
    923: [0, 0.69444, 0, 0, 0.61111],
    926: [0, 0.69444, 0, 0, 0.66667],
    928: [0, 0.69444, 0, 0, 0.70834],
    931: [0, 0.69444, 0, 0, 0.72222],
    933: [0, 0.69444, 0, 0, 0.77778],
    934: [0, 0.69444, 0, 0, 0.72222],
    936: [0, 0.69444, 0, 0, 0.77778],
    937: [0, 0.69444, 0, 0, 0.72222],
    8211: [0, 0.44444, 0.02778, 0, 0.5],
    8212: [0, 0.44444, 0.02778, 0, 1],
    8216: [0, 0.69444, 0, 0, 0.27778],
    8217: [0, 0.69444, 0, 0, 0.27778],
    8220: [0, 0.69444, 0, 0, 0.5],
    8221: [0, 0.69444, 0, 0, 0.5]
  },
  "Script-Regular": {
    32: [0, 0, 0, 0, 0.25],
    65: [0, 0.7, 0.22925, 0, 0.80253],
    66: [0, 0.7, 0.04087, 0, 0.90757],
    67: [0, 0.7, 0.1689, 0, 0.66619],
    68: [0, 0.7, 0.09371, 0, 0.77443],
    69: [0, 0.7, 0.18583, 0, 0.56162],
    70: [0, 0.7, 0.13634, 0, 0.89544],
    71: [0, 0.7, 0.17322, 0, 0.60961],
    72: [0, 0.7, 0.29694, 0, 0.96919],
    73: [0, 0.7, 0.19189, 0, 0.80907],
    74: [0.27778, 0.7, 0.19189, 0, 1.05159],
    75: [0, 0.7, 0.31259, 0, 0.91364],
    76: [0, 0.7, 0.19189, 0, 0.87373],
    77: [0, 0.7, 0.15981, 0, 1.08031],
    78: [0, 0.7, 0.3525, 0, 0.9015],
    79: [0, 0.7, 0.08078, 0, 0.73787],
    80: [0, 0.7, 0.08078, 0, 1.01262],
    81: [0, 0.7, 0.03305, 0, 0.88282],
    82: [0, 0.7, 0.06259, 0, 0.85],
    83: [0, 0.7, 0.19189, 0, 0.86767],
    84: [0, 0.7, 0.29087, 0, 0.74697],
    85: [0, 0.7, 0.25815, 0, 0.79996],
    86: [0, 0.7, 0.27523, 0, 0.62204],
    87: [0, 0.7, 0.27523, 0, 0.80532],
    88: [0, 0.7, 0.26006, 0, 0.94445],
    89: [0, 0.7, 0.2939, 0, 0.70961],
    90: [0, 0.7, 0.24037, 0, 0.8212],
    160: [0, 0, 0, 0, 0.25]
  },
  "Size1-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.35001, 0.85, 0, 0, 0.45834],
    41: [0.35001, 0.85, 0, 0, 0.45834],
    47: [0.35001, 0.85, 0, 0, 0.57778],
    91: [0.35001, 0.85, 0, 0, 0.41667],
    92: [0.35001, 0.85, 0, 0, 0.57778],
    93: [0.35001, 0.85, 0, 0, 0.41667],
    123: [0.35001, 0.85, 0, 0, 0.58334],
    125: [0.35001, 0.85, 0, 0, 0.58334],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.72222, 0, 0, 0.55556],
    732: [0, 0.72222, 0, 0, 0.55556],
    770: [0, 0.72222, 0, 0, 0.55556],
    771: [0, 0.72222, 0, 0, 0.55556],
    8214: [-99e-5, 0.601, 0, 0, 0.77778],
    8593: [1e-5, 0.6, 0, 0, 0.66667],
    8595: [1e-5, 0.6, 0, 0, 0.66667],
    8657: [1e-5, 0.6, 0, 0, 0.77778],
    8659: [1e-5, 0.6, 0, 0, 0.77778],
    8719: [0.25001, 0.75, 0, 0, 0.94445],
    8720: [0.25001, 0.75, 0, 0, 0.94445],
    8721: [0.25001, 0.75, 0, 0, 1.05556],
    8730: [0.35001, 0.85, 0, 0, 1],
    8739: [-599e-5, 0.606, 0, 0, 0.33333],
    8741: [-599e-5, 0.606, 0, 0, 0.55556],
    8747: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8748: [0.306, 0.805, 0.19445, 0, 0.47222],
    8749: [0.306, 0.805, 0.19445, 0, 0.47222],
    8750: [0.30612, 0.805, 0.19445, 0, 0.47222],
    8896: [0.25001, 0.75, 0, 0, 0.83334],
    8897: [0.25001, 0.75, 0, 0, 0.83334],
    8898: [0.25001, 0.75, 0, 0, 0.83334],
    8899: [0.25001, 0.75, 0, 0, 0.83334],
    8968: [0.35001, 0.85, 0, 0, 0.47222],
    8969: [0.35001, 0.85, 0, 0, 0.47222],
    8970: [0.35001, 0.85, 0, 0, 0.47222],
    8971: [0.35001, 0.85, 0, 0, 0.47222],
    9168: [-99e-5, 0.601, 0, 0, 0.66667],
    10216: [0.35001, 0.85, 0, 0, 0.47222],
    10217: [0.35001, 0.85, 0, 0, 0.47222],
    10752: [0.25001, 0.75, 0, 0, 1.11111],
    10753: [0.25001, 0.75, 0, 0, 1.11111],
    10754: [0.25001, 0.75, 0, 0, 1.11111],
    10756: [0.25001, 0.75, 0, 0, 0.83334],
    10758: [0.25001, 0.75, 0, 0, 0.83334]
  },
  "Size2-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.65002, 1.15, 0, 0, 0.59722],
    41: [0.65002, 1.15, 0, 0, 0.59722],
    47: [0.65002, 1.15, 0, 0, 0.81111],
    91: [0.65002, 1.15, 0, 0, 0.47222],
    92: [0.65002, 1.15, 0, 0, 0.81111],
    93: [0.65002, 1.15, 0, 0, 0.47222],
    123: [0.65002, 1.15, 0, 0, 0.66667],
    125: [0.65002, 1.15, 0, 0, 0.66667],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1],
    732: [0, 0.75, 0, 0, 1],
    770: [0, 0.75, 0, 0, 1],
    771: [0, 0.75, 0, 0, 1],
    8719: [0.55001, 1.05, 0, 0, 1.27778],
    8720: [0.55001, 1.05, 0, 0, 1.27778],
    8721: [0.55001, 1.05, 0, 0, 1.44445],
    8730: [0.65002, 1.15, 0, 0, 1],
    8747: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8748: [0.862, 1.36, 0.44445, 0, 0.55556],
    8749: [0.862, 1.36, 0.44445, 0, 0.55556],
    8750: [0.86225, 1.36, 0.44445, 0, 0.55556],
    8896: [0.55001, 1.05, 0, 0, 1.11111],
    8897: [0.55001, 1.05, 0, 0, 1.11111],
    8898: [0.55001, 1.05, 0, 0, 1.11111],
    8899: [0.55001, 1.05, 0, 0, 1.11111],
    8968: [0.65002, 1.15, 0, 0, 0.52778],
    8969: [0.65002, 1.15, 0, 0, 0.52778],
    8970: [0.65002, 1.15, 0, 0, 0.52778],
    8971: [0.65002, 1.15, 0, 0, 0.52778],
    10216: [0.65002, 1.15, 0, 0, 0.61111],
    10217: [0.65002, 1.15, 0, 0, 0.61111],
    10752: [0.55001, 1.05, 0, 0, 1.51112],
    10753: [0.55001, 1.05, 0, 0, 1.51112],
    10754: [0.55001, 1.05, 0, 0, 1.51112],
    10756: [0.55001, 1.05, 0, 0, 1.11111],
    10758: [0.55001, 1.05, 0, 0, 1.11111]
  },
  "Size3-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [0.95003, 1.45, 0, 0, 0.73611],
    41: [0.95003, 1.45, 0, 0, 0.73611],
    47: [0.95003, 1.45, 0, 0, 1.04445],
    91: [0.95003, 1.45, 0, 0, 0.52778],
    92: [0.95003, 1.45, 0, 0, 1.04445],
    93: [0.95003, 1.45, 0, 0, 0.52778],
    123: [0.95003, 1.45, 0, 0, 0.75],
    125: [0.95003, 1.45, 0, 0, 0.75],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.75, 0, 0, 1.44445],
    732: [0, 0.75, 0, 0, 1.44445],
    770: [0, 0.75, 0, 0, 1.44445],
    771: [0, 0.75, 0, 0, 1.44445],
    8730: [0.95003, 1.45, 0, 0, 1],
    8968: [0.95003, 1.45, 0, 0, 0.58334],
    8969: [0.95003, 1.45, 0, 0, 0.58334],
    8970: [0.95003, 1.45, 0, 0, 0.58334],
    8971: [0.95003, 1.45, 0, 0, 0.58334],
    10216: [0.95003, 1.45, 0, 0, 0.75],
    10217: [0.95003, 1.45, 0, 0, 0.75]
  },
  "Size4-Regular": {
    32: [0, 0, 0, 0, 0.25],
    40: [1.25003, 1.75, 0, 0, 0.79167],
    41: [1.25003, 1.75, 0, 0, 0.79167],
    47: [1.25003, 1.75, 0, 0, 1.27778],
    91: [1.25003, 1.75, 0, 0, 0.58334],
    92: [1.25003, 1.75, 0, 0, 1.27778],
    93: [1.25003, 1.75, 0, 0, 0.58334],
    123: [1.25003, 1.75, 0, 0, 0.80556],
    125: [1.25003, 1.75, 0, 0, 0.80556],
    160: [0, 0, 0, 0, 0.25],
    710: [0, 0.825, 0, 0, 1.8889],
    732: [0, 0.825, 0, 0, 1.8889],
    770: [0, 0.825, 0, 0, 1.8889],
    771: [0, 0.825, 0, 0, 1.8889],
    8730: [1.25003, 1.75, 0, 0, 1],
    8968: [1.25003, 1.75, 0, 0, 0.63889],
    8969: [1.25003, 1.75, 0, 0, 0.63889],
    8970: [1.25003, 1.75, 0, 0, 0.63889],
    8971: [1.25003, 1.75, 0, 0, 0.63889],
    9115: [0.64502, 1.155, 0, 0, 0.875],
    9116: [1e-5, 0.6, 0, 0, 0.875],
    9117: [0.64502, 1.155, 0, 0, 0.875],
    9118: [0.64502, 1.155, 0, 0, 0.875],
    9119: [1e-5, 0.6, 0, 0, 0.875],
    9120: [0.64502, 1.155, 0, 0, 0.875],
    9121: [0.64502, 1.155, 0, 0, 0.66667],
    9122: [-99e-5, 0.601, 0, 0, 0.66667],
    9123: [0.64502, 1.155, 0, 0, 0.66667],
    9124: [0.64502, 1.155, 0, 0, 0.66667],
    9125: [-99e-5, 0.601, 0, 0, 0.66667],
    9126: [0.64502, 1.155, 0, 0, 0.66667],
    9127: [1e-5, 0.9, 0, 0, 0.88889],
    9128: [0.65002, 1.15, 0, 0, 0.88889],
    9129: [0.90001, 0, 0, 0, 0.88889],
    9130: [0, 0.3, 0, 0, 0.88889],
    9131: [1e-5, 0.9, 0, 0, 0.88889],
    9132: [0.65002, 1.15, 0, 0, 0.88889],
    9133: [0.90001, 0, 0, 0, 0.88889],
    9143: [0.88502, 0.915, 0, 0, 1.05556],
    10216: [1.25003, 1.75, 0, 0, 0.80556],
    10217: [1.25003, 1.75, 0, 0, 0.80556],
    57344: [-499e-5, 0.605, 0, 0, 1.05556],
    57345: [-499e-5, 0.605, 0, 0, 1.05556],
    57680: [0, 0.12, 0, 0, 0.45],
    57681: [0, 0.12, 0, 0, 0.45],
    57682: [0, 0.12, 0, 0, 0.45],
    57683: [0, 0.12, 0, 0, 0.45]
  },
  "Typewriter-Regular": {
    32: [0, 0, 0, 0, 0.525],
    33: [0, 0.61111, 0, 0, 0.525],
    34: [0, 0.61111, 0, 0, 0.525],
    35: [0, 0.61111, 0, 0, 0.525],
    36: [0.08333, 0.69444, 0, 0, 0.525],
    37: [0.08333, 0.69444, 0, 0, 0.525],
    38: [0, 0.61111, 0, 0, 0.525],
    39: [0, 0.61111, 0, 0, 0.525],
    40: [0.08333, 0.69444, 0, 0, 0.525],
    41: [0.08333, 0.69444, 0, 0, 0.525],
    42: [0, 0.52083, 0, 0, 0.525],
    43: [-0.08056, 0.53055, 0, 0, 0.525],
    44: [0.13889, 0.125, 0, 0, 0.525],
    45: [-0.08056, 0.53055, 0, 0, 0.525],
    46: [0, 0.125, 0, 0, 0.525],
    47: [0.08333, 0.69444, 0, 0, 0.525],
    48: [0, 0.61111, 0, 0, 0.525],
    49: [0, 0.61111, 0, 0, 0.525],
    50: [0, 0.61111, 0, 0, 0.525],
    51: [0, 0.61111, 0, 0, 0.525],
    52: [0, 0.61111, 0, 0, 0.525],
    53: [0, 0.61111, 0, 0, 0.525],
    54: [0, 0.61111, 0, 0, 0.525],
    55: [0, 0.61111, 0, 0, 0.525],
    56: [0, 0.61111, 0, 0, 0.525],
    57: [0, 0.61111, 0, 0, 0.525],
    58: [0, 0.43056, 0, 0, 0.525],
    59: [0.13889, 0.43056, 0, 0, 0.525],
    60: [-0.05556, 0.55556, 0, 0, 0.525],
    61: [-0.19549, 0.41562, 0, 0, 0.525],
    62: [-0.05556, 0.55556, 0, 0, 0.525],
    63: [0, 0.61111, 0, 0, 0.525],
    64: [0, 0.61111, 0, 0, 0.525],
    65: [0, 0.61111, 0, 0, 0.525],
    66: [0, 0.61111, 0, 0, 0.525],
    67: [0, 0.61111, 0, 0, 0.525],
    68: [0, 0.61111, 0, 0, 0.525],
    69: [0, 0.61111, 0, 0, 0.525],
    70: [0, 0.61111, 0, 0, 0.525],
    71: [0, 0.61111, 0, 0, 0.525],
    72: [0, 0.61111, 0, 0, 0.525],
    73: [0, 0.61111, 0, 0, 0.525],
    74: [0, 0.61111, 0, 0, 0.525],
    75: [0, 0.61111, 0, 0, 0.525],
    76: [0, 0.61111, 0, 0, 0.525],
    77: [0, 0.61111, 0, 0, 0.525],
    78: [0, 0.61111, 0, 0, 0.525],
    79: [0, 0.61111, 0, 0, 0.525],
    80: [0, 0.61111, 0, 0, 0.525],
    81: [0.13889, 0.61111, 0, 0, 0.525],
    82: [0, 0.61111, 0, 0, 0.525],
    83: [0, 0.61111, 0, 0, 0.525],
    84: [0, 0.61111, 0, 0, 0.525],
    85: [0, 0.61111, 0, 0, 0.525],
    86: [0, 0.61111, 0, 0, 0.525],
    87: [0, 0.61111, 0, 0, 0.525],
    88: [0, 0.61111, 0, 0, 0.525],
    89: [0, 0.61111, 0, 0, 0.525],
    90: [0, 0.61111, 0, 0, 0.525],
    91: [0.08333, 0.69444, 0, 0, 0.525],
    92: [0.08333, 0.69444, 0, 0, 0.525],
    93: [0.08333, 0.69444, 0, 0, 0.525],
    94: [0, 0.61111, 0, 0, 0.525],
    95: [0.09514, 0, 0, 0, 0.525],
    96: [0, 0.61111, 0, 0, 0.525],
    97: [0, 0.43056, 0, 0, 0.525],
    98: [0, 0.61111, 0, 0, 0.525],
    99: [0, 0.43056, 0, 0, 0.525],
    100: [0, 0.61111, 0, 0, 0.525],
    101: [0, 0.43056, 0, 0, 0.525],
    102: [0, 0.61111, 0, 0, 0.525],
    103: [0.22222, 0.43056, 0, 0, 0.525],
    104: [0, 0.61111, 0, 0, 0.525],
    105: [0, 0.61111, 0, 0, 0.525],
    106: [0.22222, 0.61111, 0, 0, 0.525],
    107: [0, 0.61111, 0, 0, 0.525],
    108: [0, 0.61111, 0, 0, 0.525],
    109: [0, 0.43056, 0, 0, 0.525],
    110: [0, 0.43056, 0, 0, 0.525],
    111: [0, 0.43056, 0, 0, 0.525],
    112: [0.22222, 0.43056, 0, 0, 0.525],
    113: [0.22222, 0.43056, 0, 0, 0.525],
    114: [0, 0.43056, 0, 0, 0.525],
    115: [0, 0.43056, 0, 0, 0.525],
    116: [0, 0.55358, 0, 0, 0.525],
    117: [0, 0.43056, 0, 0, 0.525],
    118: [0, 0.43056, 0, 0, 0.525],
    119: [0, 0.43056, 0, 0, 0.525],
    120: [0, 0.43056, 0, 0, 0.525],
    121: [0.22222, 0.43056, 0, 0, 0.525],
    122: [0, 0.43056, 0, 0, 0.525],
    123: [0.08333, 0.69444, 0, 0, 0.525],
    124: [0.08333, 0.69444, 0, 0, 0.525],
    125: [0.08333, 0.69444, 0, 0, 0.525],
    126: [0, 0.61111, 0, 0, 0.525],
    127: [0, 0.61111, 0, 0, 0.525],
    160: [0, 0, 0, 0, 0.525],
    176: [0, 0.61111, 0, 0, 0.525],
    184: [0.19445, 0, 0, 0, 0.525],
    305: [0, 0.43056, 0, 0, 0.525],
    567: [0.22222, 0.43056, 0, 0, 0.525],
    711: [0, 0.56597, 0, 0, 0.525],
    713: [0, 0.56555, 0, 0, 0.525],
    714: [0, 0.61111, 0, 0, 0.525],
    715: [0, 0.61111, 0, 0, 0.525],
    728: [0, 0.61111, 0, 0, 0.525],
    730: [0, 0.61111, 0, 0, 0.525],
    770: [0, 0.61111, 0, 0, 0.525],
    771: [0, 0.61111, 0, 0, 0.525],
    776: [0, 0.61111, 0, 0, 0.525],
    915: [0, 0.61111, 0, 0, 0.525],
    916: [0, 0.61111, 0, 0, 0.525],
    920: [0, 0.61111, 0, 0, 0.525],
    923: [0, 0.61111, 0, 0, 0.525],
    926: [0, 0.61111, 0, 0, 0.525],
    928: [0, 0.61111, 0, 0, 0.525],
    931: [0, 0.61111, 0, 0, 0.525],
    933: [0, 0.61111, 0, 0, 0.525],
    934: [0, 0.61111, 0, 0, 0.525],
    936: [0, 0.61111, 0, 0, 0.525],
    937: [0, 0.61111, 0, 0, 0.525],
    8216: [0, 0.61111, 0, 0, 0.525],
    8217: [0, 0.61111, 0, 0, 0.525],
    8242: [0, 0.61111, 0, 0, 0.525],
    9251: [0.11111, 0.21944, 0, 0, 0.525]
  }
}, N0 = {
  slant: [0.25, 0.25, 0.25],
  // sigma1
  space: [0, 0, 0],
  // sigma2
  stretch: [0, 0, 0],
  // sigma3
  shrink: [0, 0, 0],
  // sigma4
  xHeight: [0.431, 0.431, 0.431],
  // sigma5
  quad: [1, 1.171, 1.472],
  // sigma6
  extraSpace: [0, 0, 0],
  // sigma7
  num1: [0.677, 0.732, 0.925],
  // sigma8
  num2: [0.394, 0.384, 0.387],
  // sigma9
  num3: [0.444, 0.471, 0.504],
  // sigma10
  denom1: [0.686, 0.752, 1.025],
  // sigma11
  denom2: [0.345, 0.344, 0.532],
  // sigma12
  sup1: [0.413, 0.503, 0.504],
  // sigma13
  sup2: [0.363, 0.431, 0.404],
  // sigma14
  sup3: [0.289, 0.286, 0.294],
  // sigma15
  sub1: [0.15, 0.143, 0.2],
  // sigma16
  sub2: [0.247, 0.286, 0.4],
  // sigma17
  supDrop: [0.386, 0.353, 0.494],
  // sigma18
  subDrop: [0.05, 0.071, 0.1],
  // sigma19
  delim1: [2.39, 1.7, 1.98],
  // sigma20
  delim2: [1.01, 1.157, 1.42],
  // sigma21
  axisHeight: [0.25, 0.25, 0.25],
  // sigma22
  // These font metrics are extracted from TeX by using tftopl on cmex10.tfm;
  // they correspond to the font parameters of the extension fonts (family 3).
  // See the TeXbook, page 441. In AMSTeX, the extension fonts scale; to
  // match cmex7, we'd use cmex7.tfm values for script and scriptscript
  // values.
  defaultRuleThickness: [0.04, 0.049, 0.049],
  // xi8; cmex7: 0.049
  bigOpSpacing1: [0.111, 0.111, 0.111],
  // xi9
  bigOpSpacing2: [0.166, 0.166, 0.166],
  // xi10
  bigOpSpacing3: [0.2, 0.2, 0.2],
  // xi11
  bigOpSpacing4: [0.6, 0.611, 0.611],
  // xi12; cmex7: 0.611
  bigOpSpacing5: [0.1, 0.143, 0.143],
  // xi13; cmex7: 0.143
  // The \sqrt rule width is taken from the height of the surd character.
  // Since we use the same font at all sizes, this thickness doesn't scale.
  sqrtRuleThickness: [0.04, 0.04, 0.04],
  // This value determines how large a pt is, for metrics which are defined
  // in terms of pts.
  // This value is also used in katex.scss; if you change it make sure the
  // values match.
  ptPerEm: [10, 10, 10],
  // The space between adjacent `|` columns in an array definition. From
  // `\showthe\doublerulesep` in LaTeX. Equals 2.0 / ptPerEm.
  doubleRuleSep: [0.2, 0.2, 0.2],
  // The width of separator lines in {array} environments. From
  // `\showthe\arrayrulewidth` in LaTeX. Equals 0.4 / ptPerEm.
  arrayRuleWidth: [0.04, 0.04, 0.04],
  // Two values from LaTeX source2e:
  fboxsep: [0.3, 0.3, 0.3],
  //        3 pt / ptPerEm
  fboxrule: [0.04, 0.04, 0.04]
  // 0.4 pt / ptPerEm
}, kr = {
  // Latin-1
  \u00C5: "A",
  \u00D0: "D",
  \u00DE: "o",
  \u00E5: "a",
  \u00F0: "d",
  \u00FE: "o",
  // Cyrillic
  \u0410: "A",
  \u0411: "B",
  \u0412: "B",
  \u0413: "F",
  \u0414: "A",
  \u0415: "E",
  \u0416: "K",
  \u0417: "3",
  \u0418: "N",
  \u0419: "N",
  \u041A: "K",
  \u041B: "N",
  \u041C: "M",
  \u041D: "H",
  \u041E: "O",
  \u041F: "N",
  \u0420: "P",
  \u0421: "C",
  \u0422: "T",
  \u0423: "y",
  \u0424: "O",
  \u0425: "X",
  \u0426: "U",
  \u0427: "h",
  \u0428: "W",
  \u0429: "W",
  \u042A: "B",
  \u042B: "X",
  \u042C: "B",
  \u042D: "3",
  \u042E: "X",
  \u042F: "R",
  \u0430: "a",
  \u0431: "b",
  \u0432: "a",
  \u0433: "r",
  \u0434: "y",
  \u0435: "e",
  \u0436: "m",
  \u0437: "e",
  \u0438: "n",
  \u0439: "n",
  \u043A: "n",
  \u043B: "n",
  \u043C: "m",
  \u043D: "n",
  \u043E: "o",
  \u043F: "n",
  \u0440: "p",
  \u0441: "c",
  \u0442: "o",
  \u0443: "y",
  \u0444: "b",
  \u0445: "x",
  \u0446: "n",
  \u0447: "n",
  \u0448: "w",
  \u0449: "w",
  \u044A: "a",
  \u044B: "m",
  \u044C: "a",
  \u044D: "e",
  \u044E: "m",
  \u044F: "r"
};
function Qt(r, e, t) {
  if (!Oe[e])
    throw new Error("Font metrics not found for font: " + e + ".");
  var a = r.charCodeAt(0), n = Oe[e][a];
  if (!n && r[0] in kr && (a = kr[r[0]].charCodeAt(0), n = Oe[e][a]), !n && t === "text" && fa(a) && (n = Oe[e][77]), n)
    return {
      depth: n[0],
      height: n[1],
      italic: n[2],
      skew: n[3],
      width: n[4]
    };
}
var gt = {};
function ai(r) {
  var e;
  if (r >= 5 ? e = 0 : r >= 3 ? e = 1 : e = 2, !gt[e]) {
    var t = gt[e] = {
      cssEmPerMu: N0.quad[e] / 18
    };
    for (var a in N0)
      N0.hasOwnProperty(a) && (t[a] = N0[a][e]);
  }
  return gt[e];
}
var ni = [
  // Each element contains [textsize, scriptsize, scriptscriptsize].
  // The size mappings are taken from TeX with \normalsize=10pt.
  [1, 1, 1],
  // size1: [5, 5, 5]              \tiny
  [2, 1, 1],
  // size2: [6, 5, 5]
  [3, 1, 1],
  // size3: [7, 5, 5]              \scriptsize
  [4, 2, 1],
  // size4: [8, 6, 5]              \footnotesize
  [5, 2, 1],
  // size5: [9, 6, 5]              \small
  [6, 3, 1],
  // size6: [10, 7, 5]             \normalsize
  [7, 4, 2],
  // size7: [12, 8, 6]             \large
  [8, 6, 3],
  // size8: [14.4, 10, 7]          \Large
  [9, 7, 6],
  // size9: [17.28, 12, 10]        \LARGE
  [10, 8, 7],
  // size10: [20.74, 14.4, 12]     \huge
  [11, 10, 9]
  // size11: [24.88, 20.74, 17.28] \HUGE
], Tr = [
  // fontMetrics.js:getGlobalMetrics also uses size indexes, so if
  // you change size indexes, change that function.
  0.5,
  0.6,
  0.7,
  0.8,
  0.9,
  1,
  1.2,
  1.44,
  1.728,
  2.074,
  2.488
], Mr = function(e, t) {
  return t.size < 2 ? e : ni[e - 1][t.size - 1];
};
class qe {
  // A font family applies to a group of fonts (i.e. SansSerif), while a font
  // represents a specific font (i.e. SansSerif Bold).
  // See: https://tex.stackexchange.com/questions/22350/difference-between-textrm-and-mathrm
  /**
   * The base size index.
   */
  constructor(e) {
    this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = e.style, this.color = e.color, this.size = e.size || qe.BASESIZE, this.textSize = e.textSize || this.size, this.phantom = !!e.phantom, this.font = e.font || "", this.fontFamily = e.fontFamily || "", this.fontWeight = e.fontWeight || "", this.fontShape = e.fontShape || "", this.sizeMultiplier = Tr[this.size - 1], this.maxSize = e.maxSize, this.minRuleThickness = e.minRuleThickness, this._fontMetrics = void 0;
  }
  /**
   * Returns a new options object with the same properties as "this".  Properties
   * from "extension" will be copied to the new options object.
   */
  extend(e) {
    var t = {
      style: this.style,
      size: this.size,
      textSize: this.textSize,
      color: this.color,
      phantom: this.phantom,
      font: this.font,
      fontFamily: this.fontFamily,
      fontWeight: this.fontWeight,
      fontShape: this.fontShape,
      maxSize: this.maxSize,
      minRuleThickness: this.minRuleThickness
    };
    for (var a in e)
      e.hasOwnProperty(a) && (t[a] = e[a]);
    return new qe(t);
  }
  /**
   * Return an options object with the given style. If `this.style === style`,
   * returns `this`.
   */
  havingStyle(e) {
    return this.style === e ? this : this.extend({
      style: e,
      size: Mr(this.textSize, e)
    });
  }
  /**
   * Return an options object with a cramped version of the current style. If
   * the current style is cramped, returns `this`.
   */
  havingCrampedStyle() {
    return this.havingStyle(this.style.cramp());
  }
  /**
   * Return an options object with the given size and in at least `\textstyle`.
   * Returns `this` if appropriate.
   */
  havingSize(e) {
    return this.size === e && this.textSize === e ? this : this.extend({
      style: this.style.text(),
      size: e,
      textSize: e,
      sizeMultiplier: Tr[e - 1]
    });
  }
  /**
   * Like `this.havingSize(BASESIZE).havingStyle(style)`. If `style` is omitted,
   * changes to at least `\textstyle`.
   */
  havingBaseStyle(e) {
    e = e || this.style.text();
    var t = Mr(qe.BASESIZE, e);
    return this.size === t && this.textSize === qe.BASESIZE && this.style === e ? this : this.extend({
      style: e,
      size: t
    });
  }
  /**
   * Remove the effect of sizing changes such as \Huge.
   * Keep the effect of the current style, such as \scriptstyle.
   */
  havingBaseSizing() {
    var e;
    switch (this.style.id) {
      case 4:
      case 5:
        e = 3;
        break;
      case 6:
      case 7:
        e = 1;
        break;
      default:
        e = 6;
    }
    return this.extend({
      style: this.style.text(),
      size: e
    });
  }
  /**
   * Create a new options object with the given color.
   */
  withColor(e) {
    return this.extend({
      color: e
    });
  }
  /**
   * Create a new options object with "phantom" set to true.
   */
  withPhantom() {
    return this.extend({
      phantom: !0
    });
  }
  /**
   * Creates a new options object with the given math font or old text font.
   * @type {[type]}
   */
  withFont(e) {
    return this.extend({
      font: e
    });
  }
  /**
   * Create a new options objects with the given fontFamily.
   */
  withTextFontFamily(e) {
    return this.extend({
      fontFamily: e,
      font: ""
    });
  }
  /**
   * Creates a new options object with the given font weight
   */
  withTextFontWeight(e) {
    return this.extend({
      fontWeight: e,
      font: ""
    });
  }
  /**
   * Creates a new options object with the given font weight
   */
  withTextFontShape(e) {
    return this.extend({
      fontShape: e,
      font: ""
    });
  }
  /**
   * Return the CSS sizing classes required to switch from enclosing options
   * `oldOptions` to `this`. Returns an array of classes.
   */
  sizingClasses(e) {
    return e.size !== this.size ? ["sizing", "reset-size" + e.size, "size" + this.size] : [];
  }
  /**
   * Return the CSS sizing classes required to switch to the base size. Like
   * `this.havingSize(BASESIZE).sizingClasses(this)`.
   */
  baseSizingClasses() {
    return this.size !== qe.BASESIZE ? ["sizing", "reset-size" + this.size, "size" + qe.BASESIZE] : [];
  }
  /**
   * Return the font metrics for this size.
   */
  fontMetrics() {
    return this._fontMetrics || (this._fontMetrics = ai(this.size)), this._fontMetrics;
  }
  /**
   * Gets the CSS color of the current options object
   */
  getColor() {
    return this.phantom ? "transparent" : this.color;
  }
}
qe.BASESIZE = 6;
var Ot = {
  // https://en.wikibooks.org/wiki/LaTeX/Lengths and
  // https://tex.stackexchange.com/a/8263
  pt: 1,
  // TeX point
  mm: 7227 / 2540,
  // millimeter
  cm: 7227 / 254,
  // centimeter
  in: 72.27,
  // inch
  bp: 803 / 800,
  // big (PostScript) points
  pc: 12,
  // pica
  dd: 1238 / 1157,
  // didot
  cc: 14856 / 1157,
  // cicero (12 didot)
  nd: 685 / 642,
  // new didot
  nc: 1370 / 107,
  // new cicero (12 new didot)
  sp: 1 / 65536,
  // scaled point (TeX's internal smallest unit)
  // https://tex.stackexchange.com/a/41371
  px: 803 / 800
  // \pdfpxdimen defaults to 1 bp in pdfTeX and LuaTeX
}, ii = {
  ex: !0,
  em: !0,
  mu: !0
}, va = function(e) {
  return typeof e != "string" && (e = e.unit), e in Ot || e in ii || e === "ex";
}, J = function(e, t) {
  var a;
  if (e.unit in Ot)
    a = Ot[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
  else if (e.unit === "mu")
    a = t.fontMetrics().cssEmPerMu;
  else {
    var n;
    if (t.style.isTight() ? n = t.havingStyle(t.style.text()) : n = t, e.unit === "ex")
      a = n.fontMetrics().xHeight;
    else if (e.unit === "em")
      a = n.fontMetrics().quad;
    else
      throw new k("Invalid unit: '" + e.unit + "'");
    n !== t && (a *= n.sizeMultiplier / t.sizeMultiplier);
  }
  return Math.min(e.number * a, t.maxSize);
}, M = function(e) {
  return +e.toFixed(4) + "em";
}, Ke = function(e) {
  return e.filter((t) => t).join(" ");
}, ga = function(e, t, a) {
  if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var n = t.getColor();
    n && (this.style.color = n);
  }
}, ba = function(e) {
  var t = document.createElement(e);
  t.className = Ke(this.classes);
  for (var a in this.style)
    this.style.hasOwnProperty(a) && (t.style[a] = this.style[a]);
  for (var n in this.attributes)
    this.attributes.hasOwnProperty(n) && t.setAttribute(n, this.attributes[n]);
  for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode());
  return t;
}, si = /[\s"'>/=\x00-\x1f]/, ya = function(e) {
  var t = "<" + e;
  this.classes.length && (t += ' class="' + ue(Ke(this.classes)) + '"');
  var a = "";
  for (var n in this.style)
    this.style.hasOwnProperty(n) && (a += Zt(n) + ":" + this.style[n] + ";");
  a && (t += ' style="' + ue(a) + '"');
  for (var i in this.attributes)
    if (this.attributes.hasOwnProperty(i)) {
      if (si.test(i))
        throw new k("Invalid attribute name '" + i + "'");
      t += " " + i + '="' + ue(this.attributes[i]) + '"';
    }
  t += ">";
  for (var l = 0; l < this.children.length; l++)
    t += this.children[l].toMarkup();
  return t += "</" + e + ">", t;
};
class Q0 {
  constructor(e, t, a, n) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, ga.call(this, e, a, n), this.children = t || [];
  }
  /**
   * Sets an arbitrary attribute on the span. Warning: use this wisely. Not
   * all browsers support attributes the same, and having too many custom
   * attributes is probably bad.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  toNode() {
    return ba.call(this, "span");
  }
  toMarkup() {
    return ya.call(this, "span");
  }
}
class xa {
  constructor(e, t, a, n) {
    this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, ga.call(this, t, n), this.children = a || [], this.setAttribute("href", e);
  }
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  toNode() {
    return ba.call(this, "a");
  }
  toMarkup() {
    return ya.call(this, "a");
  }
}
class oi {
  constructor(e, t, a) {
    this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.style = a;
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  toNode() {
    var e = document.createElement("img");
    e.src = this.src, e.alt = this.alt, e.className = "mord";
    for (var t in this.style)
      this.style.hasOwnProperty(t) && (e.style[t] = this.style[t]);
    return e;
  }
  toMarkup() {
    var e = '<img src="' + ue(this.src) + '"' + (' alt="' + ue(this.alt) + '"'), t = "";
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (t += Zt(a) + ":" + this.style[a] + ";");
    return t && (e += ' style="' + ue(t) + '"'), e += "'/>", e;
  }
}
var li = {
  \u00EE: "\u0131\u0302",
  \u00EF: "\u0131\u0308",
  \u00ED: "\u0131\u0301",
  // 'ī': '\u0131\u0304', // enable when we add Extended Latin
  \u00EC: "\u0131\u0300"
};
class Me {
  constructor(e, t, a, n, i, l, u, h) {
    this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = a || 0, this.italic = n || 0, this.skew = i || 0, this.width = l || 0, this.classes = u || [], this.style = h || {}, this.maxFontSize = 0;
    var f = Wn(this.text.charCodeAt(0));
    f && this.classes.push(f + "_fallback"), /[îïíì]/.test(this.text) && (this.text = li[this.text]);
  }
  hasClass(e) {
    return this.classes.includes(e);
  }
  /**
   * Creates a text node or span from a symbol node. Note that a span is only
   * created if it is needed.
   */
  toNode() {
    var e = document.createTextNode(this.text), t = null;
    this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = M(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = Ke(this.classes));
    for (var a in this.style)
      this.style.hasOwnProperty(a) && (t = t || document.createElement("span"), t.style[a] = this.style[a]);
    return t ? (t.appendChild(e), t) : e;
  }
  /**
   * Creates markup for a symbol node.
   */
  toMarkup() {
    var e = !1, t = "<span";
    this.classes.length && (e = !0, t += ' class="', t += ue(Ke(this.classes)), t += '"');
    var a = "";
    this.italic > 0 && (a += "margin-right:" + this.italic + "em;");
    for (var n in this.style)
      this.style.hasOwnProperty(n) && (a += Zt(n) + ":" + this.style[n] + ";");
    a && (e = !0, t += ' style="' + ue(a) + '"');
    var i = ue(this.text);
    return e ? (t += ">", t += i, t += "</span>", t) : i;
  }
}
class _e {
  constructor(e, t) {
    this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg");
    for (var a in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, a) && t.setAttribute(a, this.attributes[a]);
    for (var n = 0; n < this.children.length; n++)
      t.appendChild(this.children[n].toNode());
    return t;
  }
  toMarkup() {
    var e = '<svg xmlns="http://www.w3.org/2000/svg"';
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + ue(this.attributes[t]) + '"');
    e += ">";
    for (var a = 0; a < this.children.length; a++)
      e += this.children[a].toMarkup();
    return e += "</svg>", e;
  }
}
class r0 {
  constructor(e, t) {
    this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path");
    return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", Ar[this.pathName]), t;
  }
  toMarkup() {
    return this.alternate ? '<path d="' + ue(this.alternate) + '"/>' : '<path d="' + ue(Ar[this.pathName]) + '"/>';
  }
}
class Cr {
  constructor(e) {
    this.attributes = void 0, this.attributes = e || {};
  }
  toNode() {
    var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line");
    for (var a in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, a) && t.setAttribute(a, this.attributes[a]);
    return t;
  }
  toMarkup() {
    var e = "<line";
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="' + ue(this.attributes[t]) + '"');
    return e += "/>", e;
  }
}
function Er(r) {
  if (r instanceof Me)
    return r;
  throw new Error("Expected symbolNode but got " + String(r) + ".");
}
function ui(r) {
  if (r instanceof Q0)
    return r;
  throw new Error("Expected span<HtmlDomNode> but got " + String(r) + ".");
}
var ci = {
  bin: 1,
  close: 1,
  inner: 1,
  open: 1,
  punct: 1,
  rel: 1
}, hi = {
  "accent-token": 1,
  mathord: 1,
  "op-token": 1,
  spacing: 1,
  textord: 1
}, K = {
  math: {},
  text: {}
};
function s(r, e, t, a, n, i) {
  K[r][n] = {
    font: e,
    group: t,
    replace: a
  }, i && a && (K[r][a] = K[r][n]);
}
var o = "math", w = "text", c = "main", d = "ams", _ = "accent-token", z = "bin", pe = "close", g0 = "inner", F = "mathord", ne = "op-token", ye = "open", et = "punct", p = "rel", He = "spacing", g = "textord";
s(o, c, p, "\u2261", "\\equiv", !0);
s(o, c, p, "\u227A", "\\prec", !0);
s(o, c, p, "\u227B", "\\succ", !0);
s(o, c, p, "\u223C", "\\sim", !0);
s(o, c, p, "\u22A5", "\\perp");
s(o, c, p, "\u2AAF", "\\preceq", !0);
s(o, c, p, "\u2AB0", "\\succeq", !0);
s(o, c, p, "\u2243", "\\simeq", !0);
s(o, c, p, "\u2223", "\\mid", !0);
s(o, c, p, "\u226A", "\\ll", !0);
s(o, c, p, "\u226B", "\\gg", !0);
s(o, c, p, "\u224D", "\\asymp", !0);
s(o, c, p, "\u2225", "\\parallel");
s(o, c, p, "\u22C8", "\\bowtie", !0);
s(o, c, p, "\u2323", "\\smile", !0);
s(o, c, p, "\u2291", "\\sqsubseteq", !0);
s(o, c, p, "\u2292", "\\sqsupseteq", !0);
s(o, c, p, "\u2250", "\\doteq", !0);
s(o, c, p, "\u2322", "\\frown", !0);
s(o, c, p, "\u220B", "\\ni", !0);
s(o, c, p, "\u221D", "\\propto", !0);
s(o, c, p, "\u22A2", "\\vdash", !0);
s(o, c, p, "\u22A3", "\\dashv", !0);
s(o, c, p, "\u220B", "\\owns");
s(o, c, et, ".", "\\ldotp");
s(o, c, et, "\u22C5", "\\cdotp");
s(o, c, g, "#", "\\#");
s(w, c, g, "#", "\\#");
s(o, c, g, "&", "\\&");
s(w, c, g, "&", "\\&");
s(o, c, g, "\u2135", "\\aleph", !0);
s(o, c, g, "\u2200", "\\forall", !0);
s(o, c, g, "\u210F", "\\hbar", !0);
s(o, c, g, "\u2203", "\\exists", !0);
s(o, c, g, "\u2207", "\\nabla", !0);
s(o, c, g, "\u266D", "\\flat", !0);
s(o, c, g, "\u2113", "\\ell", !0);
s(o, c, g, "\u266E", "\\natural", !0);
s(o, c, g, "\u2663", "\\clubsuit", !0);
s(o, c, g, "\u2118", "\\wp", !0);
s(o, c, g, "\u266F", "\\sharp", !0);
s(o, c, g, "\u2662", "\\diamondsuit", !0);
s(o, c, g, "\u211C", "\\Re", !0);
s(o, c, g, "\u2661", "\\heartsuit", !0);
s(o, c, g, "\u2111", "\\Im", !0);
s(o, c, g, "\u2660", "\\spadesuit", !0);
s(o, c, g, "\xA7", "\\S", !0);
s(w, c, g, "\xA7", "\\S");
s(o, c, g, "\xB6", "\\P", !0);
s(w, c, g, "\xB6", "\\P");
s(o, c, g, "\u2020", "\\dag");
s(w, c, g, "\u2020", "\\dag");
s(w, c, g, "\u2020", "\\textdagger");
s(o, c, g, "\u2021", "\\ddag");
s(w, c, g, "\u2021", "\\ddag");
s(w, c, g, "\u2021", "\\textdaggerdbl");
s(o, c, pe, "\u23B1", "\\rmoustache", !0);
s(o, c, ye, "\u23B0", "\\lmoustache", !0);
s(o, c, pe, "\u27EF", "\\rgroup", !0);
s(o, c, ye, "\u27EE", "\\lgroup", !0);
s(o, c, z, "\u2213", "\\mp", !0);
s(o, c, z, "\u2296", "\\ominus", !0);
s(o, c, z, "\u228E", "\\uplus", !0);
s(o, c, z, "\u2293", "\\sqcap", !0);
s(o, c, z, "\u2217", "\\ast");
s(o, c, z, "\u2294", "\\sqcup", !0);
s(o, c, z, "\u25EF", "\\bigcirc", !0);
s(o, c, z, "\u2219", "\\bullet", !0);
s(o, c, z, "\u2021", "\\ddagger");
s(o, c, z, "\u2240", "\\wr", !0);
s(o, c, z, "\u2A3F", "\\amalg");
s(o, c, z, "&", "\\And");
s(o, c, p, "\u27F5", "\\longleftarrow", !0);
s(o, c, p, "\u21D0", "\\Leftarrow", !0);
s(o, c, p, "\u27F8", "\\Longleftarrow", !0);
s(o, c, p, "\u27F6", "\\longrightarrow", !0);
s(o, c, p, "\u21D2", "\\Rightarrow", !0);
s(o, c, p, "\u27F9", "\\Longrightarrow", !0);
s(o, c, p, "\u2194", "\\leftrightarrow", !0);
s(o, c, p, "\u27F7", "\\longleftrightarrow", !0);
s(o, c, p, "\u21D4", "\\Leftrightarrow", !0);
s(o, c, p, "\u27FA", "\\Longleftrightarrow", !0);
s(o, c, p, "\u21A6", "\\mapsto", !0);
s(o, c, p, "\u27FC", "\\longmapsto", !0);
s(o, c, p, "\u2197", "\\nearrow", !0);
s(o, c, p, "\u21A9", "\\hookleftarrow", !0);
s(o, c, p, "\u21AA", "\\hookrightarrow", !0);
s(o, c, p, "\u2198", "\\searrow", !0);
s(o, c, p, "\u21BC", "\\leftharpoonup", !0);
s(o, c, p, "\u21C0", "\\rightharpoonup", !0);
s(o, c, p, "\u2199", "\\swarrow", !0);
s(o, c, p, "\u21BD", "\\leftharpoondown", !0);
s(o, c, p, "\u21C1", "\\rightharpoondown", !0);
s(o, c, p, "\u2196", "\\nwarrow", !0);
s(o, c, p, "\u21CC", "\\rightleftharpoons", !0);
s(o, d, p, "\u226E", "\\nless", !0);
s(o, d, p, "\uE010", "\\@nleqslant");
s(o, d, p, "\uE011", "\\@nleqq");
s(o, d, p, "\u2A87", "\\lneq", !0);
s(o, d, p, "\u2268", "\\lneqq", !0);
s(o, d, p, "\uE00C", "\\@lvertneqq");
s(o, d, p, "\u22E6", "\\lnsim", !0);
s(o, d, p, "\u2A89", "\\lnapprox", !0);
s(o, d, p, "\u2280", "\\nprec", !0);
s(o, d, p, "\u22E0", "\\npreceq", !0);
s(o, d, p, "\u22E8", "\\precnsim", !0);
s(o, d, p, "\u2AB9", "\\precnapprox", !0);
s(o, d, p, "\u2241", "\\nsim", !0);
s(o, d, p, "\uE006", "\\@nshortmid");
s(o, d, p, "\u2224", "\\nmid", !0);
s(o, d, p, "\u22AC", "\\nvdash", !0);
s(o, d, p, "\u22AD", "\\nvDash", !0);
s(o, d, p, "\u22EA", "\\ntriangleleft");
s(o, d, p, "\u22EC", "\\ntrianglelefteq", !0);
s(o, d, p, "\u228A", "\\subsetneq", !0);
s(o, d, p, "\uE01A", "\\@varsubsetneq");
s(o, d, p, "\u2ACB", "\\subsetneqq", !0);
s(o, d, p, "\uE017", "\\@varsubsetneqq");
s(o, d, p, "\u226F", "\\ngtr", !0);
s(o, d, p, "\uE00F", "\\@ngeqslant");
s(o, d, p, "\uE00E", "\\@ngeqq");
s(o, d, p, "\u2A88", "\\gneq", !0);
s(o, d, p, "\u2269", "\\gneqq", !0);
s(o, d, p, "\uE00D", "\\@gvertneqq");
s(o, d, p, "\u22E7", "\\gnsim", !0);
s(o, d, p, "\u2A8A", "\\gnapprox", !0);
s(o, d, p, "\u2281", "\\nsucc", !0);
s(o, d, p, "\u22E1", "\\nsucceq", !0);
s(o, d, p, "\u22E9", "\\succnsim", !0);
s(o, d, p, "\u2ABA", "\\succnapprox", !0);
s(o, d, p, "\u2246", "\\ncong", !0);
s(o, d, p, "\uE007", "\\@nshortparallel");
s(o, d, p, "\u2226", "\\nparallel", !0);
s(o, d, p, "\u22AF", "\\nVDash", !0);
s(o, d, p, "\u22EB", "\\ntriangleright");
s(o, d, p, "\u22ED", "\\ntrianglerighteq", !0);
s(o, d, p, "\uE018", "\\@nsupseteqq");
s(o, d, p, "\u228B", "\\supsetneq", !0);
s(o, d, p, "\uE01B", "\\@varsupsetneq");
s(o, d, p, "\u2ACC", "\\supsetneqq", !0);
s(o, d, p, "\uE019", "\\@varsupsetneqq");
s(o, d, p, "\u22AE", "\\nVdash", !0);
s(o, d, p, "\u2AB5", "\\precneqq", !0);
s(o, d, p, "\u2AB6", "\\succneqq", !0);
s(o, d, p, "\uE016", "\\@nsubseteqq");
s(o, d, z, "\u22B4", "\\unlhd");
s(o, d, z, "\u22B5", "\\unrhd");
s(o, d, p, "\u219A", "\\nleftarrow", !0);
s(o, d, p, "\u219B", "\\nrightarrow", !0);
s(o, d, p, "\u21CD", "\\nLeftarrow", !0);
s(o, d, p, "\u21CF", "\\nRightarrow", !0);
s(o, d, p, "\u21AE", "\\nleftrightarrow", !0);
s(o, d, p, "\u21CE", "\\nLeftrightarrow", !0);
s(o, d, p, "\u25B3", "\\vartriangle");
s(o, d, g, "\u210F", "\\hslash");
s(o, d, g, "\u25BD", "\\triangledown");
s(o, d, g, "\u25CA", "\\lozenge");
s(o, d, g, "\u24C8", "\\circledS");
s(o, d, g, "\xAE", "\\circledR");
s(w, d, g, "\xAE", "\\circledR");
s(o, d, g, "\u2221", "\\measuredangle", !0);
s(o, d, g, "\u2204", "\\nexists");
s(o, d, g, "\u2127", "\\mho");
s(o, d, g, "\u2132", "\\Finv", !0);
s(o, d, g, "\u2141", "\\Game", !0);
s(o, d, g, "\u2035", "\\backprime");
s(o, d, g, "\u25B2", "\\blacktriangle");
s(o, d, g, "\u25BC", "\\blacktriangledown");
s(o, d, g, "\u25A0", "\\blacksquare");
s(o, d, g, "\u29EB", "\\blacklozenge");
s(o, d, g, "\u2605", "\\bigstar");
s(o, d, g, "\u2222", "\\sphericalangle", !0);
s(o, d, g, "\u2201", "\\complement", !0);
s(o, d, g, "\xF0", "\\eth", !0);
s(w, c, g, "\xF0", "\xF0");
s(o, d, g, "\u2571", "\\diagup");
s(o, d, g, "\u2572", "\\diagdown");
s(o, d, g, "\u25A1", "\\square");
s(o, d, g, "\u25A1", "\\Box");
s(o, d, g, "\u25CA", "\\Diamond");
s(o, d, g, "\xA5", "\\yen", !0);
s(w, d, g, "\xA5", "\\yen", !0);
s(o, d, g, "\u2713", "\\checkmark", !0);
s(w, d, g, "\u2713", "\\checkmark");
s(o, d, g, "\u2136", "\\beth", !0);
s(o, d, g, "\u2138", "\\daleth", !0);
s(o, d, g, "\u2137", "\\gimel", !0);
s(o, d, g, "\u03DD", "\\digamma", !0);
s(o, d, g, "\u03F0", "\\varkappa");
s(o, d, ye, "\u250C", "\\@ulcorner", !0);
s(o, d, pe, "\u2510", "\\@urcorner", !0);
s(o, d, ye, "\u2514", "\\@llcorner", !0);
s(o, d, pe, "\u2518", "\\@lrcorner", !0);
s(o, d, p, "\u2266", "\\leqq", !0);
s(o, d, p, "\u2A7D", "\\leqslant", !0);
s(o, d, p, "\u2A95", "\\eqslantless", !0);
s(o, d, p, "\u2272", "\\lesssim", !0);
s(o, d, p, "\u2A85", "\\lessapprox", !0);
s(o, d, p, "\u224A", "\\approxeq", !0);
s(o, d, z, "\u22D6", "\\lessdot");
s(o, d, p, "\u22D8", "\\lll", !0);
s(o, d, p, "\u2276", "\\lessgtr", !0);
s(o, d, p, "\u22DA", "\\lesseqgtr", !0);
s(o, d, p, "\u2A8B", "\\lesseqqgtr", !0);
s(o, d, p, "\u2251", "\\doteqdot");
s(o, d, p, "\u2253", "\\risingdotseq", !0);
s(o, d, p, "\u2252", "\\fallingdotseq", !0);
s(o, d, p, "\u223D", "\\backsim", !0);
s(o, d, p, "\u22CD", "\\backsimeq", !0);
s(o, d, p, "\u2AC5", "\\subseteqq", !0);
s(o, d, p, "\u22D0", "\\Subset", !0);
s(o, d, p, "\u228F", "\\sqsubset", !0);
s(o, d, p, "\u227C", "\\preccurlyeq", !0);
s(o, d, p, "\u22DE", "\\curlyeqprec", !0);
s(o, d, p, "\u227E", "\\precsim", !0);
s(o, d, p, "\u2AB7", "\\precapprox", !0);
s(o, d, p, "\u22B2", "\\vartriangleleft");
s(o, d, p, "\u22B4", "\\trianglelefteq");
s(o, d, p, "\u22A8", "\\vDash", !0);
s(o, d, p, "\u22AA", "\\Vvdash", !0);
s(o, d, p, "\u2323", "\\smallsmile");
s(o, d, p, "\u2322", "\\smallfrown");
s(o, d, p, "\u224F", "\\bumpeq", !0);
s(o, d, p, "\u224E", "\\Bumpeq", !0);
s(o, d, p, "\u2267", "\\geqq", !0);
s(o, d, p, "\u2A7E", "\\geqslant", !0);
s(o, d, p, "\u2A96", "\\eqslantgtr", !0);
s(o, d, p, "\u2273", "\\gtrsim", !0);
s(o, d, p, "\u2A86", "\\gtrapprox", !0);
s(o, d, z, "\u22D7", "\\gtrdot");
s(o, d, p, "\u22D9", "\\ggg", !0);
s(o, d, p, "\u2277", "\\gtrless", !0);
s(o, d, p, "\u22DB", "\\gtreqless", !0);
s(o, d, p, "\u2A8C", "\\gtreqqless", !0);
s(o, d, p, "\u2256", "\\eqcirc", !0);
s(o, d, p, "\u2257", "\\circeq", !0);
s(o, d, p, "\u225C", "\\triangleq", !0);
s(o, d, p, "\u223C", "\\thicksim");
s(o, d, p, "\u2248", "\\thickapprox");
s(o, d, p, "\u2AC6", "\\supseteqq", !0);
s(o, d, p, "\u22D1", "\\Supset", !0);
s(o, d, p, "\u2290", "\\sqsupset", !0);
s(o, d, p, "\u227D", "\\succcurlyeq", !0);
s(o, d, p, "\u22DF", "\\curlyeqsucc", !0);
s(o, d, p, "\u227F", "\\succsim", !0);
s(o, d, p, "\u2AB8", "\\succapprox", !0);
s(o, d, p, "\u22B3", "\\vartriangleright");
s(o, d, p, "\u22B5", "\\trianglerighteq");
s(o, d, p, "\u22A9", "\\Vdash", !0);
s(o, d, p, "\u2223", "\\shortmid");
s(o, d, p, "\u2225", "\\shortparallel");
s(o, d, p, "\u226C", "\\between", !0);
s(o, d, p, "\u22D4", "\\pitchfork", !0);
s(o, d, p, "\u221D", "\\varpropto");
s(o, d, p, "\u25C0", "\\blacktriangleleft");
s(o, d, p, "\u2234", "\\therefore", !0);
s(o, d, p, "\u220D", "\\backepsilon");
s(o, d, p, "\u25B6", "\\blacktriangleright");
s(o, d, p, "\u2235", "\\because", !0);
s(o, d, p, "\u22D8", "\\llless");
s(o, d, p, "\u22D9", "\\gggtr");
s(o, d, z, "\u22B2", "\\lhd");
s(o, d, z, "\u22B3", "\\rhd");
s(o, d, p, "\u2242", "\\eqsim", !0);
s(o, c, p, "\u22C8", "\\Join");
s(o, d, p, "\u2251", "\\Doteq", !0);
s(o, d, z, "\u2214", "\\dotplus", !0);
s(o, d, z, "\u2216", "\\smallsetminus");
s(o, d, z, "\u22D2", "\\Cap", !0);
s(o, d, z, "\u22D3", "\\Cup", !0);
s(o, d, z, "\u2A5E", "\\doublebarwedge", !0);
s(o, d, z, "\u229F", "\\boxminus", !0);
s(o, d, z, "\u229E", "\\boxplus", !0);
s(o, d, z, "\u22C7", "\\divideontimes", !0);
s(o, d, z, "\u22C9", "\\ltimes", !0);
s(o, d, z, "\u22CA", "\\rtimes", !0);
s(o, d, z, "\u22CB", "\\leftthreetimes", !0);
s(o, d, z, "\u22CC", "\\rightthreetimes", !0);
s(o, d, z, "\u22CF", "\\curlywedge", !0);
s(o, d, z, "\u22CE", "\\curlyvee", !0);
s(o, d, z, "\u229D", "\\circleddash", !0);
s(o, d, z, "\u229B", "\\circledast", !0);
s(o, d, z, "\u22C5", "\\centerdot");
s(o, d, z, "\u22BA", "\\intercal", !0);
s(o, d, z, "\u22D2", "\\doublecap");
s(o, d, z, "\u22D3", "\\doublecup");
s(o, d, z, "\u22A0", "\\boxtimes", !0);
s(o, d, p, "\u21E2", "\\dashrightarrow", !0);
s(o, d, p, "\u21E0", "\\dashleftarrow", !0);
s(o, d, p, "\u21C7", "\\leftleftarrows", !0);
s(o, d, p, "\u21C6", "\\leftrightarrows", !0);
s(o, d, p, "\u21DA", "\\Lleftarrow", !0);
s(o, d, p, "\u219E", "\\twoheadleftarrow", !0);
s(o, d, p, "\u21A2", "\\leftarrowtail", !0);
s(o, d, p, "\u21AB", "\\looparrowleft", !0);
s(o, d, p, "\u21CB", "\\leftrightharpoons", !0);
s(o, d, p, "\u21B6", "\\curvearrowleft", !0);
s(o, d, p, "\u21BA", "\\circlearrowleft", !0);
s(o, d, p, "\u21B0", "\\Lsh", !0);
s(o, d, p, "\u21C8", "\\upuparrows", !0);
s(o, d, p, "\u21BF", "\\upharpoonleft", !0);
s(o, d, p, "\u21C3", "\\downharpoonleft", !0);
s(o, c, p, "\u22B6", "\\origof", !0);
s(o, c, p, "\u22B7", "\\imageof", !0);
s(o, d, p, "\u22B8", "\\multimap", !0);
s(o, d, p, "\u21AD", "\\leftrightsquigarrow", !0);
s(o, d, p, "\u21C9", "\\rightrightarrows", !0);
s(o, d, p, "\u21C4", "\\rightleftarrows", !0);
s(o, d, p, "\u21A0", "\\twoheadrightarrow", !0);
s(o, d, p, "\u21A3", "\\rightarrowtail", !0);
s(o, d, p, "\u21AC", "\\looparrowright", !0);
s(o, d, p, "\u21B7", "\\curvearrowright", !0);
s(o, d, p, "\u21BB", "\\circlearrowright", !0);
s(o, d, p, "\u21B1", "\\Rsh", !0);
s(o, d, p, "\u21CA", "\\downdownarrows", !0);
s(o, d, p, "\u21BE", "\\upharpoonright", !0);
s(o, d, p, "\u21C2", "\\downharpoonright", !0);
s(o, d, p, "\u21DD", "\\rightsquigarrow", !0);
s(o, d, p, "\u21DD", "\\leadsto");
s(o, d, p, "\u21DB", "\\Rrightarrow", !0);
s(o, d, p, "\u21BE", "\\restriction");
s(o, c, g, "\u2018", "`");
s(o, c, g, "$", "\\$");
s(w, c, g, "$", "\\$");
s(w, c, g, "$", "\\textdollar");
s(o, c, g, "%", "\\%");
s(w, c, g, "%", "\\%");
s(o, c, g, "_", "\\_");
s(w, c, g, "_", "\\_");
s(w, c, g, "_", "\\textunderscore");
s(o, c, g, "\u2220", "\\angle", !0);
s(o, c, g, "\u221E", "\\infty", !0);
s(o, c, g, "\u2032", "\\prime");
s(o, c, g, "\u25B3", "\\triangle");
s(o, c, g, "\u0393", "\\Gamma", !0);
s(o, c, g, "\u0394", "\\Delta", !0);
s(o, c, g, "\u0398", "\\Theta", !0);
s(o, c, g, "\u039B", "\\Lambda", !0);
s(o, c, g, "\u039E", "\\Xi", !0);
s(o, c, g, "\u03A0", "\\Pi", !0);
s(o, c, g, "\u03A3", "\\Sigma", !0);
s(o, c, g, "\u03A5", "\\Upsilon", !0);
s(o, c, g, "\u03A6", "\\Phi", !0);
s(o, c, g, "\u03A8", "\\Psi", !0);
s(o, c, g, "\u03A9", "\\Omega", !0);
s(o, c, g, "A", "\u0391");
s(o, c, g, "B", "\u0392");
s(o, c, g, "E", "\u0395");
s(o, c, g, "Z", "\u0396");
s(o, c, g, "H", "\u0397");
s(o, c, g, "I", "\u0399");
s(o, c, g, "K", "\u039A");
s(o, c, g, "M", "\u039C");
s(o, c, g, "N", "\u039D");
s(o, c, g, "O", "\u039F");
s(o, c, g, "P", "\u03A1");
s(o, c, g, "T", "\u03A4");
s(o, c, g, "X", "\u03A7");
s(o, c, g, "\xAC", "\\neg", !0);
s(o, c, g, "\xAC", "\\lnot");
s(o, c, g, "\u22A4", "\\top");
s(o, c, g, "\u22A5", "\\bot");
s(o, c, g, "\u2205", "\\emptyset");
s(o, d, g, "\u2205", "\\varnothing");
s(o, c, F, "\u03B1", "\\alpha", !0);
s(o, c, F, "\u03B2", "\\beta", !0);
s(o, c, F, "\u03B3", "\\gamma", !0);
s(o, c, F, "\u03B4", "\\delta", !0);
s(o, c, F, "\u03F5", "\\epsilon", !0);
s(o, c, F, "\u03B6", "\\zeta", !0);
s(o, c, F, "\u03B7", "\\eta", !0);
s(o, c, F, "\u03B8", "\\theta", !0);
s(o, c, F, "\u03B9", "\\iota", !0);
s(o, c, F, "\u03BA", "\\kappa", !0);
s(o, c, F, "\u03BB", "\\lambda", !0);
s(o, c, F, "\u03BC", "\\mu", !0);
s(o, c, F, "\u03BD", "\\nu", !0);
s(o, c, F, "\u03BE", "\\xi", !0);
s(o, c, F, "\u03BF", "\\omicron", !0);
s(o, c, F, "\u03C0", "\\pi", !0);
s(o, c, F, "\u03C1", "\\rho", !0);
s(o, c, F, "\u03C3", "\\sigma", !0);
s(o, c, F, "\u03C4", "\\tau", !0);
s(o, c, F, "\u03C5", "\\upsilon", !0);
s(o, c, F, "\u03D5", "\\phi", !0);
s(o, c, F, "\u03C7", "\\chi", !0);
s(o, c, F, "\u03C8", "\\psi", !0);
s(o, c, F, "\u03C9", "\\omega", !0);
s(o, c, F, "\u03B5", "\\varepsilon", !0);
s(o, c, F, "\u03D1", "\\vartheta", !0);
s(o, c, F, "\u03D6", "\\varpi", !0);
s(o, c, F, "\u03F1", "\\varrho", !0);
s(o, c, F, "\u03C2", "\\varsigma", !0);
s(o, c, F, "\u03C6", "\\varphi", !0);
s(o, c, z, "\u2217", "*", !0);
s(o, c, z, "+", "+");
s(o, c, z, "\u2212", "-", !0);
s(o, c, z, "\u22C5", "\\cdot", !0);
s(o, c, z, "\u2218", "\\circ", !0);
s(o, c, z, "\xF7", "\\div", !0);
s(o, c, z, "\xB1", "\\pm", !0);
s(o, c, z, "\xD7", "\\times", !0);
s(o, c, z, "\u2229", "\\cap", !0);
s(o, c, z, "\u222A", "\\cup", !0);
s(o, c, z, "\u2216", "\\setminus", !0);
s(o, c, z, "\u2227", "\\land");
s(o, c, z, "\u2228", "\\lor");
s(o, c, z, "\u2227", "\\wedge", !0);
s(o, c, z, "\u2228", "\\vee", !0);
s(o, c, g, "\u221A", "\\surd");
s(o, c, ye, "\u27E8", "\\langle", !0);
s(o, c, ye, "\u2223", "\\lvert");
s(o, c, ye, "\u2225", "\\lVert");
s(o, c, pe, "?", "?");
s(o, c, pe, "!", "!");
s(o, c, pe, "\u27E9", "\\rangle", !0);
s(o, c, pe, "\u2223", "\\rvert");
s(o, c, pe, "\u2225", "\\rVert");
s(o, c, p, "=", "=");
s(o, c, p, ":", ":");
s(o, c, p, "\u2248", "\\approx", !0);
s(o, c, p, "\u2245", "\\cong", !0);
s(o, c, p, "\u2265", "\\ge");
s(o, c, p, "\u2265", "\\geq", !0);
s(o, c, p, "\u2190", "\\gets");
s(o, c, p, ">", "\\gt", !0);
s(o, c, p, "\u2208", "\\in", !0);
s(o, c, p, "\uE020", "\\@not");
s(o, c, p, "\u2282", "\\subset", !0);
s(o, c, p, "\u2283", "\\supset", !0);
s(o, c, p, "\u2286", "\\subseteq", !0);
s(o, c, p, "\u2287", "\\supseteq", !0);
s(o, d, p, "\u2288", "\\nsubseteq", !0);
s(o, d, p, "\u2289", "\\nsupseteq", !0);
s(o, c, p, "\u22A8", "\\models");
s(o, c, p, "\u2190", "\\leftarrow", !0);
s(o, c, p, "\u2264", "\\le");
s(o, c, p, "\u2264", "\\leq", !0);
s(o, c, p, "<", "\\lt", !0);
s(o, c, p, "\u2192", "\\rightarrow", !0);
s(o, c, p, "\u2192", "\\to");
s(o, d, p, "\u2271", "\\ngeq", !0);
s(o, d, p, "\u2270", "\\nleq", !0);
s(o, c, He, "\xA0", "\\ ");
s(o, c, He, "\xA0", "\\space");
s(o, c, He, "\xA0", "\\nobreakspace");
s(w, c, He, "\xA0", "\\ ");
s(w, c, He, "\xA0", " ");
s(w, c, He, "\xA0", "\\space");
s(w, c, He, "\xA0", "\\nobreakspace");
s(o, c, He, null, "\\nobreak");
s(o, c, He, null, "\\allowbreak");
s(o, c, et, ",", ",");
s(o, c, et, ";", ";");
s(o, d, z, "\u22BC", "\\barwedge", !0);
s(o, d, z, "\u22BB", "\\veebar", !0);
s(o, c, z, "\u2299", "\\odot", !0);
s(o, c, z, "\u2295", "\\oplus", !0);
s(o, c, z, "\u2297", "\\otimes", !0);
s(o, c, g, "\u2202", "\\partial", !0);
s(o, c, z, "\u2298", "\\oslash", !0);
s(o, d, z, "\u229A", "\\circledcirc", !0);
s(o, d, z, "\u22A1", "\\boxdot", !0);
s(o, c, z, "\u25B3", "\\bigtriangleup");
s(o, c, z, "\u25BD", "\\bigtriangledown");
s(o, c, z, "\u2020", "\\dagger");
s(o, c, z, "\u22C4", "\\diamond");
s(o, c, z, "\u22C6", "\\star");
s(o, c, z, "\u25C3", "\\triangleleft");
s(o, c, z, "\u25B9", "\\triangleright");
s(o, c, ye, "{", "\\{");
s(w, c, g, "{", "\\{");
s(w, c, g, "{", "\\textbraceleft");
s(o, c, pe, "}", "\\}");
s(w, c, g, "}", "\\}");
s(w, c, g, "}", "\\textbraceright");
s(o, c, ye, "{", "\\lbrace");
s(o, c, pe, "}", "\\rbrace");
s(o, c, ye, "[", "\\lbrack", !0);
s(w, c, g, "[", "\\lbrack", !0);
s(o, c, pe, "]", "\\rbrack", !0);
s(w, c, g, "]", "\\rbrack", !0);
s(o, c, ye, "(", "\\lparen", !0);
s(o, c, pe, ")", "\\rparen", !0);
s(w, c, g, "<", "\\textless", !0);
s(w, c, g, ">", "\\textgreater", !0);
s(o, c, ye, "\u230A", "\\lfloor", !0);
s(o, c, pe, "\u230B", "\\rfloor", !0);
s(o, c, ye, "\u2308", "\\lceil", !0);
s(o, c, pe, "\u2309", "\\rceil", !0);
s(o, c, g, "\\", "\\backslash");
s(o, c, g, "\u2223", "|");
s(o, c, g, "\u2223", "\\vert");
s(w, c, g, "|", "\\textbar", !0);
s(o, c, g, "\u2225", "\\|");
s(o, c, g, "\u2225", "\\Vert");
s(w, c, g, "\u2225", "\\textbardbl");
s(w, c, g, "~", "\\textasciitilde");
s(w, c, g, "\\", "\\textbackslash");
s(w, c, g, "^", "\\textasciicircum");
s(o, c, p, "\u2191", "\\uparrow", !0);
s(o, c, p, "\u21D1", "\\Uparrow", !0);
s(o, c, p, "\u2193", "\\downarrow", !0);
s(o, c, p, "\u21D3", "\\Downarrow", !0);
s(o, c, p, "\u2195", "\\updownarrow", !0);
s(o, c, p, "\u21D5", "\\Updownarrow", !0);
s(o, c, ne, "\u2210", "\\coprod");
s(o, c, ne, "\u22C1", "\\bigvee");
s(o, c, ne, "\u22C0", "\\bigwedge");
s(o, c, ne, "\u2A04", "\\biguplus");
s(o, c, ne, "\u22C2", "\\bigcap");
s(o, c, ne, "\u22C3", "\\bigcup");
s(o, c, ne, "\u222B", "\\int");
s(o, c, ne, "\u222B", "\\intop");
s(o, c, ne, "\u222C", "\\iint");
s(o, c, ne, "\u222D", "\\iiint");
s(o, c, ne, "\u220F", "\\prod");
s(o, c, ne, "\u2211", "\\sum");
s(o, c, ne, "\u2A02", "\\bigotimes");
s(o, c, ne, "\u2A01", "\\bigoplus");
s(o, c, ne, "\u2A00", "\\bigodot");
s(o, c, ne, "\u222E", "\\oint");
s(o, c, ne, "\u222F", "\\oiint");
s(o, c, ne, "\u2230", "\\oiiint");
s(o, c, ne, "\u2A06", "\\bigsqcup");
s(o, c, ne, "\u222B", "\\smallint");
s(w, c, g0, "\u2026", "\\textellipsis");
s(o, c, g0, "\u2026", "\\mathellipsis");
s(w, c, g0, "\u2026", "\\ldots", !0);
s(o, c, g0, "\u2026", "\\ldots", !0);
s(o, c, g0, "\u22EF", "\\@cdots", !0);
s(o, c, g0, "\u22F1", "\\ddots", !0);
s(o, c, g, "\u22EE", "\\varvdots");
s(w, c, g, "\u22EE", "\\varvdots");
s(o, c, _, "\u02CA", "\\acute");
s(o, c, _, "\u02CB", "\\grave");
s(o, c, _, "\xA8", "\\ddot");
s(o, c, _, "~", "\\tilde");
s(o, c, _, "\u02C9", "\\bar");
s(o, c, _, "\u02D8", "\\breve");
s(o, c, _, "\u02C7", "\\check");
s(o, c, _, "^", "\\hat");
s(o, c, _, "\u20D7", "\\vec");
s(o, c, _, "\u02D9", "\\dot");
s(o, c, _, "\u02DA", "\\mathring");
s(o, c, F, "\uE131", "\\@imath");
s(o, c, F, "\uE237", "\\@jmath");
s(o, c, g, "\u0131", "\u0131");
s(o, c, g, "\u0237", "\u0237");
s(w, c, g, "\u0131", "\\i", !0);
s(w, c, g, "\u0237", "\\j", !0);
s(w, c, g, "\xDF", "\\ss", !0);
s(w, c, g, "\xE6", "\\ae", !0);
s(w, c, g, "\u0153", "\\oe", !0);
s(w, c, g, "\xF8", "\\o", !0);
s(w, c, g, "\xC6", "\\AE", !0);
s(w, c, g, "\u0152", "\\OE", !0);
s(w, c, g, "\xD8", "\\O", !0);
s(w, c, _, "\u02CA", "\\'");
s(w, c, _, "\u02CB", "\\`");
s(w, c, _, "\u02C6", "\\^");
s(w, c, _, "\u02DC", "\\~");
s(w, c, _, "\u02C9", "\\=");
s(w, c, _, "\u02D8", "\\u");
s(w, c, _, "\u02D9", "\\.");
s(w, c, _, "\xB8", "\\c");
s(w, c, _, "\u02DA", "\\r");
s(w, c, _, "\u02C7", "\\v");
s(w, c, _, "\xA8", '\\"');
s(w, c, _, "\u02DD", "\\H");
s(w, c, _, "\u25EF", "\\textcircled");
var wa = {
  "--": !0,
  "---": !0,
  "``": !0,
  "''": !0
};
s(w, c, g, "\u2013", "--", !0);
s(w, c, g, "\u2013", "\\textendash");
s(w, c, g, "\u2014", "---", !0);
s(w, c, g, "\u2014", "\\textemdash");
s(w, c, g, "\u2018", "`", !0);
s(w, c, g, "\u2018", "\\textquoteleft");
s(w, c, g, "\u2019", "'", !0);
s(w, c, g, "\u2019", "\\textquoteright");
s(w, c, g, "\u201C", "``", !0);
s(w, c, g, "\u201C", "\\textquotedblleft");
s(w, c, g, "\u201D", "''", !0);
s(w, c, g, "\u201D", "\\textquotedblright");
s(o, c, g, "\xB0", "\\degree", !0);
s(w, c, g, "\xB0", "\\degree");
s(w, c, g, "\xB0", "\\textdegree", !0);
s(o, c, g, "\xA3", "\\pounds");
s(o, c, g, "\xA3", "\\mathsterling", !0);
s(w, c, g, "\xA3", "\\pounds");
s(w, c, g, "\xA3", "\\textsterling", !0);
s(o, d, g, "\u2720", "\\maltese");
s(w, d, g, "\u2720", "\\maltese");
var zr = '0123456789/@."';
for (var bt = 0; bt < zr.length; bt++) {
  var Dr = zr.charAt(bt);
  s(o, c, g, Dr, Dr);
}
var Rr = '0123456789!@*()-=+";:?/.,';
for (var yt = 0; yt < Rr.length; yt++) {
  var Fr = Rr.charAt(yt);
  s(w, c, g, Fr, Fr);
}
var Y0 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (var xt = 0; xt < Y0.length; xt++) {
  var q0 = Y0.charAt(xt);
  s(o, c, F, q0, q0), s(w, c, g, q0, q0);
}
s(o, d, g, "C", "\u2102");
s(w, d, g, "C", "\u2102");
s(o, d, g, "H", "\u210D");
s(w, d, g, "H", "\u210D");
s(o, d, g, "N", "\u2115");
s(w, d, g, "N", "\u2115");
s(o, d, g, "P", "\u2119");
s(w, d, g, "P", "\u2119");
s(o, d, g, "Q", "\u211A");
s(w, d, g, "Q", "\u211A");
s(o, d, g, "R", "\u211D");
s(w, d, g, "R", "\u211D");
s(o, d, g, "Z", "\u2124");
s(w, d, g, "Z", "\u2124");
s(o, c, F, "h", "\u210E");
s(w, c, F, "h", "\u210E");
var I = "";
for (var he = 0; he < Y0.length; he++) {
  var Q = Y0.charAt(he);
  I = String.fromCharCode(55349, 56320 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56372 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56424 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56580 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56684 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56736 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56788 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56840 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56944 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), he < 26 && (I = String.fromCharCode(55349, 56632 + he), s(o, c, F, Q, I), s(w, c, g, Q, I), I = String.fromCharCode(55349, 56476 + he), s(o, c, F, Q, I), s(w, c, g, Q, I));
}
I = "\u{1D55C}";
s(o, c, F, "k", I);
s(w, c, g, "k", I);
for (var e0 = 0; e0 < 10; e0++) {
  var We = e0.toString();
  I = String.fromCharCode(55349, 57294 + e0), s(o, c, F, We, I), s(w, c, g, We, I), I = String.fromCharCode(55349, 57314 + e0), s(o, c, F, We, I), s(w, c, g, We, I), I = String.fromCharCode(55349, 57324 + e0), s(o, c, F, We, I), s(w, c, g, We, I), I = String.fromCharCode(55349, 57334 + e0), s(o, c, F, We, I), s(w, c, g, We, I);
}
var Lt = "\xD0\xDE\xFE";
for (var wt = 0; wt < Lt.length; wt++) {
  var O0 = Lt.charAt(wt);
  s(o, c, F, O0, O0), s(w, c, g, O0, O0);
}
var L0 = [
  ["mathbf", "textbf", "Main-Bold"],
  // A-Z bold upright
  ["mathbf", "textbf", "Main-Bold"],
  // a-z bold upright
  ["mathnormal", "textit", "Math-Italic"],
  // A-Z italic
  ["mathnormal", "textit", "Math-Italic"],
  // a-z italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // A-Z bold italic
  ["boldsymbol", "boldsymbol", "Main-BoldItalic"],
  // a-z bold italic
  // Map fancy A-Z letters to script, not calligraphic.
  // This aligns with unicode-math and math fonts (except Cambria Math).
  ["mathscr", "textscr", "Script-Regular"],
  // A-Z script
  ["", "", ""],
  // a-z script.  No font
  ["", "", ""],
  // A-Z bold script. No font
  ["", "", ""],
  // a-z bold script. No font
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // A-Z Fraktur
  ["mathfrak", "textfrak", "Fraktur-Regular"],
  // a-z Fraktur
  ["mathbb", "textbb", "AMS-Regular"],
  // A-Z double-struck
  ["mathbb", "textbb", "AMS-Regular"],
  // k double-struck
  // Note that we are using a bold font, but font metrics for regular Fraktur.
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // A-Z bold Fraktur
  ["mathboldfrak", "textboldfrak", "Fraktur-Regular"],
  // a-z bold Fraktur
  ["mathsf", "textsf", "SansSerif-Regular"],
  // A-Z sans-serif
  ["mathsf", "textsf", "SansSerif-Regular"],
  // a-z sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // A-Z bold sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // a-z bold sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // A-Z italic sans-serif
  ["mathitsf", "textitsf", "SansSerif-Italic"],
  // a-z italic sans-serif
  ["", "", ""],
  // A-Z bold italic sans. No font
  ["", "", ""],
  // a-z bold italic sans. No font
  ["mathtt", "texttt", "Typewriter-Regular"],
  // A-Z monospace
  ["mathtt", "texttt", "Typewriter-Regular"]
  // a-z monospace
], Ir = [
  ["mathbf", "textbf", "Main-Bold"],
  // 0-9 bold
  ["", "", ""],
  // 0-9 double-struck. No KaTeX font.
  ["mathsf", "textsf", "SansSerif-Regular"],
  // 0-9 sans-serif
  ["mathboldsf", "textboldsf", "SansSerif-Bold"],
  // 0-9 bold sans-serif
  ["mathtt", "texttt", "Typewriter-Regular"]
  // 0-9 monospace
], mi = function(e, t) {
  var a = e.charCodeAt(0), n = e.charCodeAt(1), i = (a - 55296) * 1024 + (n - 56320) + 65536, l = t === "math" ? 0 : 1;
  if (119808 <= i && i < 120484) {
    var u = Math.floor((i - 119808) / 26);
    return [L0[u][2], L0[u][l]];
  } else if (120782 <= i && i <= 120831) {
    var h = Math.floor((i - 120782) / 10);
    return [Ir[h][2], Ir[h][l]];
  } else {
    if (i === 120485 || i === 120486)
      return [L0[0][2], L0[0][l]];
    if (120486 < i && i < 120782)
      return ["", ""];
    throw new k("Unsupported character: " + e);
  }
}, tt = function(e, t, a) {
  return K[a][e] && K[a][e].replace && (e = K[a][e].replace), {
    value: e,
    metrics: Qt(e, t, a)
  };
}, me = function(e, t, a, n, i) {
  var l = tt(e, t, a), u = l.metrics;
  e = l.value;
  var h;
  if (u) {
    var f = u.italic;
    (a === "text" || n && n.font === "mathit") && (f = 0), h = new Me(e, u.height, u.depth, f, u.skew, u.width, i);
  } else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + a + "'")), h = new Me(e, 0, 0, 0, 0, 0, i);
  if (n) {
    h.maxFontSize = n.sizeMultiplier, n.style.isTight() && h.classes.push("mtight");
    var v = n.getColor();
    v && (h.style.color = v);
  }
  return h;
}, er = function(e, t, a, n) {
  return n === void 0 && (n = []), a.font === "boldsymbol" && tt(e, "Main-Bold", t).metrics ? me(e, "Main-Bold", t, a, n.concat(["mathbf"])) : e === "\\" || K[t][e].font === "main" ? me(e, "Main-Regular", t, a, n) : me(e, "AMS-Regular", t, a, n.concat(["amsrm"]));
}, di = function(e, t, a, n, i) {
  return i !== "textord" && tt(e, "Math-BoldItalic", t).metrics ? {
    fontName: "Math-BoldItalic",
    fontClass: "boldsymbol"
  } : {
    fontName: "Main-Bold",
    fontClass: "mathbf"
  };
}, rt = function(e, t, a) {
  var n = e.mode, i = e.text, l = ["mord"], u = n === "math" || n === "text" && t.font, h = u ? t.font : t.fontFamily, f = "", v = "";
  if (i.charCodeAt(0) === 55349 && ([f, v] = mi(i, n)), f.length > 0)
    return me(i, f, n, t, l.concat(v));
  if (h) {
    var b, y;
    if (h === "boldsymbol") {
      var x = di(i, n, t, l, a);
      b = x.fontName, y = [x.fontClass];
    } else u ? (b = Pt[h].fontName, y = [h]) : (b = P0(h, t.fontWeight, t.fontShape), y = [h, t.fontWeight, t.fontShape]);
    if (tt(i, b, n).metrics)
      return me(i, b, n, t, l.concat(y));
    if (wa.hasOwnProperty(i) && b.slice(0, 10) === "Typewriter") {
      for (var T = [], C = 0; C < i.length; C++)
        T.push(me(i[C], b, n, t, l.concat(y)));
      return Ge(T);
    }
  }
  if (a === "mathord")
    return me(i, "Math-Italic", n, t, l.concat(["mathnormal"]));
  if (a === "textord") {
    var D = K[n][i] && K[n][i].font;
    if (D === "ams") {
      var R = P0("amsrm", t.fontWeight, t.fontShape);
      return me(i, R, n, t, l.concat("amsrm", t.fontWeight, t.fontShape));
    } else if (D === "main" || !D) {
      var B = P0("textrm", t.fontWeight, t.fontShape);
      return me(i, B, n, t, l.concat(t.fontWeight, t.fontShape));
    } else {
      var q = P0(D, t.fontWeight, t.fontShape);
      return me(i, q, n, t, l.concat(q, t.fontWeight, t.fontShape));
    }
  } else
    throw new Error("unexpected type: " + a + " in makeOrd");
}, pi = (r, e) => {
  if (Ke(r.classes) !== Ke(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize || r.italic !== 0 && r.hasClass("mathnormal"))
    return !1;
  if (r.classes.length === 1) {
    var t = r.classes[0];
    if (t === "mbin" || t === "mord")
      return !1;
  }
  for (var a in r.style)
    if (r.style.hasOwnProperty(a) && r.style[a] !== e.style[a])
      return !1;
  for (var n in e.style)
    if (e.style.hasOwnProperty(n) && r.style[n] !== e.style[n])
      return !1;
  return !0;
}, Sa = (r) => {
  for (var e = 0; e < r.length - 1; e++) {
    var t = r[e], a = r[e + 1];
    t instanceof Me && a instanceof Me && pi(t, a) && (t.text += a.text, t.height = Math.max(t.height, a.height), t.depth = Math.max(t.depth, a.depth), t.italic = a.italic, r.splice(e + 1, 1), e--);
  }
  return r;
}, tr = function(e) {
  for (var t = 0, a = 0, n = 0, i = 0; i < e.children.length; i++) {
    var l = e.children[i];
    l.height > t && (t = l.height), l.depth > a && (a = l.depth), l.maxFontSize > n && (n = l.maxFontSize);
  }
  e.height = t, e.depth = a, e.maxFontSize = n;
}, S = function(e, t, a, n) {
  var i = new Q0(e, t, a, n);
  return tr(i), i;
}, je = (r, e, t, a) => new Q0(r, e, t, a), f0 = function(e, t, a) {
  var n = S([e], [], t);
  return n.height = Math.max(a || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), n.style.borderBottomWidth = M(n.height), n.maxFontSize = 1, n;
}, fi = function(e, t, a, n) {
  var i = new xa(e, t, a, n);
  return tr(i), i;
}, Ge = function(e) {
  var t = new C0(e);
  return tr(t), t;
}, v0 = function(e, t) {
  return e instanceof C0 ? S([], [e], t) : e;
}, vi = function(e) {
  if (e.positionType === "individualShift") {
    for (var t = e.children, a = [t[0]], n = -t[0].shift - t[0].elem.depth, i = n, l = 1; l < t.length; l++) {
      var u = -t[l].shift - i - t[l].elem.depth, h = u - (t[l - 1].elem.height + t[l - 1].elem.depth);
      i = i + u, a.push({
        type: "kern",
        size: h
      }), a.push(t[l]);
    }
    return {
      children: a,
      depth: n
    };
  }
  var f;
  if (e.positionType === "top") {
    for (var v = e.positionData, b = 0; b < e.children.length; b++) {
      var y = e.children[b];
      v -= y.type === "kern" ? y.size : y.elem.height + y.elem.depth;
    }
    f = v;
  } else if (e.positionType === "bottom")
    f = -e.positionData;
  else {
    var x = e.children[0];
    if (x.type !== "elem")
      throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
      f = -x.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
      f = -x.elem.depth;
    else
      throw new Error("Invalid positionType " + e.positionType + ".");
  }
  return {
    children: e.children,
    depth: f
  };
}, U = function(e, t) {
  for (var {
    children: a,
    depth: n
  } = vi(e), i = 0, l = 0; l < a.length; l++) {
    var u = a[l];
    if (u.type === "elem") {
      var h = u.elem;
      i = Math.max(i, h.maxFontSize, h.height);
    }
  }
  i += 2;
  var f = S(["pstrut"], []);
  f.style.height = M(i);
  for (var v = [], b = n, y = n, x = n, T = 0; T < a.length; T++) {
    var C = a[T];
    if (C.type === "kern")
      x += C.size;
    else {
      var D = C.elem, R = C.wrapperClasses || [], B = C.wrapperStyle || {}, q = S(R, [f, D], void 0, B);
      q.style.top = M(-i - x - D.depth), C.marginLeft && (q.style.marginLeft = C.marginLeft), C.marginRight && (q.style.marginRight = C.marginRight), v.push(q), x += D.height + D.depth;
    }
    b = Math.min(b, x), y = Math.max(y, x);
  }
  var V = S(["vlist"], v);
  V.style.height = M(y);
  var L;
  if (b < 0) {
    var $ = S([], []), G = S(["vlist"], [$]);
    G.style.height = M(-b);
    var j = S(["vlist-s"], [new Me("\u200B")]);
    L = [S(["vlist-r"], [V, j]), S(["vlist-r"], [G])];
  } else
    L = [S(["vlist-r"], [V])];
  var X = S(["vlist-t"], L);
  return L.length === 2 && X.classes.push("vlist-t2"), X.height = y, X.depth = -b, X;
}, Aa = (r, e) => {
  var t = S(["mspace"], [], e), a = J(r, e);
  return t.style.marginRight = M(a), t;
}, P0 = function(e, t, a) {
  var n = "";
  switch (e) {
    case "amsrm":
      n = "AMS";
      break;
    case "textrm":
      n = "Main";
      break;
    case "textsf":
      n = "SansSerif";
      break;
    case "texttt":
      n = "Typewriter";
      break;
    default:
      n = e;
  }
  var i;
  return t === "textbf" && a === "textit" ? i = "BoldItalic" : t === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", n + "-" + i;
}, Pt = {
  // styles
  mathbf: {
    variant: "bold",
    fontName: "Main-Bold"
  },
  mathrm: {
    variant: "normal",
    fontName: "Main-Regular"
  },
  textit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathit: {
    variant: "italic",
    fontName: "Main-Italic"
  },
  mathnormal: {
    variant: "italic",
    fontName: "Math-Italic"
  },
  mathsfit: {
    variant: "sans-serif-italic",
    fontName: "SansSerif-Italic"
  },
  // "boldsymbol" is missing because they require the use of multiple fonts:
  // Math-BoldItalic and Main-Bold.  This is handled by a special case in
  // makeOrd which ends up calling boldsymbol.
  // families
  mathbb: {
    variant: "double-struck",
    fontName: "AMS-Regular"
  },
  mathcal: {
    variant: "script",
    fontName: "Caligraphic-Regular"
  },
  mathfrak: {
    variant: "fraktur",
    fontName: "Fraktur-Regular"
  },
  mathscr: {
    variant: "script",
    fontName: "Script-Regular"
  },
  mathsf: {
    variant: "sans-serif",
    fontName: "SansSerif-Regular"
  },
  mathtt: {
    variant: "monospace",
    fontName: "Typewriter-Regular"
  }
}, ka = {
  //   path, width, height
  vec: ["vec", 0.471, 0.714],
  // values from the font glyph
  oiintSize1: ["oiintSize1", 0.957, 0.499],
  // oval to overlay the integrand
  oiintSize2: ["oiintSize2", 1.472, 0.659],
  oiiintSize1: ["oiiintSize1", 1.304, 0.499],
  oiiintSize2: ["oiiintSize2", 1.98, 0.659]
}, Ta = function(e, t) {
  var [a, n, i] = ka[e], l = new r0(a), u = new _e([l], {
    width: M(n),
    height: M(i),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + M(n),
    viewBox: "0 0 " + 1e3 * n + " " + 1e3 * i,
    preserveAspectRatio: "xMinYMin"
  }), h = je(["overlay"], [u], t);
  return h.height = i, h.style.height = M(i), h.style.width = M(n), h;
}, Z = {
  number: 3,
  unit: "mu"
}, t0 = {
  number: 4,
  unit: "mu"
}, Ne = {
  number: 5,
  unit: "mu"
}, gi = {
  mord: {
    mop: Z,
    mbin: t0,
    mrel: Ne,
    minner: Z
  },
  mop: {
    mord: Z,
    mop: Z,
    mrel: Ne,
    minner: Z
  },
  mbin: {
    mord: t0,
    mop: t0,
    mopen: t0,
    minner: t0
  },
  mrel: {
    mord: Ne,
    mop: Ne,
    mopen: Ne,
    minner: Ne
  },
  mopen: {},
  mclose: {
    mop: Z,
    mbin: t0,
    mrel: Ne,
    minner: Z
  },
  mpunct: {
    mord: Z,
    mop: Z,
    mrel: Ne,
    mopen: Z,
    mclose: Z,
    mpunct: Z,
    minner: Z
  },
  minner: {
    mord: Z,
    mop: Z,
    mbin: t0,
    mrel: Ne,
    mopen: Z,
    mpunct: Z,
    minner: Z
  }
}, bi = {
  mord: {
    mop: Z
  },
  mop: {
    mord: Z,
    mop: Z
  },
  mbin: {},
  mrel: {},
  mopen: {},
  mclose: {
    mop: Z
  },
  mpunct: {},
  minner: {
    mop: Z
  }
}, Ma = {}, K0 = {}, _0 = {};
function E(r) {
  for (var {
    type: e,
    names: t,
    props: a,
    handler: n,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, u = {
    type: e,
    numArgs: a.numArgs,
    argTypes: a.argTypes,
    allowedInArgument: !!a.allowedInArgument,
    allowedInText: !!a.allowedInText,
    allowedInMath: a.allowedInMath === void 0 ? !0 : a.allowedInMath,
    numOptionalArgs: a.numOptionalArgs || 0,
    infix: !!a.infix,
    primitive: !!a.primitive,
    handler: n
  }, h = 0; h < t.length; ++h)
    Ma[t[h]] = u;
  e && (i && (K0[e] = i), l && (_0[e] = l));
}
function a0(r) {
  var {
    type: e,
    htmlBuilder: t,
    mathmlBuilder: a
  } = r;
  E({
    type: e,
    names: [],
    props: {
      numArgs: 0
    },
    handler() {
      throw new Error("Should never be called.");
    },
    htmlBuilder: t,
    mathmlBuilder: a
  });
}
var j0 = function(e) {
  return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, ee = function(e) {
  return e.type === "ordgroup" ? e.body : [e];
}, yi = /* @__PURE__ */ new Set(["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"]), xi = /* @__PURE__ */ new Set(["rightmost", "mrel", "mclose", "mpunct"]), wi = {
  display: N.DISPLAY,
  text: N.TEXT,
  script: N.SCRIPT,
  scriptscript: N.SCRIPTSCRIPT
}, Si = {
  mord: "mord",
  mop: "mop",
  mbin: "mbin",
  mrel: "mrel",
  mopen: "mopen",
  mclose: "mclose",
  mpunct: "mpunct",
  minner: "minner"
}, se = function(e, t, a, n) {
  n === void 0 && (n = [null, null]);
  for (var i = [], l = 0; l < e.length; l++) {
    var u = H(e[l], t);
    if (u instanceof C0) {
      var h = u.children;
      i.push(...h);
    } else
      i.push(u);
  }
  if (Sa(i), !a)
    return i;
  var f = t;
  if (e.length === 1) {
    var v = e[0];
    v.type === "sizing" ? f = t.havingSize(v.size) : v.type === "styling" && (f = t.havingStyle(wi[v.style]));
  }
  var b = S([n[0] || "leftmost"], [], t), y = S([n[1] || "rightmost"], [], t), x = a === "root";
  return Br(i, (T, C) => {
    var D = C.classes[0], R = T.classes[0];
    D === "mbin" && xi.has(R) ? C.classes[0] = "mord" : R === "mbin" && yi.has(D) && (T.classes[0] = "mord");
  }, {
    node: b
  }, y, x), Br(i, (T, C) => {
    var D = Ht(C), R = Ht(T), B = D && R ? T.hasClass("mtight") ? bi[D][R] : gi[D][R] : null;
    if (B)
      return Aa(B, f);
  }, {
    node: b
  }, y, x), i;
}, Br = function r(e, t, a, n, i) {
  n && e.push(n);
  for (var l = 0; l < e.length; l++) {
    var u = e[l], h = Ca(u);
    if (h) {
      r(h.children, t, a, null, i);
      continue;
    }
    var f = !u.hasClass("mspace");
    if (f) {
      var v = t(u, a.node);
      v && (a.insertAfter ? a.insertAfter(v) : (e.unshift(v), l++));
    }
    f ? a.node = u : i && u.hasClass("newline") && (a.node = S(["leftmost"])), a.insertAfter = /* @__PURE__ */ ((b) => (y) => {
      e.splice(b + 1, 0, y), l++;
    })(l);
  }
  n && e.pop();
}, Ca = function(e) {
  return e instanceof C0 || e instanceof xa || e instanceof Q0 && e.hasClass("enclosing") ? e : null;
}, Ai = function r(e, t) {
  var a = Ca(e);
  if (a) {
    var n = a.children;
    if (n.length) {
      if (t === "right")
        return r(n[n.length - 1], "right");
      if (t === "left")
        return r(n[0], "left");
    }
  }
  return e;
}, Ht = function(e, t) {
  return e ? (t && (e = Ai(e, t)), Si[e.classes[0]] || null) : null;
}, M0 = function(e, t) {
  var a = ["nulldelimiter"].concat(e.baseSizingClasses());
  return S(t.concat(a));
}, H = function(e, t, a) {
  if (!e)
    return S();
  if (K0[e.type]) {
    var n = K0[e.type](e, t);
    if (a && t.size !== a.size) {
      n = S(t.sizingClasses(a), [n], t);
      var i = t.sizeMultiplier / a.sizeMultiplier;
      n.height *= i, n.depth *= i;
    }
    return n;
  } else
    throw new k("Got group of unknown type: '" + e.type + "'");
};
function H0(r, e) {
  var t = S(["base"], r, e), a = S(["strut"]);
  return a.style.height = M(t.height + t.depth), t.depth && (a.style.verticalAlign = M(-t.depth)), t.children.unshift(a), t;
}
function Nr(r, e) {
  var t = null;
  r.length === 1 && r[0].type === "tag" && (t = r[0].tag, r = r[0].body);
  var a = se(r, e, "root"), n;
  a.length === 2 && a[1].hasClass("tag") && (n = a.pop());
  for (var i = [], l = [], u = 0; u < a.length; u++)
    if (l.push(a[u]), a[u].hasClass("mbin") || a[u].hasClass("mrel") || a[u].hasClass("allowbreak")) {
      for (var h = !1; u < a.length - 1 && a[u + 1].hasClass("mspace") && !a[u + 1].hasClass("newline"); )
        u++, l.push(a[u]), a[u].hasClass("nobreak") && (h = !0);
      h || (i.push(H0(l, e)), l = []);
    } else a[u].hasClass("newline") && (l.pop(), l.length > 0 && (i.push(H0(l, e)), l = []), i.push(a[u]));
  l.length > 0 && i.push(H0(l, e));
  var f;
  t ? (f = H0(se(t, e, !0)), f.classes = ["tag"], i.push(f)) : n && i.push(n);
  var v = S(["katex-html"], i);
  if (v.setAttribute("aria-hidden", "true"), f) {
    var b = f.children[0];
    b.style.height = M(v.height + v.depth), v.depth && (b.style.verticalAlign = M(-v.depth));
  }
  return v;
}
function Ea(r) {
  return new C0(r);
}
class A {
  constructor(e, t, a) {
    this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = a || [];
  }
  /**
   * Sets an attribute on a MathML node. MathML depends on attributes to convey a
   * semantic content, so this is used heavily.
   */
  setAttribute(e, t) {
    this.attributes[e] = t;
  }
  /**
   * Gets an attribute on a MathML node.
   */
  getAttribute(e) {
    return this.attributes[e];
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]);
    this.classes.length > 0 && (e.className = Ke(this.classes));
    for (var a = 0; a < this.children.length; a++)
      if (this.children[a] instanceof ae && this.children[a + 1] instanceof ae) {
        for (var n = this.children[a].toText() + this.children[++a].toText(); this.children[a + 1] instanceof ae; )
          n += this.children[++a].toText();
        e.appendChild(new ae(n).toNode());
      } else
        e.appendChild(this.children[a].toNode());
    return e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    var e = "<" + this.type;
    for (var t in this.attributes)
      Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += ue(this.attributes[t]), e += '"');
    this.classes.length > 0 && (e += ' class ="' + ue(Ke(this.classes)) + '"'), e += ">";
    for (var a = 0; a < this.children.length; a++)
      e += this.children[a].toMarkup();
    return e += "</" + this.type + ">", e;
  }
  /**
   * Converts the math node into a string, similar to innerText, but escaped.
   */
  toText() {
    return this.children.map((e) => e.toText()).join("");
  }
}
class ae {
  constructor(e) {
    this.text = void 0, this.text = e;
  }
  /**
   * Converts the text node into a DOM text node.
   */
  toNode() {
    return document.createTextNode(this.text);
  }
  /**
   * Converts the text node into escaped HTML markup
   * (representing the text itself).
   */
  toMarkup() {
    return ue(this.toText());
  }
  /**
   * Converts the text node into a string
   * (representing the text itself).
   */
  toText() {
    return this.text;
  }
}
class za {
  /**
   * Create a Space node with width given in CSS ems.
   */
  constructor(e) {
    this.width = void 0, this.character = void 0, this.width = e, e >= 0.05555 && e <= 0.05556 ? this.character = "\u200A" : e >= 0.1666 && e <= 0.1667 ? this.character = "\u2009" : e >= 0.2222 && e <= 0.2223 ? this.character = "\u2005" : e >= 0.2777 && e <= 0.2778 ? this.character = "\u2005\u200A" : e >= -0.05556 && e <= -0.05555 ? this.character = "\u200A\u2063" : e >= -0.1667 && e <= -0.1666 ? this.character = "\u2009\u2063" : e >= -0.2223 && e <= -0.2222 ? this.character = "\u205F\u2063" : e >= -0.2778 && e <= -0.2777 ? this.character = "\u2005\u2063" : this.character = null;
  }
  /**
   * Converts the math node into a MathML-namespaced DOM element.
   */
  toNode() {
    if (this.character)
      return document.createTextNode(this.character);
    var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
    return e.setAttribute("width", M(this.width)), e;
  }
  /**
   * Converts the math node into an HTML markup string.
   */
  toMarkup() {
    return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + M(this.width) + '"/>';
  }
  /**
   * Converts the math node into a string, similar to innerText.
   */
  toText() {
    return this.character ? this.character : " ";
  }
}
var ki = /* @__PURE__ */ new Set(["\\imath", "\\jmath"]), Ti = /* @__PURE__ */ new Set(["mrow", "mtable"]), ke = function(e, t, a) {
  return K[t][e] && K[t][e].replace && e.charCodeAt(0) !== 55349 && !(wa.hasOwnProperty(e) && a && (a.fontFamily && a.fontFamily.slice(4, 6) === "tt" || a.font && a.font.slice(4, 6) === "tt")) && (e = K[t][e].replace), new ae(e);
}, rr = function(e) {
  return e.length === 1 ? e[0] : new A("mrow", e);
}, ar = function(e, t) {
  if (t.fontFamily === "texttt")
    return "monospace";
  if (t.fontFamily === "textsf")
    return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
  if (t.fontShape === "textit" && t.fontWeight === "textbf")
    return "bold-italic";
  if (t.fontShape === "textit")
    return "italic";
  if (t.fontWeight === "textbf")
    return "bold";
  var a = t.font;
  if (!a || a === "mathnormal")
    return null;
  var n = e.mode;
  if (a === "mathit")
    return "italic";
  if (a === "boldsymbol")
    return e.type === "textord" ? "bold" : "bold-italic";
  if (a === "mathbf")
    return "bold";
  if (a === "mathbb")
    return "double-struck";
  if (a === "mathsfit")
    return "sans-serif-italic";
  if (a === "mathfrak")
    return "fraktur";
  if (a === "mathscr" || a === "mathcal")
    return "script";
  if (a === "mathsf")
    return "sans-serif";
  if (a === "mathtt")
    return "monospace";
  var i = e.text;
  if (ki.has(i))
    return null;
  K[n][i] && K[n][i].replace && (i = K[n][i].replace);
  var l = Pt[a].fontName;
  return Qt(i, l, n) ? Pt[a].variant : null;
};
function St(r) {
  if (!r)
    return !1;
  if (r.type === "mi" && r.children.length === 1) {
    var e = r.children[0];
    return e instanceof ae && e.text === ".";
  } else if (r.type === "mo" && r.children.length === 1 && r.getAttribute("separator") === "true" && r.getAttribute("lspace") === "0em" && r.getAttribute("rspace") === "0em") {
    var t = r.children[0];
    return t instanceof ae && t.text === ",";
  } else
    return !1;
}
var ge = function(e, t, a) {
  if (e.length === 1) {
    var n = Y(e[0], t);
    return a && n instanceof A && n.type === "mo" && (n.setAttribute("lspace", "0em"), n.setAttribute("rspace", "0em")), [n];
  }
  for (var i = [], l, u = 0; u < e.length; u++) {
    var h = Y(e[u], t);
    if (h instanceof A && l instanceof A) {
      if (h.type === "mtext" && l.type === "mtext" && h.getAttribute("mathvariant") === l.getAttribute("mathvariant")) {
        l.children.push(...h.children);
        continue;
      } else if (h.type === "mn" && l.type === "mn") {
        l.children.push(...h.children);
        continue;
      } else if (St(h) && l.type === "mn") {
        l.children.push(...h.children);
        continue;
      } else if (h.type === "mn" && St(l))
        h.children = [...l.children, ...h.children], i.pop();
      else if ((h.type === "msup" || h.type === "msub") && h.children.length >= 1 && (l.type === "mn" || St(l))) {
        var f = h.children[0];
        f instanceof A && f.type === "mn" && (f.children = [...l.children, ...f.children], i.pop());
      } else if (l.type === "mi" && l.children.length === 1) {
        var v = l.children[0];
        if (v instanceof ae && v.text === "\u0338" && (h.type === "mo" || h.type === "mi" || h.type === "mn")) {
          var b = h.children[0];
          b instanceof ae && b.text.length > 0 && (b.text = b.text.slice(0, 1) + "\u0338" + b.text.slice(1), i.pop());
        }
      }
    }
    i.push(h), l = h;
  }
  return i;
}, Ze = function(e, t, a) {
  return rr(ge(e, t, a));
}, Y = function(e, t) {
  if (!e)
    return new A("mrow");
  if (_0[e.type]) {
    var a = _0[e.type](e, t);
    return a;
  } else
    throw new k("Got group of unknown type: '" + e.type + "'");
};
function qr(r, e, t, a, n) {
  var i = ge(r, t), l;
  i.length === 1 && i[0] instanceof A && Ti.has(i[0].type) ? l = i[0] : l = new A("mrow", i);
  var u = new A("annotation", [new ae(e)]);
  u.setAttribute("encoding", "application/x-tex");
  var h = new A("semantics", [l, u]), f = new A("math", [h]);
  f.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), a && f.setAttribute("display", "block");
  var v = n ? "katex" : "katex-mathml";
  return S([v], [f]);
}
var Mi = function(e) {
  return new qe({
    style: e.displayMode ? N.DISPLAY : N.TEXT,
    maxSize: e.maxSize,
    minRuleThickness: e.minRuleThickness
  });
}, Ci = function(e, t) {
  if (t.displayMode) {
    var a = ["katex-display"];
    t.leqno && a.push("leqno"), t.fleqn && a.push("fleqn"), e = S(a, [e]);
  }
  return e;
}, Ei = function(e, t, a) {
  var n = Mi(a), i;
  if (a.output === "mathml")
    return qr(e, t, n, a.displayMode, !0);
  if (a.output === "html") {
    var l = Nr(e, n);
    i = S(["katex"], [l]);
  } else {
    var u = qr(e, t, n, a.displayMode, !1), h = Nr(e, n);
    i = S(["katex"], [u, h]);
  }
  return Ci(i, a);
}, zi = {
  widehat: "^",
  widecheck: "\u02C7",
  widetilde: "~",
  utilde: "~",
  overleftarrow: "\u2190",
  underleftarrow: "\u2190",
  xleftarrow: "\u2190",
  overrightarrow: "\u2192",
  underrightarrow: "\u2192",
  xrightarrow: "\u2192",
  underbrace: "\u23DF",
  overbrace: "\u23DE",
  overgroup: "\u23E0",
  undergroup: "\u23E1",
  overleftrightarrow: "\u2194",
  underleftrightarrow: "\u2194",
  xleftrightarrow: "\u2194",
  Overrightarrow: "\u21D2",
  xRightarrow: "\u21D2",
  overleftharpoon: "\u21BC",
  xleftharpoonup: "\u21BC",
  overrightharpoon: "\u21C0",
  xrightharpoonup: "\u21C0",
  xLeftarrow: "\u21D0",
  xLeftrightarrow: "\u21D4",
  xhookleftarrow: "\u21A9",
  xhookrightarrow: "\u21AA",
  xmapsto: "\u21A6",
  xrightharpoondown: "\u21C1",
  xleftharpoondown: "\u21BD",
  xrightleftharpoons: "\u21CC",
  xleftrightharpoons: "\u21CB",
  xtwoheadleftarrow: "\u219E",
  xtwoheadrightarrow: "\u21A0",
  xlongequal: "=",
  xtofrom: "\u21C4",
  xrightleftarrows: "\u21C4",
  xrightequilibrium: "\u21CC",
  // Not a perfect match.
  xleftequilibrium: "\u21CB",
  // None better available.
  "\\cdrightarrow": "\u2192",
  "\\cdleftarrow": "\u2190",
  "\\cdlongequal": "="
}, at = function(e) {
  var t = new A("mo", [new ae(zi[e.replace(/^\\/, "")])]);
  return t.setAttribute("stretchy", "true"), t;
}, Di = {
  //   path(s), minWidth, height, align
  overrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  overleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  underrightarrow: [["rightarrow"], 0.888, 522, "xMaxYMin"],
  underleftarrow: [["leftarrow"], 0.888, 522, "xMinYMin"],
  xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"],
  "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"],
  // CD minwwidth2.5pc
  xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"],
  "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"],
  Overrightarrow: [["doublerightarrow"], 0.888, 560, "xMaxYMin"],
  xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"],
  xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"],
  overleftharpoon: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoonup: [["leftharpoon"], 0.888, 522, "xMinYMin"],
  xleftharpoondown: [["leftharpoondown"], 0.888, 522, "xMinYMin"],
  overrightharpoon: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoonup: [["rightharpoon"], 0.888, 522, "xMaxYMin"],
  xrightharpoondown: [["rightharpoondown"], 0.888, 522, "xMaxYMin"],
  xlongequal: [["longequal"], 0.888, 334, "xMinYMin"],
  "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"],
  xtwoheadleftarrow: [["twoheadleftarrow"], 0.888, 334, "xMinYMin"],
  xtwoheadrightarrow: [["twoheadrightarrow"], 0.888, 334, "xMaxYMin"],
  overleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548],
  underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548],
  underleftrightarrow: [["leftarrow", "rightarrow"], 0.888, 522],
  xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522],
  xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560],
  xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716],
  xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716],
  xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522],
  xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522],
  overlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  underlinesegment: [["leftlinesegment", "rightlinesegment"], 0.888, 522],
  overgroup: [["leftgroup", "rightgroup"], 0.888, 342],
  undergroup: [["leftgroupunder", "rightgroupunder"], 0.888, 342],
  xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522],
  xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528],
  // The next three arrows are from the mhchem package.
  // In mhchem.sty, min-length is 2.0em. But these arrows might appear in the
  // document as \xrightarrow or \xrightleftharpoons. Those have
  // min-length = 1.75em, so we set min-length on these next three to match.
  xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901],
  xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716],
  xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716]
}, Ri = /* @__PURE__ */ new Set(["widehat", "widecheck", "widetilde", "utilde"]), nt = function(e, t) {
  function a() {
    var u = 4e5, h = e.label.slice(1);
    if (Ri.has(h)) {
      var f = e, v = f.base.type === "ordgroup" ? f.base.body.length : 1, b, y, x;
      if (v > 5)
        h === "widehat" || h === "widecheck" ? (b = 420, u = 2364, x = 0.42, y = h + "4") : (b = 312, u = 2340, x = 0.34, y = "tilde4");
      else {
        var T = [1, 1, 2, 2, 3, 3][v];
        h === "widehat" || h === "widecheck" ? (u = [0, 1062, 2364, 2364, 2364][T], b = [0, 239, 300, 360, 420][T], x = [0, 0.24, 0.3, 0.3, 0.36, 0.42][T], y = h + T) : (u = [0, 600, 1033, 2339, 2340][T], b = [0, 260, 286, 306, 312][T], x = [0, 0.26, 0.286, 0.3, 0.306, 0.34][T], y = "tilde" + T);
      }
      var C = new r0(y), D = new _e([C], {
        width: "100%",
        height: M(x),
        viewBox: "0 0 " + u + " " + b,
        preserveAspectRatio: "none"
      });
      return {
        span: je([], [D], t),
        minWidth: 0,
        height: x
      };
    } else {
      var R = [], B = Di[h], [q, V, L] = B, $ = L / 1e3, G = q.length, j, X;
      if (G === 1) {
        var Be = B[3];
        j = ["hide-tail"], X = [Be];
      } else if (G === 2)
        j = ["halfarrow-left", "halfarrow-right"], X = ["xMinYMin", "xMaxYMin"];
      else if (G === 3)
        j = ["brace-left", "brace-center", "brace-right"], X = ["xMinYMin", "xMidYMin", "xMaxYMin"];
      else
        throw new Error(`Correct katexImagesData or update code here to support
                    ` + G + " children.");
      for (var ce = 0; ce < G; ce++) {
        var ie = new r0(q[ce]), Qe = new _e([ie], {
          width: "400em",
          height: M($),
          viewBox: "0 0 " + u + " " + L,
          preserveAspectRatio: X[ce] + " slice"
        }), fe = je([j[ce]], [Qe], t);
        if (G === 1)
          return {
            span: fe,
            minWidth: V,
            height: $
          };
        fe.style.height = M($), R.push(fe);
      }
      return {
        span: S(["stretchy"], R, t),
        minWidth: V,
        height: $
      };
    }
  }
  var {
    span: n,
    minWidth: i,
    height: l
  } = a();
  return n.height = l, n.style.height = M(l), i > 0 && (n.style.minWidth = M(i)), n;
}, Fi = function(e, t, a, n, i) {
  var l, u = e.height + e.depth + a + n;
  if (/fbox|color|angl/.test(t)) {
    if (l = S(["stretchy", t], [], i), t === "fbox") {
      var h = i.color && i.getColor();
      h && (l.style.borderColor = h);
    }
  } else {
    var f = [];
    /^[bx]cancel$/.test(t) && f.push(new Cr({
      x1: "0",
      y1: "0",
      x2: "100%",
      y2: "100%",
      "stroke-width": "0.046em"
    })), /^x?cancel$/.test(t) && f.push(new Cr({
      x1: "0",
      y1: "100%",
      x2: "100%",
      y2: "0",
      "stroke-width": "0.046em"
    }));
    var v = new _e(f, {
      width: "100%",
      height: M(u)
    });
    l = je([], [v], i);
  }
  return l.height = u, l.style.height = M(u), l;
};
function O(r, e) {
  if (!r || r.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r)));
  return r;
}
function nr(r) {
  var e = it(r);
  if (!e)
    throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r)));
  return e;
}
function it(r) {
  return r && (r.type === "atom" || hi.hasOwnProperty(r.type)) ? r : null;
}
var ir = (r, e) => {
  var t, a, n;
  r && r.type === "supsub" ? (a = O(r.base, "accent"), t = a.base, r.base = t, n = ui(H(r, e)), r.base = a) : (a = O(r, "accent"), t = a.base);
  var i = H(t, e.havingCrampedStyle()), l = a.isShifty && Pe(t), u = 0;
  if (l) {
    var h = w0(t), f = H(h, e.havingCrampedStyle());
    u = Er(f).skew;
  }
  var v = a.label === "\\c", b = v ? i.height + i.depth : Math.min(i.height, e.fontMetrics().xHeight), y;
  if (a.isStretchy)
    y = nt(a, e), y = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "elem",
        elem: y,
        wrapperClasses: ["svg-align"],
        wrapperStyle: u > 0 ? {
          width: "calc(100% - " + M(2 * u) + ")",
          marginLeft: M(2 * u)
        } : void 0
      }]
    });
  else {
    var x, T;
    a.label === "\\vec" ? (x = Ta("vec", e), T = ka.vec[1]) : (x = rt({
      mode: a.mode,
      text: a.label
    }, e, "textord"), x = Er(x), x.italic = 0, T = x.width, v && (b += x.depth)), y = S(["accent-body"], [x]);
    var C = a.label === "\\textcircled";
    C && (y.classes.push("accent-full"), b = i.height);
    var D = u;
    C || (D -= T / 2), y.style.left = M(D), a.label === "\\textcircled" && (y.style.top = ".2em"), y = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: i
      }, {
        type: "kern",
        size: -b
      }, {
        type: "elem",
        elem: y
      }]
    });
  }
  var R = S(["mord", "accent"], [y], e);
  return n ? (n.children[0] = R, n.height = Math.max(R.height, n.height), n.classes[0] = "mord", n) : R;
}, Da = (r, e) => {
  var t = r.isStretchy ? at(r.label) : new A("mo", [ke(r.label, r.mode)]), a = new A("mover", [Y(r.base, e), t]);
  return a.setAttribute("accent", "true"), a;
}, Ii = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map((r) => "\\" + r).join("|"));
E({
  type: "accent",
  names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var t = j0(e[0]), a = !Ii.test(r.funcName), n = !a || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck";
    return {
      type: "accent",
      mode: r.parser.mode,
      label: r.funcName,
      isStretchy: a,
      isShifty: n,
      base: t
    };
  },
  htmlBuilder: ir,
  mathmlBuilder: Da
});
E({
  type: "accent",
  names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    // unless in strict mode
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = e[0], a = r.parser.mode;
    return a === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), a = "text"), {
      type: "accent",
      mode: a,
      label: r.funcName,
      isStretchy: !1,
      isShifty: !0,
      base: t
    };
  },
  htmlBuilder: ir,
  mathmlBuilder: Da
});
E({
  type: "accentUnder",
  names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "accentUnder",
      mode: t.mode,
      label: a,
      base: n
    };
  },
  htmlBuilder: (r, e) => {
    var t = H(r.base, e), a = nt(r, e), n = r.label === "\\utilde" ? 0.12 : 0, i = U({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "elem",
        elem: a,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: n
      }, {
        type: "elem",
        elem: t
      }]
    });
    return S(["mord", "accentunder"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = at(r.label), a = new A("munder", [Y(r.base, e), t]);
    return a.setAttribute("accentunder", "true"), a;
  }
});
var G0 = (r) => {
  var e = new A("mpadded", r ? [r] : []);
  return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e;
};
E({
  type: "xArrow",
  names: [
    "\\xleftarrow",
    "\\xrightarrow",
    "\\xLeftarrow",
    "\\xRightarrow",
    "\\xleftrightarrow",
    "\\xLeftrightarrow",
    "\\xhookleftarrow",
    "\\xhookrightarrow",
    "\\xmapsto",
    "\\xrightharpoondown",
    "\\xrightharpoonup",
    "\\xleftharpoondown",
    "\\xleftharpoonup",
    "\\xrightleftharpoons",
    "\\xleftrightharpoons",
    "\\xlongequal",
    "\\xtwoheadrightarrow",
    "\\xtwoheadleftarrow",
    "\\xtofrom",
    // The next 3 functions are here to support the mhchem extension.
    // Direct use of these functions is discouraged and may break someday.
    "\\xrightleftarrows",
    "\\xrightequilibrium",
    "\\xleftequilibrium",
    // The next 3 functions are here only to support the {CD} environment.
    "\\\\cdrightarrow",
    "\\\\cdleftarrow",
    "\\\\cdlongequal"
  ],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: a,
      funcName: n
    } = r;
    return {
      type: "xArrow",
      mode: a.mode,
      label: n,
      body: e[0],
      below: t[0]
    };
  },
  // Flow is unable to correctly infer the type of `group`, even though it's
  // unambiguously determined from the passed-in `type` above.
  htmlBuilder(r, e) {
    var t = e.style, a = e.havingStyle(t.sup()), n = v0(H(r.body, a, e), e), i = r.label.slice(0, 2) === "\\x" ? "x" : "cd";
    n.classes.push(i + "-arrow-pad");
    var l;
    r.below && (a = e.havingStyle(t.sub()), l = v0(H(r.below, a, e), e), l.classes.push(i + "-arrow-pad"));
    var u = nt(r, e), h = -e.fontMetrics().axisHeight + 0.5 * u.height, f = -e.fontMetrics().axisHeight - 0.5 * u.height - 0.111;
    (n.depth > 0.25 || r.label === "\\xleftequilibrium") && (f -= n.depth);
    var v;
    if (l) {
      var b = -e.fontMetrics().axisHeight + l.height + 0.5 * u.height + 0.111;
      v = U({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: n,
          shift: f
        }, {
          type: "elem",
          elem: u,
          shift: h
        }, {
          type: "elem",
          elem: l,
          shift: b
        }]
      });
    } else
      v = U({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: n,
          shift: f
        }, {
          type: "elem",
          elem: u,
          shift: h
        }]
      });
    return v.children[0].children[0].children[1].classes.push("svg-align"), S(["mrel", "x-arrow"], [v], e);
  },
  mathmlBuilder(r, e) {
    var t = at(r.label);
    t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em");
    var a;
    if (r.body) {
      var n = G0(Y(r.body, e));
      if (r.below) {
        var i = G0(Y(r.below, e));
        a = new A("munderover", [t, i, n]);
      } else
        a = new A("mover", [t, n]);
    } else if (r.below) {
      var l = G0(Y(r.below, e));
      a = new A("munder", [t, l]);
    } else
      a = G0(), a = new A("mover", [t, a]);
    return a;
  }
});
function Ra(r, e) {
  var t = se(r.body, e, !0);
  return S([r.mclass], t, e);
}
function Fa(r, e) {
  var t, a = ge(r.body, e);
  return r.mclass === "minner" ? t = new A("mpadded", a) : r.mclass === "mord" ? r.isCharacterBox ? (t = a[0], t.type = "mi") : t = new A("mi", a) : (r.isCharacterBox ? (t = a[0], t.type = "mo") : t = new A("mo", a), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t;
}
E({
  type: "mclass",
  names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: "m" + a.slice(5),
      // TODO(kevinb): don't prefix with 'm'
      body: ee(n),
      isCharacterBox: Pe(n)
    };
  },
  htmlBuilder: Ra,
  mathmlBuilder: Fa
});
var st = (r) => {
  var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r;
  return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord";
};
E({
  type: "mclass",
  names: ["\\@binrel"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "mclass",
      mode: t.mode,
      mclass: st(e[0]),
      body: ee(e[1]),
      isCharacterBox: Pe(e[1])
    };
  }
});
E({
  type: "mclass",
  names: ["\\stackrel", "\\overset", "\\underset"],
  props: {
    numArgs: 2
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[1], i = e[0], l;
    a !== "\\stackrel" ? l = st(n) : l = "mrel";
    var u = {
      type: "op",
      mode: n.mode,
      limits: !0,
      alwaysHandleSupSub: !0,
      parentIsSupSub: !1,
      symbol: !1,
      suppressBaseShift: a !== "\\stackrel",
      body: ee(n)
    }, h = {
      type: "supsub",
      mode: i.mode,
      base: u,
      sup: a === "\\underset" ? null : i,
      sub: a === "\\underset" ? i : null
    };
    return {
      type: "mclass",
      mode: t.mode,
      mclass: l,
      body: [h],
      isCharacterBox: Pe(h)
    };
  },
  htmlBuilder: Ra,
  mathmlBuilder: Fa
});
E({
  type: "pmb",
  names: ["\\pmb"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "pmb",
      mode: t.mode,
      mclass: st(e[0]),
      body: ee(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = se(r.body, e, !0), a = S([r.mclass], t, e);
    return a.style.textShadow = "0.02em 0.01em 0.04px", a;
  },
  mathmlBuilder(r, e) {
    var t = ge(r.body, e), a = new A("mstyle", t);
    return a.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), a;
  }
});
var Bi = {
  ">": "\\\\cdrightarrow",
  "<": "\\\\cdleftarrow",
  "=": "\\\\cdlongequal",
  A: "\\uparrow",
  V: "\\downarrow",
  "|": "\\Vert",
  ".": "no arrow"
}, Or = () => ({
  type: "styling",
  body: [],
  mode: "math",
  style: "display"
}), Lr = (r) => r.type === "textord" && r.text === "@", Ni = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
function qi(r, e, t) {
  var a = Bi[r];
  switch (a) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow":
      return t.callFunction(a, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
      var n = t.callFunction("\\\\cdleft", [e[0]], []), i = {
        type: "atom",
        text: a,
        mode: "math",
        family: "rel"
      }, l = t.callFunction("\\Big", [i], []), u = t.callFunction("\\\\cdright", [e[1]], []), h = {
        type: "ordgroup",
        mode: "math",
        body: [n, l, u]
      };
      return t.callFunction("\\\\cdparent", [h], []);
    }
    case "\\\\cdlongequal":
      return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
      var f = {
        type: "textord",
        text: "\\Vert",
        mode: "math"
      };
      return t.callFunction("\\Big", [f], []);
    }
    default:
      return {
        type: "textord",
        text: " ",
        mode: "math"
      };
  }
}
function Oi(r) {
  var e = [];
  for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup(); ; ) {
    e.push(r.parseExpression(!1, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
    var t = r.fetch().text;
    if (t === "&" || t === "\\\\")
      r.consume();
    else if (t === "\\end") {
      e[e.length - 1].length === 0 && e.pop();
      break;
    } else
      throw new k("Expected \\\\ or \\cr or \\end", r.nextToken);
  }
  for (var a = [], n = [a], i = 0; i < e.length; i++) {
    for (var l = e[i], u = Or(), h = 0; h < l.length; h++)
      if (!Lr(l[h]))
        u.body.push(l[h]);
      else {
        a.push(u), h += 1;
        var f = nr(l[h]).text, v = new Array(2);
        if (v[0] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, v[1] = {
          type: "ordgroup",
          mode: "math",
          body: []
        }, !"=|.".includes(f)) if ("<>AV".includes(f))
          for (var b = 0; b < 2; b++) {
            for (var y = !0, x = h + 1; x < l.length; x++) {
              if (Ni(l[x], f)) {
                y = !1, h = x;
                break;
              }
              if (Lr(l[x]))
                throw new k("Missing a " + f + " character to complete a CD arrow.", l[x]);
              v[b].body.push(l[x]);
            }
            if (y)
              throw new k("Missing a " + f + " character to complete a CD arrow.", l[h]);
          }
        else
          throw new k('Expected one of "<>AV=|." after @', l[h]);
        var T = qi(f, v, r), C = {
          type: "styling",
          body: [T],
          mode: "math",
          style: "display"
          // CD is always displaystyle.
        };
        a.push(C), u = Or();
      }
    i % 2 === 0 ? a.push(u) : a.shift(), a = [], n.push(a);
  }
  r.gullet.endGroup(), r.gullet.endGroup();
  var D = new Array(n[0].length).fill({
    type: "align",
    align: "c",
    pregap: 0.25,
    // CD package sets \enskip between columns.
    postgap: 0.25
    // So pre and post each get half an \enskip, i.e. 0.25em.
  });
  return {
    type: "array",
    mode: "math",
    body: n,
    arraystretch: 1,
    addJot: !0,
    rowGaps: [null],
    cols: D,
    colSeparationType: "CD",
    hLinesBeforeRow: new Array(n.length + 1).fill([])
  };
}
E({
  type: "cdlabel",
  names: ["\\\\cdleft", "\\\\cdright"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r;
    return {
      type: "cdlabel",
      mode: t.mode,
      side: a.slice(4),
      label: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = e.havingStyle(e.style.sup()), a = v0(H(r.label, t, e), e);
    return a.classes.push("cd-label-" + r.side), a.style.bottom = M(0.8 - a.depth), a.height = 0, a.depth = 0, a;
  },
  mathmlBuilder(r, e) {
    var t = new A("mrow", [Y(r.label, e)]);
    return t = new A("mpadded", [t]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new A("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t;
  }
});
E({
  type: "cdlabelparent",
  names: ["\\\\cdparent"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "cdlabelparent",
      mode: t.mode,
      fragment: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = v0(H(r.fragment, e), e);
    return t.classes.push("cd-vert-arrow"), t;
  },
  mathmlBuilder(r, e) {
    return new A("mrow", [Y(r.fragment, e)]);
  }
});
E({
  type: "textord",
  names: ["\\@char"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    for (var {
      parser: t
    } = r, a = O(e[0], "ordgroup"), n = a.body, i = "", l = 0; l < n.length; l++) {
      var u = O(n[l], "textord");
      i += u.text;
    }
    var h = parseInt(i), f;
    if (isNaN(h))
      throw new k("\\@char has non-numeric argument " + i);
    if (h < 0 || h >= 1114111)
      throw new k("\\@char with invalid code point " + i);
    return h <= 65535 ? f = String.fromCharCode(h) : (h -= 65536, f = String.fromCharCode((h >> 10) + 55296, (h & 1023) + 56320)), {
      type: "textord",
      mode: t.mode,
      text: f
    };
  }
});
var Ia = (r, e) => {
  var t = se(r.body, e.withColor(r.color), !1);
  return Ge(t);
}, Ba = (r, e) => {
  var t = ge(r.body, e.withColor(r.color)), a = new A("mstyle", t);
  return a.setAttribute("mathcolor", r.color), a;
};
E({
  type: "color",
  names: ["\\textcolor"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "original"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = O(e[0], "color-token").color, n = e[1];
    return {
      type: "color",
      mode: t.mode,
      color: a,
      body: ee(n)
    };
  },
  htmlBuilder: Ia,
  mathmlBuilder: Ba
});
E({
  type: "color",
  names: ["\\color"],
  props: {
    numArgs: 1,
    allowedInText: !0,
    argTypes: ["color"]
  },
  handler(r, e) {
    var {
      parser: t,
      breakOnTokenText: a
    } = r, n = O(e[0], "color-token").color;
    t.gullet.macros.set("\\current@color", n);
    var i = t.parseExpression(!0, a);
    return {
      type: "color",
      mode: t.mode,
      color: n,
      body: i
    };
  },
  htmlBuilder: Ia,
  mathmlBuilder: Ba
});
E({
  type: "cr",
  names: ["\\\\"],
  props: {
    numArgs: 0,
    numOptionalArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    var {
      parser: a
    } = r, n = a.gullet.future().text === "[" ? a.parseSizeGroup(!0) : null, i = !a.settings.displayMode || !a.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode");
    return {
      type: "cr",
      mode: a.mode,
      newLine: i,
      size: n && O(n, "size").value
    };
  },
  // The following builders are called only at the top level,
  // not within tabular/array environments.
  htmlBuilder(r, e) {
    var t = S(["mspace"], [], e);
    return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = M(J(r.size, e)))), t;
  },
  mathmlBuilder(r, e) {
    var t = new A("mspace");
    return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", M(J(r.size, e)))), t;
  }
});
var Gt = {
  "\\global": "\\global",
  "\\long": "\\\\globallong",
  "\\\\globallong": "\\\\globallong",
  "\\def": "\\gdef",
  "\\gdef": "\\gdef",
  "\\edef": "\\xdef",
  "\\xdef": "\\xdef",
  "\\let": "\\\\globallet",
  "\\futurelet": "\\\\globalfuture"
}, Na = (r) => {
  var e = r.text;
  if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new k("Expected a control sequence", r);
  return e;
}, Li = (r) => {
  var e = r.gullet.popToken();
  return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e;
}, qa = (r, e, t, a) => {
  var n = r.gullet.macros.get(t.text);
  n == null && (t.noexpand = !0, n = {
    tokens: [t],
    numArgs: 0,
    // reproduce the same behavior in expansion
    unexpandable: !r.gullet.isExpandable(t.text)
  }), r.gullet.macros.set(e, n, a);
};
E({
  type: "internal",
  names: [
    "\\global",
    "\\long",
    "\\\\globallong"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    e.consumeSpaces();
    var a = e.fetch();
    if (Gt[a.text])
      return (t === "\\global" || t === "\\\\globallong") && (a.text = Gt[a.text]), O(e.parseFunction(), "internal");
    throw new k("Invalid token after macro prefix", a);
  }
});
E({
  type: "internal",
  names: ["\\def", "\\gdef", "\\edef", "\\xdef"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = e.gullet.popToken(), n = a.text;
    if (/^(?:[\\{}$&#^_]|EOF)$/.test(n))
      throw new k("Expected a control sequence", a);
    for (var i = 0, l, u = [[]]; e.gullet.future().text !== "{"; )
      if (a = e.gullet.popToken(), a.text === "#") {
        if (e.gullet.future().text === "{") {
          l = e.gullet.future(), u[i].push("{");
          break;
        }
        if (a = e.gullet.popToken(), !/^[1-9]$/.test(a.text))
          throw new k('Invalid argument number "' + a.text + '"');
        if (parseInt(a.text) !== i + 1)
          throw new k('Argument number "' + a.text + '" out of order');
        i++, u.push([]);
      } else {
        if (a.text === "EOF")
          throw new k("Expected a macro definition");
        u[i].push(a.text);
      }
    var {
      tokens: h
    } = e.gullet.consumeArg();
    return l && h.unshift(l), (t === "\\edef" || t === "\\xdef") && (h = e.gullet.expandTokens(h), h.reverse()), e.gullet.macros.set(n, {
      tokens: h,
      numArgs: i,
      delimiters: u
    }, t === Gt[t]), {
      type: "internal",
      mode: e.mode
    };
  }
});
E({
  type: "internal",
  names: [
    "\\let",
    "\\\\globallet"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = Na(e.gullet.popToken());
    e.gullet.consumeSpaces();
    var n = Li(e);
    return qa(e, a, n, t === "\\\\globallet"), {
      type: "internal",
      mode: e.mode
    };
  }
});
E({
  type: "internal",
  names: [
    "\\futurelet",
    "\\\\globalfuture"
    // can’t be entered directly
  ],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = Na(e.gullet.popToken()), n = e.gullet.popToken(), i = e.gullet.popToken();
    return qa(e, a, i, t === "\\\\globalfuture"), e.gullet.pushToken(i), e.gullet.pushToken(n), {
      type: "internal",
      mode: e.mode
    };
  }
});
var y0 = function(e, t, a) {
  var n = K.math[e] && K.math[e].replace, i = Qt(n || e, t, a);
  if (!i)
    throw new Error("Unsupported symbol " + e + " and font size " + t + ".");
  return i;
}, sr = function(e, t, a, n) {
  var i = a.havingBaseStyle(t), l = S(n.concat(i.sizingClasses(a)), [e], a), u = i.sizeMultiplier / a.sizeMultiplier;
  return l.height *= u, l.depth *= u, l.maxFontSize = i.sizeMultiplier, l;
}, Oa = function(e, t, a) {
  var n = t.havingBaseStyle(a), i = (1 - t.sizeMultiplier / n.sizeMultiplier) * t.fontMetrics().axisHeight;
  e.classes.push("delimcenter"), e.style.top = M(i), e.height -= i, e.depth += i;
}, Pi = function(e, t, a, n, i, l) {
  var u = me(e, "Main-Regular", i, n), h = sr(u, t, n, l);
  return Oa(h, n, t), h;
}, Hi = function(e, t, a, n) {
  return me(e, "Size" + t + "-Regular", a, n);
}, La = function(e, t, a, n, i, l) {
  var u = Hi(e, t, i, n), h = sr(S(["delimsizing", "size" + t], [u], n), N.TEXT, n, l);
  return a && Oa(h, n, N.TEXT), h;
}, At = function(e, t, a) {
  var n;
  t === "Size1-Regular" ? n = "delim-size1" : n = "delim-size4";
  var i = S(["delimsizinginner", n], [S([], [me(e, t, a)])]);
  return {
    type: "elem",
    elem: i
  };
}, kt = function(e, t, a) {
  var n = Oe["Size4-Regular"][e.charCodeAt(0)] ? Oe["Size4-Regular"][e.charCodeAt(0)][4] : Oe["Size1-Regular"][e.charCodeAt(0)][4], i = new r0("inner", ti(e, Math.round(1e3 * t))), l = new _e([i], {
    width: M(n),
    height: M(t),
    // Override CSS rule `.katex svg { width: 100% }`
    style: "width:" + M(n),
    viewBox: "0 0 " + 1e3 * n + " " + Math.round(1e3 * t),
    preserveAspectRatio: "xMinYMin"
  }), u = je([], [l], a);
  return u.height = t, u.style.height = M(t), u.style.width = M(n), {
    type: "elem",
    elem: u
  };
}, Ut = 8e-3, U0 = {
  type: "kern",
  size: -1 * Ut
}, Gi = /* @__PURE__ */ new Set(["|", "\\lvert", "\\rvert", "\\vert"]), Ui = /* @__PURE__ */ new Set(["\\|", "\\lVert", "\\rVert", "\\Vert"]), Pa = function(e, t, a, n, i, l) {
  var u, h, f, v, b = "", y = 0;
  u = f = v = e, h = null;
  var x = "Size1-Regular";
  e === "\\uparrow" ? f = v = "\u23D0" : e === "\\Uparrow" ? f = v = "\u2016" : e === "\\downarrow" ? u = f = "\u23D0" : e === "\\Downarrow" ? u = f = "\u2016" : e === "\\updownarrow" ? (u = "\\uparrow", f = "\u23D0", v = "\\downarrow") : e === "\\Updownarrow" ? (u = "\\Uparrow", f = "\u2016", v = "\\Downarrow") : Gi.has(e) ? (f = "\u2223", b = "vert", y = 333) : Ui.has(e) ? (f = "\u2225", b = "doublevert", y = 556) : e === "[" || e === "\\lbrack" ? (u = "\u23A1", f = "\u23A2", v = "\u23A3", x = "Size4-Regular", b = "lbrack", y = 667) : e === "]" || e === "\\rbrack" ? (u = "\u23A4", f = "\u23A5", v = "\u23A6", x = "Size4-Regular", b = "rbrack", y = 667) : e === "\\lfloor" || e === "\u230A" ? (f = u = "\u23A2", v = "\u23A3", x = "Size4-Regular", b = "lfloor", y = 667) : e === "\\lceil" || e === "\u2308" ? (u = "\u23A1", f = v = "\u23A2", x = "Size4-Regular", b = "lceil", y = 667) : e === "\\rfloor" || e === "\u230B" ? (f = u = "\u23A5", v = "\u23A6", x = "Size4-Regular", b = "rfloor", y = 667) : e === "\\rceil" || e === "\u2309" ? (u = "\u23A4", f = v = "\u23A5", x = "Size4-Regular", b = "rceil", y = 667) : e === "(" || e === "\\lparen" ? (u = "\u239B", f = "\u239C", v = "\u239D", x = "Size4-Regular", b = "lparen", y = 875) : e === ")" || e === "\\rparen" ? (u = "\u239E", f = "\u239F", v = "\u23A0", x = "Size4-Regular", b = "rparen", y = 875) : e === "\\{" || e === "\\lbrace" ? (u = "\u23A7", h = "\u23A8", v = "\u23A9", f = "\u23AA", x = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (u = "\u23AB", h = "\u23AC", v = "\u23AD", f = "\u23AA", x = "Size4-Regular") : e === "\\lgroup" || e === "\u27EE" ? (u = "\u23A7", v = "\u23A9", f = "\u23AA", x = "Size4-Regular") : e === "\\rgroup" || e === "\u27EF" ? (u = "\u23AB", v = "\u23AD", f = "\u23AA", x = "Size4-Regular") : e === "\\lmoustache" || e === "\u23B0" ? (u = "\u23A7", v = "\u23AD", f = "\u23AA", x = "Size4-Regular") : (e === "\\rmoustache" || e === "\u23B1") && (u = "\u23AB", v = "\u23A9", f = "\u23AA", x = "Size4-Regular");
  var T = y0(u, x, i), C = T.height + T.depth, D = y0(f, x, i), R = D.height + D.depth, B = y0(v, x, i), q = B.height + B.depth, V = 0, L = 1;
  if (h !== null) {
    var $ = y0(h, x, i);
    V = $.height + $.depth, L = 2;
  }
  var G = C + q + V, j = Math.max(0, Math.ceil((t - G) / (L * R))), X = G + j * L * R, Be = n.fontMetrics().axisHeight;
  a && (Be *= n.sizeMultiplier);
  var ce = X / 2 - Be, ie = [];
  if (b.length > 0) {
    var Qe = X - C - q, fe = Math.round(X * 1e3), Te = ri(b, Math.round(Qe * 1e3)), Ue = new r0(b, Te), n0 = (y / 1e3).toFixed(3) + "em", i0 = (fe / 1e3).toFixed(3) + "em", ct = new _e([Ue], {
      width: n0,
      height: i0,
      viewBox: "0 0 " + y + " " + fe
    }), Ve = je([], [ct], n);
    Ve.height = fe / 1e3, Ve.style.width = n0, Ve.style.height = i0, ie.push({
      type: "elem",
      elem: Ve
    });
  } else {
    if (ie.push(At(v, x, i)), ie.push(U0), h === null) {
      var $e = X - C - q + 2 * Ut;
      ie.push(kt(f, $e, n));
    } else {
      var xe = (X - C - q - V) / 2 + 2 * Ut;
      ie.push(kt(f, xe, n)), ie.push(U0), ie.push(At(h, x, i)), ie.push(U0), ie.push(kt(f, xe, n));
    }
    ie.push(U0), ie.push(At(u, x, i));
  }
  var z0 = n.havingBaseStyle(N.TEXT), ht = U({
    positionType: "bottom",
    positionData: ce,
    children: ie
  });
  return sr(S(["delimsizing", "mult"], [ht], z0), N.TEXT, n, l);
}, Tt = 80, Mt = 0.08, Ct = function(e, t, a, n, i) {
  var l = ei(e, n, a), u = new r0(e, l), h = new _e([u], {
    // Note: 1000:1 ratio of viewBox to document em width.
    width: "400em",
    height: M(t),
    viewBox: "0 0 400000 " + a,
    preserveAspectRatio: "xMinYMin slice"
  });
  return je(["hide-tail"], [h], i);
}, Vi = function(e, t) {
  var a = t.havingBaseSizing(), n = $a("\\surd", e * a.sizeMultiplier, Va, a), i = a.sizeMultiplier, l = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), u, h = 0, f = 0, v = 0, b;
  return n.type === "small" ? (v = 1e3 + 1e3 * l + Tt, e < 1 ? i = 1 : e < 1.4 && (i = 0.7), h = (1 + l + Mt) / i, f = (1 + l) / i, u = Ct("sqrtMain", h, v, l, t), u.style.minWidth = "0.853em", b = 0.833 / i) : n.type === "large" ? (v = (1e3 + Tt) * S0[n.size], f = (S0[n.size] + l) / i, h = (S0[n.size] + l + Mt) / i, u = Ct("sqrtSize" + n.size, h, v, l, t), u.style.minWidth = "1.02em", b = 1 / i) : (h = e + l + Mt, f = e + l, v = Math.floor(1e3 * e + l) + Tt, u = Ct("sqrtTall", h, v, l, t), u.style.minWidth = "0.742em", b = 1.056), u.height = f, u.style.height = M(h), {
    span: u,
    advanceWidth: b,
    // Calculate the actual line width.
    // This actually should depend on the chosen font -- e.g. \boldmath
    // should use the thicker surd symbols from e.g. KaTeX_Main-Bold, and
    // have thicker rules.
    ruleWidth: (t.fontMetrics().sqrtRuleThickness + l) * i
  };
}, Ha = /* @__PURE__ */ new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\u230A", "\u230B", "\\lceil", "\\rceil", "\u2308", "\u2309", "\\surd"]), $i = /* @__PURE__ */ new Set(["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "\u27EE", "\u27EF", "\\lmoustache", "\\rmoustache", "\u23B0", "\u23B1"]), Ga = /* @__PURE__ */ new Set(["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"]), S0 = [0, 1.2, 1.8, 2.4, 3], Ua = function(e, t, a, n, i) {
  if (e === "<" || e === "\\lt" || e === "\u27E8" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "\u27E9") && (e = "\\rangle"), Ha.has(e) || Ga.has(e))
    return La(e, t, !1, a, n, i);
  if ($i.has(e))
    return Pa(e, S0[t], !1, a, n, i);
  throw new k("Illegal delimiter: '" + e + "'");
}, Xi = [{
  type: "small",
  style: N.SCRIPTSCRIPT
}, {
  type: "small",
  style: N.SCRIPT
}, {
  type: "small",
  style: N.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}], Wi = [{
  type: "small",
  style: N.SCRIPTSCRIPT
}, {
  type: "small",
  style: N.SCRIPT
}, {
  type: "small",
  style: N.TEXT
}, {
  type: "stack"
}], Va = [{
  type: "small",
  style: N.SCRIPTSCRIPT
}, {
  type: "small",
  style: N.SCRIPT
}, {
  type: "small",
  style: N.TEXT
}, {
  type: "large",
  size: 1
}, {
  type: "large",
  size: 2
}, {
  type: "large",
  size: 3
}, {
  type: "large",
  size: 4
}, {
  type: "stack"
}], Yi = function(e) {
  if (e.type === "small")
    return "Main-Regular";
  if (e.type === "large")
    return "Size" + e.size + "-Regular";
  if (e.type === "stack")
    return "Size4-Regular";
  throw new Error("Add support for delim type '" + e.type + "' here.");
}, $a = function(e, t, a, n) {
  for (var i = Math.min(2, 3 - n.style.size), l = i; l < a.length && a[l].type !== "stack"; l++) {
    var u = y0(e, Yi(a[l]), "math"), h = u.height + u.depth;
    if (a[l].type === "small") {
      var f = n.havingBaseStyle(a[l].style);
      h *= f.sizeMultiplier;
    }
    if (h > t)
      return a[l];
  }
  return a[a.length - 1];
}, Vt = function(e, t, a, n, i, l) {
  e === "<" || e === "\\lt" || e === "\u27E8" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "\u27E9") && (e = "\\rangle");
  var u;
  Ga.has(e) ? u = Xi : Ha.has(e) ? u = Va : u = Wi;
  var h = $a(e, t, u, n);
  return h.type === "small" ? Pi(e, h.style, a, n, i, l) : h.type === "large" ? La(e, h.size, a, n, i, l) : Pa(e, t, a, n, i, l);
}, Et = function(e, t, a, n, i, l) {
  var u = n.fontMetrics().axisHeight * n.sizeMultiplier, h = 901, f = 5 / n.fontMetrics().ptPerEm, v = Math.max(t - u, a + u), b = Math.max(
    // In real TeX, calculations are done using integral values which are
    // 65536 per pt, or 655360 per em. So, the division here truncates in
    // TeX but doesn't here, producing different results. If we wanted to
    // exactly match TeX's calculation, we could do
    //   Math.floor(655360 * maxDistFromAxis / 500) *
    //    delimiterFactor / 655360
    // (To see the difference, compare
    //    x^{x^{\left(\rule{0.1em}{0.68em}\right)}}
    // in TeX and KaTeX)
    v / 500 * h,
    2 * v - f
  );
  return Vt(e, b, !0, n, i, l);
}, Pr = {
  "\\bigl": {
    mclass: "mopen",
    size: 1
  },
  "\\Bigl": {
    mclass: "mopen",
    size: 2
  },
  "\\biggl": {
    mclass: "mopen",
    size: 3
  },
  "\\Biggl": {
    mclass: "mopen",
    size: 4
  },
  "\\bigr": {
    mclass: "mclose",
    size: 1
  },
  "\\Bigr": {
    mclass: "mclose",
    size: 2
  },
  "\\biggr": {
    mclass: "mclose",
    size: 3
  },
  "\\Biggr": {
    mclass: "mclose",
    size: 4
  },
  "\\bigm": {
    mclass: "mrel",
    size: 1
  },
  "\\Bigm": {
    mclass: "mrel",
    size: 2
  },
  "\\biggm": {
    mclass: "mrel",
    size: 3
  },
  "\\Biggm": {
    mclass: "mrel",
    size: 4
  },
  "\\big": {
    mclass: "mord",
    size: 1
  },
  "\\Big": {
    mclass: "mord",
    size: 2
  },
  "\\bigg": {
    mclass: "mord",
    size: 3
  },
  "\\Bigg": {
    mclass: "mord",
    size: 4
  }
}, Ki = /* @__PURE__ */ new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\u230A", "\u230B", "\\lceil", "\\rceil", "\u2308", "\u2309", "<", ">", "\\langle", "\u27E8", "\\rangle", "\u27E9", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "\u27EE", "\u27EF", "\\lmoustache", "\\rmoustache", "\u23B0", "\u23B1", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."]);
function ot(r, e) {
  var t = it(r);
  if (t && Ki.has(t.text))
    return t;
  throw t ? new k("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new k("Invalid delimiter type '" + r.type + "'", r);
}
E({
  type: "delimsizing",
  names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"],
  props: {
    numArgs: 1,
    argTypes: ["primitive"]
  },
  handler: (r, e) => {
    var t = ot(e[0], r);
    return {
      type: "delimsizing",
      mode: r.parser.mode,
      size: Pr[r.funcName].size,
      mclass: Pr[r.funcName].mclass,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => r.delim === "." ? S([r.mclass]) : Ua(r.delim, r.size, e, r.mode, [r.mclass]),
  mathmlBuilder: (r) => {
    var e = [];
    r.delim !== "." && e.push(ke(r.delim, r.mode));
    var t = new A("mo", e);
    r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true");
    var a = M(S0[r.size]);
    return t.setAttribute("minsize", a), t.setAttribute("maxsize", a), t;
  }
});
function Hr(r) {
  if (!r.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
E({
  type: "leftright-right",
  names: ["\\right"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = r.parser.gullet.macros.get("\\current@color");
    if (t && typeof t != "string")
      throw new k("\\current@color set to non-string in \\right");
    return {
      type: "leftright-right",
      mode: r.parser.mode,
      delim: ot(e[0], r).text,
      color: t
      // undefined if not set via \color
    };
  }
});
E({
  type: "leftright",
  names: ["\\left"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = ot(e[0], r), a = r.parser;
    ++a.leftrightDepth;
    var n = a.parseExpression(!1);
    --a.leftrightDepth, a.expect("\\right", !1);
    var i = O(a.parseFunction(), "leftright-right");
    return {
      type: "leftright",
      mode: a.mode,
      body: n,
      left: t.text,
      right: i.delim,
      rightColor: i.color
    };
  },
  htmlBuilder: (r, e) => {
    Hr(r);
    for (var t = se(r.body, e, !0, ["mopen", "mclose"]), a = 0, n = 0, i = !1, l = 0; l < t.length; l++)
      t[l].isMiddle ? i = !0 : (a = Math.max(t[l].height, a), n = Math.max(t[l].depth, n));
    a *= e.sizeMultiplier, n *= e.sizeMultiplier;
    var u;
    if (r.left === "." ? u = M0(e, ["mopen"]) : u = Et(r.left, a, n, e, r.mode, ["mopen"]), t.unshift(u), i)
      for (var h = 1; h < t.length; h++) {
        var f = t[h], v = f.isMiddle;
        v && (t[h] = Et(v.delim, a, n, v.options, r.mode, []));
      }
    var b;
    if (r.right === ".")
      b = M0(e, ["mclose"]);
    else {
      var y = r.rightColor ? e.withColor(r.rightColor) : e;
      b = Et(r.right, a, n, y, r.mode, ["mclose"]);
    }
    return t.push(b), S(["minner"], t, e);
  },
  mathmlBuilder: (r, e) => {
    Hr(r);
    var t = ge(r.body, e);
    if (r.left !== ".") {
      var a = new A("mo", [ke(r.left, r.mode)]);
      a.setAttribute("fence", "true"), t.unshift(a);
    }
    if (r.right !== ".") {
      var n = new A("mo", [ke(r.right, r.mode)]);
      n.setAttribute("fence", "true"), r.rightColor && n.setAttribute("mathcolor", r.rightColor), t.push(n);
    }
    return rr(t);
  }
});
E({
  type: "middle",
  names: ["\\middle"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var t = ot(e[0], r);
    if (!r.parser.leftrightDepth)
      throw new k("\\middle without preceding \\left", t);
    return {
      type: "middle",
      mode: r.parser.mode,
      delim: t.text
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    if (r.delim === ".")
      t = M0(e, []);
    else {
      t = Ua(r.delim, 1, e, r.mode, []);
      var a = {
        delim: r.delim,
        options: e
      };
      t.isMiddle = a;
    }
    return t;
  },
  mathmlBuilder: (r, e) => {
    var t = r.delim === "\\vert" || r.delim === "|" ? ke("|", "text") : ke(r.delim, r.mode), a = new A("mo", [t]);
    return a.setAttribute("fence", "true"), a.setAttribute("lspace", "0.05em"), a.setAttribute("rspace", "0.05em"), a;
  }
});
var or = (r, e) => {
  var t = v0(H(r.body, e), e), a = r.label.slice(1), n = e.sizeMultiplier, i, l = 0, u = Pe(r.body);
  if (a === "sout")
    i = S(["stretchy", "sout"]), i.height = e.fontMetrics().defaultRuleThickness / n, l = -0.5 * e.fontMetrics().xHeight;
  else if (a === "phase") {
    var h = J({
      number: 0.6,
      unit: "pt"
    }, e), f = J({
      number: 0.35,
      unit: "ex"
    }, e), v = e.havingBaseSizing();
    n = n / v.sizeMultiplier;
    var b = t.height + t.depth + h + f;
    t.style.paddingLeft = M(b / 2 + h);
    var y = Math.floor(1e3 * b * n), x = Jn(y), T = new _e([new r0("phase", x)], {
      width: "400em",
      height: M(y / 1e3),
      viewBox: "0 0 400000 " + y,
      preserveAspectRatio: "xMinYMin slice"
    });
    i = je(["hide-tail"], [T], e), i.style.height = M(b), l = t.depth + h + f;
  } else {
    /cancel/.test(a) ? u || t.classes.push("cancel-pad") : a === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var C = 0, D = 0, R = 0;
    /box/.test(a) ? (R = Math.max(
      e.fontMetrics().fboxrule,
      // default
      e.minRuleThickness
      // User override.
    ), C = e.fontMetrics().fboxsep + (a === "colorbox" ? 0 : R), D = C) : a === "angl" ? (R = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), C = 4 * R, D = Math.max(0, 0.25 - t.depth)) : (C = u ? 0.2 : 0, D = C), i = Fi(t, a, C, D, e), /fbox|boxed|fcolorbox/.test(a) ? (i.style.borderStyle = "solid", i.style.borderWidth = M(R)) : a === "angl" && R !== 0.049 && (i.style.borderTopWidth = M(R), i.style.borderRightWidth = M(R)), l = t.depth + D, r.backgroundColor && (i.style.backgroundColor = r.backgroundColor, r.borderColor && (i.style.borderColor = r.borderColor));
  }
  var B;
  if (r.backgroundColor)
    B = U({
      positionType: "individualShift",
      children: [
        // Put the color background behind inner;
        {
          type: "elem",
          elem: i,
          shift: l
        },
        {
          type: "elem",
          elem: t,
          shift: 0
        }
      ]
    });
  else {
    var q = /cancel|phase/.test(a) ? ["svg-align"] : [];
    B = U({
      positionType: "individualShift",
      children: [
        // Write the \cancel stroke on top of inner.
        {
          type: "elem",
          elem: t,
          shift: 0
        },
        {
          type: "elem",
          elem: i,
          shift: l,
          wrapperClasses: q
        }
      ]
    });
  }
  return /cancel/.test(a) && (B.height = t.height, B.depth = t.depth), /cancel/.test(a) && !u ? S(["mord", "cancel-lap"], [B], e) : S(["mord"], [B], e);
}, lr = (r, e) => {
  var t = 0, a = new A(r.label.includes("colorbox") ? "mpadded" : "menclose", [Y(r.body, e)]);
  switch (r.label) {
    case "\\cancel":
      a.setAttribute("notation", "updiagonalstrike");
      break;
    case "\\bcancel":
      a.setAttribute("notation", "downdiagonalstrike");
      break;
    case "\\phase":
      a.setAttribute("notation", "phasorangle");
      break;
    case "\\sout":
      a.setAttribute("notation", "horizontalstrike");
      break;
    case "\\fbox":
      a.setAttribute("notation", "box");
      break;
    case "\\angl":
      a.setAttribute("notation", "actuarial");
      break;
    case "\\fcolorbox":
    case "\\colorbox":
      if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, a.setAttribute("width", "+" + 2 * t + "pt"), a.setAttribute("height", "+" + 2 * t + "pt"), a.setAttribute("lspace", t + "pt"), a.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
        var n = Math.max(
          e.fontMetrics().fboxrule,
          // default
          e.minRuleThickness
          // user override
        );
        a.setAttribute("style", "border: " + n + "em solid " + String(r.borderColor));
      }
      break;
    case "\\xcancel":
      a.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
      break;
  }
  return r.backgroundColor && a.setAttribute("mathbackground", r.backgroundColor), a;
};
E({
  type: "enclose",
  names: ["\\colorbox"],
  props: {
    numArgs: 2,
    allowedInText: !0,
    argTypes: ["color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: a,
      funcName: n
    } = r, i = O(e[0], "color-token").color, l = e[1];
    return {
      type: "enclose",
      mode: a.mode,
      label: n,
      backgroundColor: i,
      body: l
    };
  },
  htmlBuilder: or,
  mathmlBuilder: lr
});
E({
  type: "enclose",
  names: ["\\fcolorbox"],
  props: {
    numArgs: 3,
    allowedInText: !0,
    argTypes: ["color", "color", "text"]
  },
  handler(r, e, t) {
    var {
      parser: a,
      funcName: n
    } = r, i = O(e[0], "color-token").color, l = O(e[1], "color-token").color, u = e[2];
    return {
      type: "enclose",
      mode: a.mode,
      label: n,
      backgroundColor: l,
      borderColor: i,
      body: u
    };
  },
  htmlBuilder: or,
  mathmlBuilder: lr
});
E({
  type: "enclose",
  names: ["\\fbox"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\fbox",
      body: e[0]
    };
  }
});
E({
  type: "enclose",
  names: ["\\cancel", "\\bcancel", "\\xcancel", "\\sout", "\\phase"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "enclose",
      mode: t.mode,
      label: a,
      body: n
    };
  },
  htmlBuilder: or,
  mathmlBuilder: lr
});
E({
  type: "enclose",
  names: ["\\angl"],
  props: {
    numArgs: 1,
    argTypes: ["hbox"],
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "enclose",
      mode: t.mode,
      label: "\\angl",
      body: e[0]
    };
  }
});
var Xa = {};
function Re(r) {
  for (var {
    type: e,
    names: t,
    props: a,
    handler: n,
    htmlBuilder: i,
    mathmlBuilder: l
  } = r, u = {
    type: e,
    numArgs: a.numArgs || 0,
    allowedInText: !1,
    numOptionalArgs: 0,
    handler: n
  }, h = 0; h < t.length; ++h)
    Xa[t[h]] = u;
  i && (K0[e] = i), l && (_0[e] = l);
}
var Wa = {};
function m(r, e) {
  Wa[r] = e;
}
function Gr(r) {
  var e = [];
  r.consumeSpaces();
  var t = r.fetch().text;
  for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline"; )
    r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text;
  return e;
}
var lt = (r) => {
  var e = r.parser.settings;
  if (!e.displayMode)
    throw new k("{" + r.envName + "} can be used only in display mode.");
}, _i = /* @__PURE__ */ new Set(["gather", "gather*"]);
function ur(r) {
  if (!r.includes("ed"))
    return !r.includes("*");
}
function Je(r, e, t) {
  var {
    hskipBeforeAndAfter: a,
    addJot: n,
    cols: i,
    arraystretch: l,
    colSeparationType: u,
    autoTag: h,
    singleRow: f,
    emptySingleRow: v,
    maxNumCols: b,
    leqno: y
  } = e;
  if (r.gullet.beginGroup(), f || r.gullet.macros.set("\\cr", "\\\\\\relax"), !l) {
    var x = r.gullet.expandMacroAsText("\\arraystretch");
    if (x == null)
      l = 1;
    else if (l = parseFloat(x), !l || l < 0)
      throw new k("Invalid \\arraystretch: " + x);
  }
  r.gullet.beginGroup();
  var T = [], C = [T], D = [], R = [], B = h != null ? [] : void 0;
  function q() {
    h && r.gullet.macros.set("\\@eqnsw", "1", !0);
  }
  function V() {
    B && (r.gullet.macros.get("\\df@tag") ? (B.push(r.subparse([new be("\\df@tag")])), r.gullet.macros.set("\\df@tag", void 0, !0)) : B.push(!!h && r.gullet.macros.get("\\@eqnsw") === "1"));
  }
  for (q(), R.push(Gr(r)); ; ) {
    var L = r.parseExpression(!1, f ? "\\end" : "\\\\");
    r.gullet.endGroup(), r.gullet.beginGroup(), L = {
      type: "ordgroup",
      mode: r.mode,
      body: L
    }, t && (L = {
      type: "styling",
      mode: r.mode,
      style: t,
      body: [L]
    }), T.push(L);
    var $ = r.fetch().text;
    if ($ === "&") {
      if (b && T.length === b) {
        if (f || u)
          throw new k("Too many tab characters: &", r.nextToken);
        r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
      }
      r.consume();
    } else if ($ === "\\end") {
      V(), T.length === 1 && L.type === "styling" && L.body[0].body.length === 0 && (C.length > 1 || !v) && C.pop(), R.length < C.length + 1 && R.push([]);
      break;
    } else if ($ === "\\\\") {
      r.consume();
      var G = void 0;
      r.gullet.future().text !== " " && (G = r.parseSizeGroup(!0)), D.push(G ? G.value : null), V(), R.push(Gr(r)), T = [], C.push(T), q();
    } else
      throw new k("Expected & or \\\\ or \\cr or \\end", r.nextToken);
  }
  return r.gullet.endGroup(), r.gullet.endGroup(), {
    type: "array",
    mode: r.mode,
    addJot: n,
    arraystretch: l,
    body: C,
    cols: i,
    rowGaps: D,
    hskipBeforeAndAfter: a,
    hLinesBeforeRow: R,
    colSeparationType: u,
    tags: B,
    leqno: y
  };
}
function cr(r) {
  return r.slice(0, 1) === "d" ? "display" : "text";
}
var Fe = function(e, t) {
  var a, n, i = e.body.length, l = e.hLinesBeforeRow, u = 0, h = new Array(i), f = [], v = Math.max(
    // From LaTeX \showthe\arrayrulewidth. Equals 0.04 em.
    t.fontMetrics().arrayRuleWidth,
    t.minRuleThickness
    // User override.
  ), b = 1 / t.fontMetrics().ptPerEm, y = 5 * b;
  if (e.colSeparationType && e.colSeparationType === "small") {
    var x = t.havingStyle(N.SCRIPT).sizeMultiplier;
    y = 0.2778 * (x / t.sizeMultiplier);
  }
  var T = e.colSeparationType === "CD" ? J({
    number: 3,
    unit: "ex"
  }, t) : 12 * b, C = 3 * b, D = e.arraystretch * T, R = 0.7 * D, B = 0.3 * D, q = 0;
  function V(F0) {
    for (var I0 = 0; I0 < F0.length; ++I0)
      I0 > 0 && (q += 0.25), f.push({
        pos: q,
        isDashed: F0[I0]
      });
  }
  for (V(l[0]), a = 0; a < e.body.length; ++a) {
    var L = e.body[a], $ = R, G = B;
    u < L.length && (u = L.length);
    var j = new Array(L.length);
    for (n = 0; n < L.length; ++n) {
      var X = H(L[n], t);
      G < X.depth && (G = X.depth), $ < X.height && ($ = X.height), j[n] = X;
    }
    var Be = e.rowGaps[a], ce = 0;
    Be && (ce = J(Be, t), ce > 0 && (ce += B, G < ce && (G = ce), ce = 0)), e.addJot && (G += C), j.height = $, j.depth = G, q += $, j.pos = q, q += G + ce, h[a] = j, V(l[a + 1]);
  }
  var ie = q / 2 + t.fontMetrics().axisHeight, Qe = e.cols || [], fe = [], Te, Ue, n0 = [];
  if (e.tags && e.tags.some((F0) => F0))
    for (a = 0; a < i; ++a) {
      var i0 = h[a], ct = i0.pos - ie, Ve = e.tags[a], $e = void 0;
      Ve === !0 ? $e = S(["eqn-num"], [], t) : Ve === !1 ? $e = S([], [], t) : $e = S([], se(Ve, t, !0), t), $e.depth = i0.depth, $e.height = i0.height, n0.push({
        type: "elem",
        elem: $e,
        shift: ct
      });
    }
  for (
    n = 0, Ue = 0;
    // Continue while either there are more columns or more column
    // descriptions, so trailing separators don't get lost.
    n < u || Ue < Qe.length;
    ++n, ++Ue
  ) {
    for (var xe = Qe[Ue] || {}, z0 = !0; xe.type === "separator"; ) {
      if (z0 || (Te = S(["arraycolsep"], []), Te.style.width = M(t.fontMetrics().doubleRuleSep), fe.push(Te)), xe.separator === "|" || xe.separator === ":") {
        var ht = xe.separator === "|" ? "solid" : "dashed", s0 = S(["vertical-separator"], [], t);
        s0.style.height = M(q), s0.style.borderRightWidth = M(v), s0.style.borderRightStyle = ht, s0.style.margin = "0 " + M(-v / 2);
        var pr = q - ie;
        pr && (s0.style.verticalAlign = M(-pr)), fe.push(s0);
      } else
        throw new k("Invalid separator type: " + xe.separator);
      Ue++, xe = Qe[Ue] || {}, z0 = !1;
    }
    if (!(n >= u)) {
      var o0 = void 0;
      if (n > 0 || e.hskipBeforeAndAfter) {
        var fr;
        o0 = (fr = xe.pregap) != null ? fr : y, o0 !== 0 && (Te = S(["arraycolsep"], []), Te.style.width = M(o0), fe.push(Te));
      }
      var l0 = [];
      for (a = 0; a < i; ++a) {
        var D0 = h[a], R0 = D0[n];
        if (R0) {
          var fn = D0.pos - ie;
          R0.depth = D0.depth, R0.height = D0.height, l0.push({
            type: "elem",
            elem: R0,
            shift: fn
          });
        }
      }
      if (l0 = U({
        positionType: "individualShift",
        children: l0
      }), l0 = S(["col-align-" + (xe.align || "c")], [l0]), fe.push(l0), n < u - 1 || e.hskipBeforeAndAfter) {
        var vr;
        o0 = (vr = xe.postgap) != null ? vr : y, o0 !== 0 && (Te = S(["arraycolsep"], []), Te.style.width = M(o0), fe.push(Te));
      }
    }
  }
  if (h = S(["mtable"], fe), f.length > 0) {
    for (var vn = f0("hline", t, v), gn = f0("hdashline", t, v), mt = [{
      type: "elem",
      elem: h,
      shift: 0
    }]; f.length > 0; ) {
      var gr = f.pop(), br = gr.pos - ie;
      gr.isDashed ? mt.push({
        type: "elem",
        elem: gn,
        shift: br
      }) : mt.push({
        type: "elem",
        elem: vn,
        shift: br
      });
    }
    h = U({
      positionType: "individualShift",
      children: mt
    });
  }
  if (n0.length === 0)
    return S(["mord"], [h], t);
  var dt = U({
    positionType: "individualShift",
    children: n0
  });
  return dt = S(["tag"], [dt], t), Ge([h, dt]);
}, ji = {
  c: "center ",
  l: "left ",
  r: "right "
}, Ie = function(e, t) {
  for (var a = [], n = new A("mtd", [], ["mtr-glue"]), i = new A("mtd", [], ["mml-eqn-num"]), l = 0; l < e.body.length; l++) {
    for (var u = e.body[l], h = [], f = 0; f < u.length; f++)
      h.push(new A("mtd", [Y(u[f], t)]));
    e.tags && e.tags[l] && (h.unshift(n), h.push(n), e.leqno ? h.unshift(i) : h.push(i)), a.push(new A("mtr", h));
  }
  var v = new A("mtable", a), b = e.arraystretch === 0.5 ? 0.1 : 0.16 + e.arraystretch - 1 + (e.addJot ? 0.09 : 0);
  v.setAttribute("rowspacing", M(b));
  var y = "", x = "";
  if (e.cols && e.cols.length > 0) {
    var T = e.cols, C = "", D = !1, R = 0, B = T.length;
    T[0].type === "separator" && (y += "top ", R = 1), T[T.length - 1].type === "separator" && (y += "bottom ", B -= 1);
    for (var q = R; q < B; q++)
      T[q].type === "align" ? (x += ji[T[q].align], D && (C += "none "), D = !0) : T[q].type === "separator" && D && (C += T[q].separator === "|" ? "solid " : "dashed ", D = !1);
    v.setAttribute("columnalign", x.trim()), /[sd]/.test(C) && v.setAttribute("columnlines", C.trim());
  }
  if (e.colSeparationType === "align") {
    for (var V = e.cols || [], L = "", $ = 1; $ < V.length; $++)
      L += $ % 2 ? "0em " : "1em ";
    v.setAttribute("columnspacing", L.trim());
  } else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? v.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? v.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? v.setAttribute("columnspacing", "0.5em") : v.setAttribute("columnspacing", "1em");
  var G = "", j = e.hLinesBeforeRow;
  y += j[0].length > 0 ? "left " : "", y += j[j.length - 1].length > 0 ? "right " : "";
  for (var X = 1; X < j.length - 1; X++)
    G += j[X].length === 0 ? "none " : j[X][0] ? "dashed " : "solid ";
  return /[sd]/.test(G) && v.setAttribute("rowlines", G.trim()), y !== "" && (v = new A("menclose", [v]), v.setAttribute("notation", y.trim())), e.arraystretch && e.arraystretch < 1 && (v = new A("mstyle", [v]), v.setAttribute("scriptlevel", "1")), v;
}, Ya = function(e, t) {
  e.envName.includes("ed") || lt(e);
  var a = [], n = e.envName.includes("at") ? "alignat" : "align", i = e.envName === "split", l = Je(e.parser, {
    cols: a,
    addJot: !0,
    autoTag: i ? void 0 : ur(e.envName),
    emptySingleRow: !0,
    colSeparationType: n,
    maxNumCols: i ? 2 : void 0,
    leqno: e.parser.settings.leqno
  }, "display"), u, h = 0, f = {
    type: "ordgroup",
    mode: e.mode,
    body: []
  };
  if (t[0] && t[0].type === "ordgroup") {
    for (var v = "", b = 0; b < t[0].body.length; b++) {
      var y = O(t[0].body[b], "textord");
      v += y.text;
    }
    u = Number(v), h = u * 2;
  }
  var x = !h;
  l.body.forEach(function(R) {
    for (var B = 1; B < R.length; B += 2) {
      var q = O(R[B], "styling"), V = O(q.body[0], "ordgroup");
      V.body.unshift(f);
    }
    if (x)
      h < R.length && (h = R.length);
    else {
      var L = R.length / 2;
      if (u < L)
        throw new k("Too many math in a row: " + ("expected " + u + ", but got " + L), R[0]);
    }
  });
  for (var T = 0; T < h; ++T) {
    var C = "r", D = 0;
    T % 2 === 1 ? C = "l" : T > 0 && x && (D = 1), a[T] = {
      type: "align",
      align: C,
      pregap: D,
      postgap: 0
    };
  }
  return l.colSeparationType = x ? "align" : "alignat", l;
};
Re({
  type: "array",
  names: ["array", "darray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = it(e[0]), a = t ? [e[0]] : O(e[0], "ordgroup").body, n = a.map(function(l) {
      var u = nr(l), h = u.text;
      if ("lcr".includes(h))
        return {
          type: "align",
          align: h
        };
      if (h === "|")
        return {
          type: "separator",
          separator: "|"
        };
      if (h === ":")
        return {
          type: "separator",
          separator: ":"
        };
      throw new k("Unknown column alignment: " + h, l);
    }), i = {
      cols: n,
      hskipBeforeAndAfter: !0,
      // \@preamble in lttab.dtx
      maxNumCols: n.length
    };
    return Je(r.parser, i, cr(r.envName));
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      matrix: null,
      pmatrix: ["(", ")"],
      bmatrix: ["[", "]"],
      Bmatrix: ["\\{", "\\}"],
      vmatrix: ["|", "|"],
      Vmatrix: ["\\Vert", "\\Vert"]
    }[r.envName.replace("*", "")], t = "c", a = {
      hskipBeforeAndAfter: !1,
      cols: [{
        type: "align",
        align: t
      }]
    };
    if (r.envName.charAt(r.envName.length - 1) === "*") {
      var n = r.parser;
      if (n.consumeSpaces(), n.fetch().text === "[") {
        if (n.consume(), n.consumeSpaces(), t = n.fetch().text, !"lcr".includes(t))
          throw new k("Expected l or c or r", n.nextToken);
        n.consume(), n.consumeSpaces(), n.expect("]"), n.consume(), a.cols = [{
          type: "align",
          align: t
        }];
      }
    }
    var i = Je(r.parser, a, cr(r.envName)), l = Math.max(0, ...i.body.map((u) => u.length));
    return i.cols = new Array(l).fill({
      type: "align",
      align: t
    }), e ? {
      type: "leftright",
      mode: r.mode,
      body: [i],
      left: e[0],
      right: e[1],
      rightColor: void 0
      // \right uninfluenced by \color in array
    } : i;
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["smallmatrix"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 0.5
    }, t = Je(r.parser, e, "script");
    return t.colSeparationType = "small", t;
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["subarray"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var t = it(e[0]), a = t ? [e[0]] : O(e[0], "ordgroup").body, n = a.map(function(l) {
      var u = nr(l), h = u.text;
      if ("lc".includes(h))
        return {
          type: "align",
          align: h
        };
      throw new k("Unknown column alignment: " + h, l);
    });
    if (n.length > 1)
      throw new k("{subarray} can contain only one column");
    var i = {
      cols: n,
      hskipBeforeAndAfter: !1,
      arraystretch: 0.5
    };
    if (i = Je(r.parser, i, "script"), i.body.length > 0 && i.body[0].length > 1)
      throw new k("{subarray} can contain only one column");
    return i;
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["cases", "dcases", "rcases", "drcases"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var e = {
      arraystretch: 1.2,
      cols: [{
        type: "align",
        align: "l",
        pregap: 0,
        // TODO(kevinb) get the current style.
        // For now we use the metrics for TEXT style which is what we were
        // doing before.  Before attempting to get the current style we
        // should look at TeX's behavior especially for \over and matrices.
        postgap: 1
        /* 1em quad */
      }, {
        type: "align",
        align: "l",
        pregap: 0,
        postgap: 0
      }]
    }, t = Je(r.parser, e, cr(r.envName));
    return {
      type: "leftright",
      mode: r.mode,
      body: [t],
      left: r.envName.includes("r") ? "." : "\\{",
      right: r.envName.includes("r") ? "\\}" : ".",
      rightColor: void 0
    };
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["align", "align*", "aligned", "split"],
  props: {
    numArgs: 0
  },
  handler: Ya,
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["gathered", "gather", "gather*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    _i.has(r.envName) && lt(r);
    var e = {
      cols: [{
        type: "align",
        align: "c"
      }],
      addJot: !0,
      colSeparationType: "gather",
      autoTag: ur(r.envName),
      emptySingleRow: !0,
      leqno: r.parser.settings.leqno
    };
    return Je(r.parser, e, "display");
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["alignat", "alignat*", "alignedat"],
  props: {
    numArgs: 1
  },
  handler: Ya,
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["equation", "equation*"],
  props: {
    numArgs: 0
  },
  handler(r) {
    lt(r);
    var e = {
      autoTag: ur(r.envName),
      emptySingleRow: !0,
      singleRow: !0,
      maxNumCols: 1,
      leqno: r.parser.settings.leqno
    };
    return Je(r.parser, e, "display");
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
Re({
  type: "array",
  names: ["CD"],
  props: {
    numArgs: 0
  },
  handler(r) {
    return lt(r), Oi(r.parser);
  },
  htmlBuilder: Fe,
  mathmlBuilder: Ie
});
m("\\nonumber", "\\gdef\\@eqnsw{0}");
m("\\notag", "\\nonumber");
E({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\hline", "\\hdashline"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !0
  },
  handler(r, e) {
    throw new k(r.funcName + " valid only within array environment");
  }
});
var Ur = Xa;
E({
  type: "environment",
  names: ["\\begin", "\\end"],
  props: {
    numArgs: 1,
    argTypes: ["text"]
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    if (n.type !== "ordgroup")
      throw new k("Invalid environment name", n);
    for (var i = "", l = 0; l < n.body.length; ++l)
      i += O(n.body[l], "textord").text;
    if (a === "\\begin") {
      if (!Ur.hasOwnProperty(i))
        throw new k("No such environment: " + i, n);
      var u = Ur[i], {
        args: h,
        optArgs: f
      } = t.parseArguments("\\begin{" + i + "}", u), v = {
        mode: t.mode,
        envName: i,
        parser: t
      }, b = u.handler(v, h, f);
      t.expect("\\end", !1);
      var y = t.nextToken, x = O(t.parseFunction(), "environment");
      if (x.name !== i)
        throw new k("Mismatch: \\begin{" + i + "} matched by \\end{" + x.name + "}", y);
      return b;
    }
    return {
      type: "environment",
      mode: t.mode,
      name: i,
      nameGroup: n
    };
  }
});
var Ka = (r, e) => {
  var t = r.font, a = e.withFont(t);
  return H(r.body, a);
}, _a = (r, e) => {
  var t = r.font, a = e.withFont(t);
  return Y(r.body, a);
}, Vr = {
  "\\Bbb": "\\mathbb",
  "\\bold": "\\mathbf",
  "\\frak": "\\mathfrak",
  "\\bm": "\\boldsymbol"
};
E({
  type: "font",
  names: [
    // styles, except \boldsymbol defined below
    "\\mathrm",
    "\\mathit",
    "\\mathbf",
    "\\mathnormal",
    "\\mathsfit",
    // families
    "\\mathbb",
    "\\mathcal",
    "\\mathfrak",
    "\\mathscr",
    "\\mathsf",
    "\\mathtt",
    // aliases, except \bm defined below
    "\\Bbb",
    "\\bold",
    "\\frak"
  ],
  props: {
    numArgs: 1,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = j0(e[0]), i = a;
    return i in Vr && (i = Vr[i]), {
      type: "font",
      mode: t.mode,
      font: i.slice(1),
      body: n
    };
  },
  htmlBuilder: Ka,
  mathmlBuilder: _a
});
E({
  type: "mclass",
  names: ["\\boldsymbol", "\\bm"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "mclass",
      mode: t.mode,
      mclass: st(a),
      body: [{
        type: "font",
        mode: t.mode,
        font: "boldsymbol",
        body: a
      }],
      isCharacterBox: Pe(a)
    };
  }
});
E({
  type: "font",
  names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a,
      breakOnTokenText: n
    } = r, {
      mode: i
    } = t, l = t.parseExpression(!0, n), u = "math" + a.slice(1);
    return {
      type: "font",
      mode: i,
      font: u,
      body: {
        type: "ordgroup",
        mode: t.mode,
        body: l
      }
    };
  },
  htmlBuilder: Ka,
  mathmlBuilder: _a
});
var Zi = (r, e) => {
  var t = e.style, a = t.fracNum(), n = t.fracDen(), i;
  i = e.havingStyle(a);
  var l = H(r.numer, i, e);
  if (r.continued) {
    var u = 8.5 / e.fontMetrics().ptPerEm, h = 3.5 / e.fontMetrics().ptPerEm;
    l.height = l.height < u ? u : l.height, l.depth = l.depth < h ? h : l.depth;
  }
  i = e.havingStyle(n);
  var f = H(r.denom, i, e), v, b, y;
  r.hasBarLine ? (r.barSize ? (b = J(r.barSize, e), v = f0("frac-line", e, b)) : v = f0("frac-line", e), b = v.height, y = v.height) : (v = null, b = 0, y = e.fontMetrics().defaultRuleThickness);
  var x, T, C;
  t.size === N.DISPLAY.size ? (x = e.fontMetrics().num1, b > 0 ? T = 3 * y : T = 7 * y, C = e.fontMetrics().denom1) : (b > 0 ? (x = e.fontMetrics().num2, T = y) : (x = e.fontMetrics().num3, T = 3 * y), C = e.fontMetrics().denom2);
  var D;
  if (v) {
    var B = e.fontMetrics().axisHeight;
    x - l.depth - (B + 0.5 * b) < T && (x += T - (x - l.depth - (B + 0.5 * b))), B - 0.5 * b - (f.height - C) < T && (C += T - (B - 0.5 * b - (f.height - C)));
    var q = -(B - 0.5 * b);
    D = U({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: f,
        shift: C
      }, {
        type: "elem",
        elem: v,
        shift: q
      }, {
        type: "elem",
        elem: l,
        shift: -x
      }]
    });
  } else {
    var R = x - l.depth - (f.height - C);
    R < T && (x += 0.5 * (T - R), C += 0.5 * (T - R)), D = U({
      positionType: "individualShift",
      children: [{
        type: "elem",
        elem: f,
        shift: C
      }, {
        type: "elem",
        elem: l,
        shift: -x
      }]
    });
  }
  i = e.havingStyle(t), D.height *= i.sizeMultiplier / e.sizeMultiplier, D.depth *= i.sizeMultiplier / e.sizeMultiplier;
  var V;
  t.size === N.DISPLAY.size ? V = e.fontMetrics().delim1 : t.size === N.SCRIPTSCRIPT.size ? V = e.havingStyle(N.SCRIPT).fontMetrics().delim2 : V = e.fontMetrics().delim2;
  var L, $;
  return r.leftDelim == null ? L = M0(e, ["mopen"]) : L = Vt(r.leftDelim, V, !0, e.havingStyle(t), r.mode, ["mopen"]), r.continued ? $ = S([]) : r.rightDelim == null ? $ = M0(e, ["mclose"]) : $ = Vt(r.rightDelim, V, !0, e.havingStyle(t), r.mode, ["mclose"]), S(["mord"].concat(i.sizingClasses(e)), [L, S(["mfrac"], [D]), $], e);
}, Ji = (r, e) => {
  var t = new A("mfrac", [Y(r.numer, e), Y(r.denom, e)]);
  if (!r.hasBarLine)
    t.setAttribute("linethickness", "0px");
  else if (r.barSize) {
    var a = J(r.barSize, e);
    t.setAttribute("linethickness", M(a));
  }
  if (r.leftDelim != null || r.rightDelim != null) {
    var n = [];
    if (r.leftDelim != null) {
      var i = new A("mo", [new ae(r.leftDelim.replace("\\", ""))]);
      i.setAttribute("fence", "true"), n.push(i);
    }
    if (n.push(t), r.rightDelim != null) {
      var l = new A("mo", [new ae(r.rightDelim.replace("\\", ""))]);
      l.setAttribute("fence", "true"), n.push(l);
    }
    return rr(n);
  }
  return t;
}, ja = (r, e) => {
  if (!e)
    return r;
  var t = {
    type: "styling",
    mode: r.mode,
    style: e,
    body: [r]
  };
  return t;
};
E({
  type: "genfrac",
  names: [
    "\\cfrac",
    "\\dfrac",
    "\\frac",
    "\\tfrac",
    "\\dbinom",
    "\\binom",
    "\\tbinom",
    "\\\\atopfrac",
    // can’t be entered directly
    "\\\\bracefrac",
    "\\\\brackfrac"
    // ditto
  ],
  props: {
    numArgs: 2,
    allowedInArgument: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0], i = e[1], l, u = null, h = null;
    switch (a) {
      case "\\cfrac":
      case "\\dfrac":
      case "\\frac":
      case "\\tfrac":
        l = !0;
        break;
      case "\\\\atopfrac":
        l = !1;
        break;
      case "\\dbinom":
      case "\\binom":
      case "\\tbinom":
        l = !1, u = "(", h = ")";
        break;
      case "\\\\bracefrac":
        l = !1, u = "\\{", h = "\\}";
        break;
      case "\\\\brackfrac":
        l = !1, u = "[", h = "]";
        break;
      default:
        throw new Error("Unrecognized genfrac command");
    }
    var f = a === "\\cfrac", v = null;
    return f || a.startsWith("\\d") ? v = "display" : a.startsWith("\\t") && (v = "text"), ja({
      type: "genfrac",
      mode: t.mode,
      numer: n,
      denom: i,
      continued: f,
      hasBarLine: l,
      leftDelim: u,
      rightDelim: h,
      barSize: null
    }, v);
  },
  htmlBuilder: Zi,
  mathmlBuilder: Ji
});
E({
  type: "infix",
  names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"],
  props: {
    numArgs: 0,
    infix: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t,
      token: a
    } = r, n;
    switch (t) {
      case "\\over":
        n = "\\frac";
        break;
      case "\\choose":
        n = "\\binom";
        break;
      case "\\atop":
        n = "\\\\atopfrac";
        break;
      case "\\brace":
        n = "\\\\bracefrac";
        break;
      case "\\brack":
        n = "\\\\brackfrac";
        break;
      default:
        throw new Error("Unrecognized infix genfrac command");
    }
    return {
      type: "infix",
      mode: e.mode,
      replaceWith: n,
      token: a
    };
  }
});
var $r = ["display", "text", "script", "scriptscript"], Xr = function(e) {
  var t = null;
  return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
E({
  type: "genfrac",
  names: ["\\genfrac"],
  props: {
    numArgs: 6,
    allowedInArgument: !0,
    argTypes: ["math", "math", "size", "text", "math", "math"]
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = e[4], n = e[5], i = j0(e[0]), l = i.type === "atom" && i.family === "open" ? Xr(i.text) : null, u = j0(e[1]), h = u.type === "atom" && u.family === "close" ? Xr(u.text) : null, f = O(e[2], "size"), v, b = null;
    f.isBlank ? v = !0 : (b = f.value, v = b.number > 0);
    var y = null, x = e[3];
    if (x.type === "ordgroup") {
      if (x.body.length > 0) {
        var T = O(x.body[0], "textord");
        y = $r[Number(T.text)];
      }
    } else
      x = O(x, "textord"), y = $r[Number(x.text)];
    return ja({
      type: "genfrac",
      mode: t.mode,
      numer: a,
      denom: n,
      continued: !1,
      hasBarLine: v,
      barSize: b,
      leftDelim: l,
      rightDelim: h
    }, y);
  }
});
E({
  type: "infix",
  names: ["\\above"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    infix: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a,
      token: n
    } = r;
    return {
      type: "infix",
      mode: t.mode,
      replaceWith: "\\\\abovefrac",
      size: O(e[0], "size").value,
      token: n
    };
  }
});
E({
  type: "genfrac",
  names: ["\\\\abovefrac"],
  props: {
    numArgs: 3,
    argTypes: ["math", "size", "math"]
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0], i = O(e[1], "infix").size;
    if (!i)
      throw new Error("\\\\abovefrac expected size, but got " + String(i));
    var l = e[2], u = i.number > 0;
    return {
      type: "genfrac",
      mode: t.mode,
      numer: n,
      denom: l,
      continued: !1,
      hasBarLine: u,
      barSize: i,
      leftDelim: null,
      rightDelim: null
    };
  }
});
var Za = (r, e) => {
  var t = e.style, a, n;
  r.type === "supsub" ? (a = r.sup ? H(r.sup, e.havingStyle(t.sup()), e) : H(r.sub, e.havingStyle(t.sub()), e), n = O(r.base, "horizBrace")) : n = O(r, "horizBrace");
  var i = H(n.base, e.havingBaseStyle(N.DISPLAY)), l = nt(n, e), u;
  if (n.isOver ? (u = U({
    positionType: "firstBaseline",
    children: [{
      type: "elem",
      elem: i
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: l
    }]
  }), u.children[0].children[0].children[1].classes.push("svg-align")) : (u = U({
    positionType: "bottom",
    positionData: i.depth + 0.1 + l.height,
    children: [{
      type: "elem",
      elem: l
    }, {
      type: "kern",
      size: 0.1
    }, {
      type: "elem",
      elem: i
    }]
  }), u.children[0].children[0].children[0].classes.push("svg-align")), a) {
    var h = S(["mord", n.isOver ? "mover" : "munder"], [u], e);
    n.isOver ? u = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: h
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: a
      }]
    }) : u = U({
      positionType: "bottom",
      positionData: h.depth + 0.2 + a.height + a.depth,
      children: [{
        type: "elem",
        elem: a
      }, {
        type: "kern",
        size: 0.2
      }, {
        type: "elem",
        elem: h
      }]
    });
  }
  return S(["mord", n.isOver ? "mover" : "munder"], [u], e);
}, Qi = (r, e) => {
  var t = at(r.label);
  return new A(r.isOver ? "mover" : "munder", [Y(r.base, e), t]);
};
E({
  type: "horizBrace",
  names: ["\\overbrace", "\\underbrace"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r;
    return {
      type: "horizBrace",
      mode: t.mode,
      label: a,
      isOver: /^\\over/.test(a),
      base: e[0]
    };
  },
  htmlBuilder: Za,
  mathmlBuilder: Qi
});
E({
  type: "href",
  names: ["\\href"],
  props: {
    numArgs: 2,
    argTypes: ["url", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[1], n = O(e[0], "url").url;
    return t.settings.isTrusted({
      command: "\\href",
      url: n
    }) ? {
      type: "href",
      mode: t.mode,
      href: n,
      body: ee(a)
    } : t.formatUnsupportedCmd("\\href");
  },
  htmlBuilder: (r, e) => {
    var t = se(r.body, e, !1);
    return fi(r.href, [], t, e);
  },
  mathmlBuilder: (r, e) => {
    var t = Ze(r.body, e);
    return t instanceof A || (t = new A("mrow", [t])), t.setAttribute("href", r.href), t;
  }
});
E({
  type: "href",
  names: ["\\url"],
  props: {
    numArgs: 1,
    argTypes: ["url"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = O(e[0], "url").url;
    if (!t.settings.isTrusted({
      command: "\\url",
      url: a
    }))
      return t.formatUnsupportedCmd("\\url");
    for (var n = [], i = 0; i < a.length; i++) {
      var l = a[i];
      l === "~" && (l = "\\textasciitilde"), n.push({
        type: "textord",
        mode: "text",
        text: l
      });
    }
    var u = {
      type: "text",
      mode: t.mode,
      font: "\\texttt",
      body: n
    };
    return {
      type: "href",
      mode: t.mode,
      href: a,
      body: ee(u)
    };
  }
});
E({
  type: "hbox",
  names: ["\\hbox"],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "hbox",
      mode: t.mode,
      body: ee(e[0])
    };
  },
  htmlBuilder(r, e) {
    var t = se(r.body, e, !1);
    return Ge(t);
  },
  mathmlBuilder(r, e) {
    return new A("mrow", ge(r.body, e));
  }
});
E({
  type: "html",
  names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"],
  props: {
    numArgs: 2,
    argTypes: ["raw", "original"],
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a,
      token: n
    } = r, i = O(e[0], "raw").string, l = e[1];
    t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode");
    var u, h = {};
    switch (a) {
      case "\\htmlClass":
        h.class = i, u = {
          command: "\\htmlClass",
          class: i
        };
        break;
      case "\\htmlId":
        h.id = i, u = {
          command: "\\htmlId",
          id: i
        };
        break;
      case "\\htmlStyle":
        h.style = i, u = {
          command: "\\htmlStyle",
          style: i
        };
        break;
      case "\\htmlData": {
        for (var f = i.split(","), v = 0; v < f.length; v++) {
          var b = f[v], y = b.indexOf("=");
          if (y < 0)
            throw new k("\\htmlData key/value '" + b + "' missing equals sign");
          var x = b.slice(0, y), T = b.slice(y + 1);
          h["data-" + x.trim()] = T;
        }
        u = {
          command: "\\htmlData",
          attributes: h
        };
        break;
      }
      default:
        throw new Error("Unrecognized html command");
    }
    return t.settings.isTrusted(u) ? {
      type: "html",
      mode: t.mode,
      attributes: h,
      body: ee(l)
    } : t.formatUnsupportedCmd(a);
  },
  htmlBuilder: (r, e) => {
    var t = se(r.body, e, !1), a = ["enclosing"];
    r.attributes.class && a.push(...r.attributes.class.trim().split(/\s+/));
    var n = S(a, t, e);
    for (var i in r.attributes)
      i !== "class" && r.attributes.hasOwnProperty(i) && n.setAttribute(i, r.attributes[i]);
    return n;
  },
  mathmlBuilder: (r, e) => Ze(r.body, e)
});
E({
  type: "htmlmathml",
  names: ["\\html@mathml"],
  props: {
    numArgs: 2,
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "htmlmathml",
      mode: t.mode,
      html: ee(e[0]),
      mathml: ee(e[1])
    };
  },
  htmlBuilder: (r, e) => {
    var t = se(r.html, e, !1);
    return Ge(t);
  },
  mathmlBuilder: (r, e) => Ze(r.mathml, e)
});
var zt = function(e) {
  if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return {
      number: +e,
      unit: "bp"
    };
  var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
  if (!t)
    throw new k("Invalid size: '" + e + "' in \\includegraphics");
  var a = {
    number: +(t[1] + t[2]),
    // sign + magnitude, cast to number
    unit: t[3]
  };
  if (!va(a))
    throw new k("Invalid unit: '" + a.unit + "' in \\includegraphics.");
  return a;
};
E({
  type: "includegraphics",
  names: ["\\includegraphics"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    argTypes: ["raw", "url"],
    allowedInText: !1
  },
  handler: (r, e, t) => {
    var {
      parser: a
    } = r, n = {
      number: 0,
      unit: "em"
    }, i = {
      number: 0.9,
      unit: "em"
    }, l = {
      number: 0,
      unit: "em"
    }, u = "";
    if (t[0])
      for (var h = O(t[0], "raw").string, f = h.split(","), v = 0; v < f.length; v++) {
        var b = f[v].split("=");
        if (b.length === 2) {
          var y = b[1].trim();
          switch (b[0].trim()) {
            case "alt":
              u = y;
              break;
            case "width":
              n = zt(y);
              break;
            case "height":
              i = zt(y);
              break;
            case "totalheight":
              l = zt(y);
              break;
            default:
              throw new k("Invalid key: '" + b[0] + "' in \\includegraphics.");
          }
        }
      }
    var x = O(e[0], "url").url;
    return u === "" && (u = x, u = u.replace(/^.*[\\/]/, ""), u = u.substring(0, u.lastIndexOf("."))), a.settings.isTrusted({
      command: "\\includegraphics",
      url: x
    }) ? {
      type: "includegraphics",
      mode: a.mode,
      alt: u,
      width: n,
      height: i,
      totalheight: l,
      src: x
    } : a.formatUnsupportedCmd("\\includegraphics");
  },
  htmlBuilder: (r, e) => {
    var t = J(r.height, e), a = 0;
    r.totalheight.number > 0 && (a = J(r.totalheight, e) - t);
    var n = 0;
    r.width.number > 0 && (n = J(r.width, e));
    var i = {
      height: M(t + a)
    };
    n > 0 && (i.width = M(n)), a > 0 && (i.verticalAlign = M(-a));
    var l = new oi(r.src, r.alt, i);
    return l.height = t, l.depth = a, l;
  },
  mathmlBuilder: (r, e) => {
    var t = new A("mglyph", []);
    t.setAttribute("alt", r.alt);
    var a = J(r.height, e), n = 0;
    if (r.totalheight.number > 0 && (n = J(r.totalheight, e) - a, t.setAttribute("valign", M(-n))), t.setAttribute("height", M(a + n)), r.width.number > 0) {
      var i = J(r.width, e);
      t.setAttribute("width", M(i));
    }
    return t.setAttribute("src", r.src), t;
  }
});
E({
  type: "kern",
  names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"],
  props: {
    numArgs: 1,
    argTypes: ["size"],
    primitive: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = O(e[0], "size");
    if (t.settings.strict) {
      var i = a[1] === "m", l = n.value.unit === "mu";
      i ? (l || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " supports only mu units, " + ("not " + n.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " works only in math mode")) : l && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " doesn't support mu units");
    }
    return {
      type: "kern",
      mode: t.mode,
      dimension: n.value
    };
  },
  htmlBuilder(r, e) {
    return Aa(r.dimension, e);
  },
  mathmlBuilder(r, e) {
    var t = J(r.dimension, e);
    return new za(t);
  }
});
E({
  type: "lap",
  names: ["\\mathllap", "\\mathrlap", "\\mathclap"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "lap",
      mode: t.mode,
      alignment: a.slice(5),
      body: n
    };
  },
  htmlBuilder: (r, e) => {
    var t;
    r.alignment === "clap" ? (t = S([], [H(r.body, e)]), t = S(["inner"], [t], e)) : t = S(["inner"], [H(r.body, e)]);
    var a = S(["fix"], []), n = S([r.alignment], [t, a], e), i = S(["strut"]);
    return i.style.height = M(n.height + n.depth), n.depth && (i.style.verticalAlign = M(-n.depth)), n.children.unshift(i), n = S(["thinbox"], [n], e), S(["mord", "vbox"], [n], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new A("mpadded", [Y(r.body, e)]);
    if (r.alignment !== "rlap") {
      var a = r.alignment === "llap" ? "-1" : "-0.5";
      t.setAttribute("lspace", a + "width");
    }
    return t.setAttribute("width", "0px"), t;
  }
});
E({
  type: "styling",
  names: ["\\(", "$"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    var {
      funcName: t,
      parser: a
    } = r, n = a.mode;
    a.switchMode("math");
    var i = t === "\\(" ? "\\)" : "$", l = a.parseExpression(!1, i);
    return a.expect(i), a.switchMode(n), {
      type: "styling",
      mode: a.mode,
      style: "text",
      body: l
    };
  }
});
E({
  type: "text",
  // Doesn't matter what this is.
  names: ["\\)", "\\]"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInMath: !1
  },
  handler(r, e) {
    throw new k("Mismatched " + r.funcName);
  }
});
var Wr = (r, e) => {
  switch (e.style.size) {
    case N.DISPLAY.size:
      return r.display;
    case N.TEXT.size:
      return r.text;
    case N.SCRIPT.size:
      return r.script;
    case N.SCRIPTSCRIPT.size:
      return r.scriptscript;
    default:
      return r.text;
  }
};
E({
  type: "mathchoice",
  names: ["\\mathchoice"],
  props: {
    numArgs: 4,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r;
    return {
      type: "mathchoice",
      mode: t.mode,
      display: ee(e[0]),
      text: ee(e[1]),
      script: ee(e[2]),
      scriptscript: ee(e[3])
    };
  },
  htmlBuilder: (r, e) => {
    var t = Wr(r, e), a = se(t, e, !1);
    return Ge(a);
  },
  mathmlBuilder: (r, e) => {
    var t = Wr(r, e);
    return Ze(t, e);
  }
});
var Ja = (r, e, t, a, n, i, l) => {
  r = S([], [r]);
  var u = t && Pe(t), h, f;
  if (e) {
    var v = H(e, a.havingStyle(n.sup()), a);
    f = {
      elem: v,
      kern: Math.max(a.fontMetrics().bigOpSpacing1, a.fontMetrics().bigOpSpacing3 - v.depth)
    };
  }
  if (t) {
    var b = H(t, a.havingStyle(n.sub()), a);
    h = {
      elem: b,
      kern: Math.max(a.fontMetrics().bigOpSpacing2, a.fontMetrics().bigOpSpacing4 - b.height)
    };
  }
  var y;
  if (f && h) {
    var x = a.fontMetrics().bigOpSpacing5 + h.elem.height + h.elem.depth + h.kern + r.depth + l;
    y = U({
      positionType: "bottom",
      positionData: x,
      children: [{
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: h.elem,
        marginLeft: M(-i)
      }, {
        type: "kern",
        size: h.kern
      }, {
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: f.kern
      }, {
        type: "elem",
        elem: f.elem,
        marginLeft: M(i)
      }, {
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }]
    });
  } else if (h) {
    var T = r.height - l;
    y = U({
      positionType: "top",
      positionData: T,
      children: [{
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }, {
        type: "elem",
        elem: h.elem,
        marginLeft: M(-i)
      }, {
        type: "kern",
        size: h.kern
      }, {
        type: "elem",
        elem: r
      }]
    });
  } else if (f) {
    var C = r.depth + l;
    y = U({
      positionType: "bottom",
      positionData: C,
      children: [{
        type: "elem",
        elem: r
      }, {
        type: "kern",
        size: f.kern
      }, {
        type: "elem",
        elem: f.elem,
        marginLeft: M(i)
      }, {
        type: "kern",
        size: a.fontMetrics().bigOpSpacing5
      }]
    });
  } else
    return r;
  var D = [y];
  if (h && i !== 0 && !u) {
    var R = S(["mspace"], [], a);
    R.style.marginRight = M(i), D.unshift(R);
  }
  return S(["mop", "op-limits"], D, a);
}, Qa = /* @__PURE__ */ new Set(["\\smallint"]), b0 = (r, e) => {
  var t, a, n = !1, i;
  r.type === "supsub" ? (t = r.sup, a = r.sub, i = O(r.base, "op"), n = !0) : i = O(r, "op");
  var l = e.style, u = !1;
  l.size === N.DISPLAY.size && i.symbol && !Qa.has(i.name) && (u = !0);
  var h;
  if (i.symbol) {
    var f = u ? "Size2-Regular" : "Size1-Regular", v = "";
    if ((i.name === "\\oiint" || i.name === "\\oiiint") && (v = i.name.slice(1), i.name = v === "oiint" ? "\\iint" : "\\iiint"), h = me(i.name, f, "math", e, ["mop", "op-symbol", u ? "large-op" : "small-op"]), v.length > 0) {
      var b = h.italic, y = Ta(v + "Size" + (u ? "2" : "1"), e);
      h = U({
        positionType: "individualShift",
        children: [{
          type: "elem",
          elem: h,
          shift: 0
        }, {
          type: "elem",
          elem: y,
          shift: u ? 0.08 : 0
        }]
      }), i.name = "\\" + v, h.classes.unshift("mop"), h.italic = b;
    }
  } else if (i.body) {
    var x = se(i.body, e, !0);
    x.length === 1 && x[0] instanceof Me ? (h = x[0], h.classes[0] = "mop") : h = S(["mop"], x, e);
  } else {
    for (var T = [], C = 1; C < i.name.length; C++)
      T.push(er(i.name[C], i.mode, e));
    h = S(["mop"], T, e);
  }
  var D = 0, R = 0;
  return (h instanceof Me || i.name === "\\oiint" || i.name === "\\oiiint") && !i.suppressBaseShift && (D = (h.height - h.depth) / 2 - e.fontMetrics().axisHeight, R = h.italic), n ? Ja(h, t, a, e, l, R, D) : (D && (h.style.position = "relative", h.style.top = M(D)), h);
}, E0 = (r, e) => {
  var t;
  if (r.symbol)
    t = new A("mo", [ke(r.name, r.mode)]), Qa.has(r.name) && t.setAttribute("largeop", "false");
  else if (r.body)
    t = new A("mo", ge(r.body, e));
  else {
    t = new A("mi", [new ae(r.name.slice(1))]);
    var a = new A("mo", [ke("\u2061", "text")]);
    r.parentIsSupSub ? t = new A("mrow", [t, a]) : t = Ea([t, a]);
  }
  return t;
}, es = {
  "\u220F": "\\prod",
  "\u2210": "\\coprod",
  "\u2211": "\\sum",
  "\u22C0": "\\bigwedge",
  "\u22C1": "\\bigvee",
  "\u22C2": "\\bigcap",
  "\u22C3": "\\bigcup",
  "\u2A00": "\\bigodot",
  "\u2A01": "\\bigoplus",
  "\u2A02": "\\bigotimes",
  "\u2A04": "\\biguplus",
  "\u2A06": "\\bigsqcup"
};
E({
  type: "op",
  names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "\u220F", "\u2210", "\u2211", "\u22C0", "\u22C1", "\u22C2", "\u22C3", "\u2A00", "\u2A01", "\u2A02", "\u2A04", "\u2A06"],
  props: {
    numArgs: 0
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = a;
    return n.length === 1 && (n = es[n]), {
      type: "op",
      mode: t.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !0,
      name: n
    };
  },
  htmlBuilder: b0,
  mathmlBuilder: E0
});
E({
  type: "op",
  names: ["\\mathop"],
  props: {
    numArgs: 1,
    primitive: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "op",
      mode: t.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      body: ee(a)
    };
  },
  htmlBuilder: b0,
  mathmlBuilder: E0
});
var ts = {
  "\u222B": "\\int",
  "\u222C": "\\iint",
  "\u222D": "\\iiint",
  "\u222E": "\\oint",
  "\u222F": "\\oiint",
  "\u2230": "\\oiiint"
};
E({
  type: "op",
  names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: b0,
  mathmlBuilder: E0
});
E({
  type: "op",
  names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"],
  props: {
    numArgs: 0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r;
    return {
      type: "op",
      mode: e.mode,
      limits: !0,
      parentIsSupSub: !1,
      symbol: !1,
      name: t
    };
  },
  htmlBuilder: b0,
  mathmlBuilder: E0
});
E({
  type: "op",
  names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "\u222B", "\u222C", "\u222D", "\u222E", "\u222F", "\u2230"],
  props: {
    numArgs: 0,
    allowedInArgument: !0
  },
  handler(r) {
    var {
      parser: e,
      funcName: t
    } = r, a = t;
    return a.length === 1 && (a = ts[a]), {
      type: "op",
      mode: e.mode,
      limits: !1,
      parentIsSupSub: !1,
      symbol: !0,
      name: a
    };
  },
  htmlBuilder: b0,
  mathmlBuilder: E0
});
var en = (r, e) => {
  var t, a, n = !1, i;
  r.type === "supsub" ? (t = r.sup, a = r.sub, i = O(r.base, "operatorname"), n = !0) : i = O(r, "operatorname");
  var l;
  if (i.body.length > 0) {
    for (var u = i.body.map((b) => {
      var y = b.text;
      return typeof y == "string" ? {
        type: "textord",
        mode: b.mode,
        text: y
      } : b;
    }), h = se(u, e.withFont("mathrm"), !0), f = 0; f < h.length; f++) {
      var v = h[f];
      v instanceof Me && (v.text = v.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    l = S(["mop"], h, e);
  } else
    l = S(["mop"], [], e);
  return n ? Ja(l, t, a, e, e.style, 0, 0) : l;
}, rs = (r, e) => {
  for (var t = ge(r.body, e.withFont("mathrm")), a = !0, n = 0; n < t.length; n++) {
    var i = t[n];
    if (!(i instanceof za)) if (i instanceof A)
      switch (i.type) {
        case "mi":
        case "mn":
        case "ms":
        case "mspace":
        case "mtext":
          break;
        // Do nothing yet.
        case "mo": {
          var l = i.children[0];
          i.children.length === 1 && l instanceof ae ? l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : a = !1;
          break;
        }
        default:
          a = !1;
      }
    else
      a = !1;
  }
  if (a) {
    var u = t.map((v) => v.toText()).join("");
    t = [new ae(u)];
  }
  var h = new A("mi", t);
  h.setAttribute("mathvariant", "normal");
  var f = new A("mo", [ke("\u2061", "text")]);
  return r.parentIsSupSub ? new A("mrow", [h, f]) : Ea([h, f]);
};
E({
  type: "operatorname",
  names: ["\\operatorname@", "\\operatornamewithlimits"],
  props: {
    numArgs: 1
  },
  handler: (r, e) => {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "operatorname",
      mode: t.mode,
      body: ee(n),
      alwaysHandleSupSub: a === "\\operatornamewithlimits",
      limits: !1,
      parentIsSupSub: !1
    };
  },
  htmlBuilder: en,
  mathmlBuilder: rs
});
m("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
a0({
  type: "ordgroup",
  htmlBuilder(r, e) {
    return r.semisimple ? Ge(se(r.body, e, !1)) : S(["mord"], se(r.body, e, !0), e);
  },
  mathmlBuilder(r, e) {
    return Ze(r.body, e, !0);
  }
});
E({
  type: "overline",
  names: ["\\overline"],
  props: {
    numArgs: 1
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "overline",
      mode: t.mode,
      body: a
    };
  },
  htmlBuilder(r, e) {
    var t = H(r.body, e.havingCrampedStyle()), a = f0("overline-line", e), n = e.fontMetrics().defaultRuleThickness, i = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }, {
        type: "kern",
        size: 3 * n
      }, {
        type: "elem",
        elem: a
      }, {
        type: "kern",
        size: n
      }]
    });
    return S(["mord", "overline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new A("mo", [new ae("\u203E")]);
    t.setAttribute("stretchy", "true");
    var a = new A("mover", [Y(r.body, e), t]);
    return a.setAttribute("accent", "true"), a;
  }
});
E({
  type: "phantom",
  names: ["\\phantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "phantom",
      mode: t.mode,
      body: ee(a)
    };
  },
  htmlBuilder: (r, e) => {
    var t = se(r.body, e.withPhantom(), !1);
    return Ge(t);
  },
  mathmlBuilder: (r, e) => {
    var t = ge(r.body, e);
    return new A("mphantom", t);
  }
});
E({
  type: "hphantom",
  names: ["\\hphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "hphantom",
      mode: t.mode,
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = S([], [H(r.body, e.withPhantom())]);
    if (t.height = 0, t.depth = 0, t.children)
      for (var a = 0; a < t.children.length; a++)
        t.children[a].height = 0, t.children[a].depth = 0;
    return t = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    }), S(["mord"], [t], e);
  },
  mathmlBuilder: (r, e) => {
    var t = ge(ee(r.body), e), a = new A("mphantom", t), n = new A("mpadded", [a]);
    return n.setAttribute("height", "0px"), n.setAttribute("depth", "0px"), n;
  }
});
E({
  type: "vphantom",
  names: ["\\vphantom"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      parser: t
    } = r, a = e[0];
    return {
      type: "vphantom",
      mode: t.mode,
      body: a
    };
  },
  htmlBuilder: (r, e) => {
    var t = S(["inner"], [H(r.body, e.withPhantom())]), a = S(["fix"], []);
    return S(["mord", "rlap"], [t, a], e);
  },
  mathmlBuilder: (r, e) => {
    var t = ge(ee(r.body), e), a = new A("mphantom", t), n = new A("mpadded", [a]);
    return n.setAttribute("width", "0px"), n;
  }
});
E({
  type: "raisebox",
  names: ["\\raisebox"],
  props: {
    numArgs: 2,
    argTypes: ["size", "hbox"],
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r, a = O(e[0], "size").value, n = e[1];
    return {
      type: "raisebox",
      mode: t.mode,
      dy: a,
      body: n
    };
  },
  htmlBuilder(r, e) {
    var t = H(r.body, e), a = J(r.dy, e);
    return U({
      positionType: "shift",
      positionData: -a,
      children: [{
        type: "elem",
        elem: t
      }]
    });
  },
  mathmlBuilder(r, e) {
    var t = new A("mpadded", [Y(r.body, e)]), a = r.dy.number + r.dy.unit;
    return t.setAttribute("voffset", a), t;
  }
});
E({
  type: "internal",
  names: ["\\relax"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    allowedInArgument: !0
  },
  handler(r) {
    var {
      parser: e
    } = r;
    return {
      type: "internal",
      mode: e.mode
    };
  }
});
E({
  type: "rule",
  names: ["\\rule"],
  props: {
    numArgs: 2,
    numOptionalArgs: 1,
    allowedInText: !0,
    allowedInMath: !0,
    argTypes: ["size", "size", "size"]
  },
  handler(r, e, t) {
    var {
      parser: a
    } = r, n = t[0], i = O(e[0], "size"), l = O(e[1], "size");
    return {
      type: "rule",
      mode: a.mode,
      shift: n && O(n, "size").value,
      width: i.value,
      height: l.value
    };
  },
  htmlBuilder(r, e) {
    var t = S(["mord", "rule"], [], e), a = J(r.width, e), n = J(r.height, e), i = r.shift ? J(r.shift, e) : 0;
    return t.style.borderRightWidth = M(a), t.style.borderTopWidth = M(n), t.style.bottom = M(i), t.width = a, t.height = n + i, t.depth = -i, t.maxFontSize = n * 1.125 * e.sizeMultiplier, t;
  },
  mathmlBuilder(r, e) {
    var t = J(r.width, e), a = J(r.height, e), n = r.shift ? J(r.shift, e) : 0, i = e.color && e.getColor() || "black", l = new A("mspace");
    l.setAttribute("mathbackground", i), l.setAttribute("width", M(t)), l.setAttribute("height", M(a));
    var u = new A("mpadded", [l]);
    return n >= 0 ? u.setAttribute("height", M(n)) : (u.setAttribute("height", M(n)), u.setAttribute("depth", M(-n))), u.setAttribute("voffset", M(n)), u;
  }
});
function tn(r, e, t) {
  for (var a = se(r, e, !1), n = e.sizeMultiplier / t.sizeMultiplier, i = 0; i < a.length; i++) {
    var l = a[i].classes.indexOf("sizing");
    l < 0 ? Array.prototype.push.apply(a[i].classes, e.sizingClasses(t)) : a[i].classes[l + 1] === "reset-size" + e.size && (a[i].classes[l + 1] = "reset-size" + t.size), a[i].height *= n, a[i].depth *= n;
  }
  return Ge(a);
}
var Yr = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], as = (r, e) => {
  var t = e.havingSize(r.size);
  return tn(r.body, t, e);
};
E({
  type: "sizing",
  names: Yr,
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler: (r, e) => {
    var {
      breakOnTokenText: t,
      funcName: a,
      parser: n
    } = r, i = n.parseExpression(!1, t);
    return {
      type: "sizing",
      mode: n.mode,
      // Figure out what size to use based on the list of functions above
      size: Yr.indexOf(a) + 1,
      body: i
    };
  },
  htmlBuilder: as,
  mathmlBuilder: (r, e) => {
    var t = e.havingSize(r.size), a = ge(r.body, t), n = new A("mstyle", a);
    return n.setAttribute("mathsize", M(t.sizeMultiplier)), n;
  }
});
E({
  type: "smash",
  names: ["\\smash"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1,
    allowedInText: !0
  },
  handler: (r, e, t) => {
    var {
      parser: a
    } = r, n = !1, i = !1, l = t[0] && O(t[0], "ordgroup");
    if (l)
      for (var u = "", h = 0; h < l.body.length; ++h) {
        var f = l.body[h];
        if (u = f.text, u === "t")
          n = !0;
        else if (u === "b")
          i = !0;
        else {
          n = !1, i = !1;
          break;
        }
      }
    else
      n = !0, i = !0;
    var v = e[0];
    return {
      type: "smash",
      mode: a.mode,
      body: v,
      smashHeight: n,
      smashDepth: i
    };
  },
  htmlBuilder: (r, e) => {
    var t = S([], [H(r.body, e)]);
    if (!r.smashHeight && !r.smashDepth)
      return t;
    if (r.smashHeight && (t.height = 0, t.children))
      for (var a = 0; a < t.children.length; a++)
        t.children[a].height = 0;
    if (r.smashDepth && (t.depth = 0, t.children))
      for (var n = 0; n < t.children.length; n++)
        t.children[n].depth = 0;
    var i = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t
      }]
    });
    return S(["mord"], [i], e);
  },
  mathmlBuilder: (r, e) => {
    var t = new A("mpadded", [Y(r.body, e)]);
    return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t;
  }
});
E({
  type: "sqrt",
  names: ["\\sqrt"],
  props: {
    numArgs: 1,
    numOptionalArgs: 1
  },
  handler(r, e, t) {
    var {
      parser: a
    } = r, n = t[0], i = e[0];
    return {
      type: "sqrt",
      mode: a.mode,
      body: i,
      index: n
    };
  },
  htmlBuilder(r, e) {
    var t = H(r.body, e.havingCrampedStyle());
    t.height === 0 && (t.height = e.fontMetrics().xHeight), t = v0(t, e);
    var a = e.fontMetrics(), n = a.defaultRuleThickness, i = n;
    e.style.id < N.TEXT.id && (i = e.fontMetrics().xHeight);
    var l = n + i / 4, u = t.height + t.depth + l + n, {
      span: h,
      ruleWidth: f,
      advanceWidth: v
    } = Vi(u, e), b = h.height - f;
    b > t.height + t.depth + l && (l = (l + b - t.height - t.depth) / 2);
    var y = h.height - t.height - l - f;
    t.style.paddingLeft = M(v);
    var x = U({
      positionType: "firstBaseline",
      children: [{
        type: "elem",
        elem: t,
        wrapperClasses: ["svg-align"]
      }, {
        type: "kern",
        size: -(t.height + y)
      }, {
        type: "elem",
        elem: h
      }, {
        type: "kern",
        size: f
      }]
    });
    if (r.index) {
      var T = e.havingStyle(N.SCRIPTSCRIPT), C = H(r.index, T, e), D = 0.6 * (x.height - x.depth), R = U({
        positionType: "shift",
        positionData: -D,
        children: [{
          type: "elem",
          elem: C
        }]
      }), B = S(["root"], [R]);
      return S(["mord", "sqrt"], [B, x], e);
    } else
      return S(["mord", "sqrt"], [x], e);
  },
  mathmlBuilder(r, e) {
    var {
      body: t,
      index: a
    } = r;
    return a ? new A("mroot", [Y(t, e), Y(a, e)]) : new A("msqrt", [Y(t, e)]);
  }
});
var Kr = {
  display: N.DISPLAY,
  text: N.TEXT,
  script: N.SCRIPT,
  scriptscript: N.SCRIPTSCRIPT
};
E({
  type: "styling",
  names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"],
  props: {
    numArgs: 0,
    allowedInText: !0,
    primitive: !0
  },
  handler(r, e) {
    var {
      breakOnTokenText: t,
      funcName: a,
      parser: n
    } = r, i = n.parseExpression(!0, t), l = a.slice(1, a.length - 5);
    return {
      type: "styling",
      mode: n.mode,
      // Figure out what style to use by pulling out the style from
      // the function name
      style: l,
      body: i
    };
  },
  htmlBuilder(r, e) {
    var t = Kr[r.style], a = e.havingStyle(t).withFont("");
    return tn(r.body, a, e);
  },
  mathmlBuilder(r, e) {
    var t = Kr[r.style], a = e.havingStyle(t), n = ge(r.body, a), i = new A("mstyle", n), l = {
      display: ["0", "true"],
      text: ["0", "false"],
      script: ["1", "false"],
      scriptscript: ["2", "false"]
    }, u = l[r.style];
    return i.setAttribute("scriptlevel", u[0]), i.setAttribute("displaystyle", u[1]), i;
  }
});
var ns = function(e, t) {
  var a = e.base;
  if (a)
    if (a.type === "op") {
      var n = a.limits && (t.style.size === N.DISPLAY.size || a.alwaysHandleSupSub);
      return n ? b0 : null;
    } else if (a.type === "operatorname") {
      var i = a.alwaysHandleSupSub && (t.style.size === N.DISPLAY.size || a.limits);
      return i ? en : null;
    } else {
      if (a.type === "accent")
        return Pe(a.base) ? ir : null;
      if (a.type === "horizBrace") {
        var l = !e.sub;
        return l === a.isOver ? Za : null;
      } else
        return null;
    }
  else return null;
};
a0({
  type: "supsub",
  htmlBuilder(r, e) {
    var t = ns(r, e);
    if (t)
      return t(r, e);
    var {
      base: a,
      sup: n,
      sub: i
    } = r, l = H(a, e), u, h, f = e.fontMetrics(), v = 0, b = 0, y = a && Pe(a);
    if (n) {
      var x = e.havingStyle(e.style.sup());
      u = H(n, x, e), y || (v = l.height - x.fontMetrics().supDrop * x.sizeMultiplier / e.sizeMultiplier);
    }
    if (i) {
      var T = e.havingStyle(e.style.sub());
      h = H(i, T, e), y || (b = l.depth + T.fontMetrics().subDrop * T.sizeMultiplier / e.sizeMultiplier);
    }
    var C;
    e.style === N.DISPLAY ? C = f.sup1 : e.style.cramped ? C = f.sup3 : C = f.sup2;
    var D = e.sizeMultiplier, R = M(0.5 / f.ptPerEm / D), B = null;
    if (h) {
      var q = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
      (l instanceof Me || q) && (B = M(-l.italic));
    }
    var V;
    if (u && h) {
      v = Math.max(v, C, u.depth + 0.25 * f.xHeight), b = Math.max(b, f.sub2);
      var L = f.defaultRuleThickness, $ = 4 * L;
      if (v - u.depth - (h.height - b) < $) {
        b = $ - (v - u.depth) + h.height;
        var G = 0.8 * f.xHeight - (v - u.depth);
        G > 0 && (v += G, b -= G);
      }
      var j = [{
        type: "elem",
        elem: h,
        shift: b,
        marginRight: R,
        marginLeft: B
      }, {
        type: "elem",
        elem: u,
        shift: -v,
        marginRight: R
      }];
      V = U({
        positionType: "individualShift",
        children: j
      });
    } else if (h) {
      b = Math.max(b, f.sub1, h.height - 0.8 * f.xHeight);
      var X = [{
        type: "elem",
        elem: h,
        marginLeft: B,
        marginRight: R
      }];
      V = U({
        positionType: "shift",
        positionData: b,
        children: X
      });
    } else if (u)
      v = Math.max(v, C, u.depth + 0.25 * f.xHeight), V = U({
        positionType: "shift",
        positionData: -v,
        children: [{
          type: "elem",
          elem: u,
          marginRight: R
        }]
      });
    else
      throw new Error("supsub must have either sup or sub.");
    var Be = Ht(l, "right") || "mord";
    return S([Be], [l, S(["msupsub"], [V])], e);
  },
  mathmlBuilder(r, e) {
    var t = !1, a, n;
    r.base && r.base.type === "horizBrace" && (n = !!r.sup, n === r.base.isOver && (t = !0, a = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = !0);
    var i = [Y(r.base, e)];
    r.sub && i.push(Y(r.sub, e)), r.sup && i.push(Y(r.sup, e));
    var l;
    if (t)
      l = a ? "mover" : "munder";
    else if (r.sub)
      if (r.sup) {
        var f = r.base;
        f && f.type === "op" && f.limits && e.style === N.DISPLAY || f && f.type === "operatorname" && f.alwaysHandleSupSub && (e.style === N.DISPLAY || f.limits) ? l = "munderover" : l = "msubsup";
      } else {
        var h = r.base;
        h && h.type === "op" && h.limits && (e.style === N.DISPLAY || h.alwaysHandleSupSub) || h && h.type === "operatorname" && h.alwaysHandleSupSub && (h.limits || e.style === N.DISPLAY) ? l = "munder" : l = "msub";
      }
    else {
      var u = r.base;
      u && u.type === "op" && u.limits && (e.style === N.DISPLAY || u.alwaysHandleSupSub) || u && u.type === "operatorname" && u.alwaysHandleSupSub && (u.limits || e.style === N.DISPLAY) ? l = "mover" : l = "msup";
    }
    return new A(l, i);
  }
});
a0({
  type: "atom",
  htmlBuilder(r, e) {
    return er(r.text, r.mode, e, ["m" + r.family]);
  },
  mathmlBuilder(r, e) {
    var t = new A("mo", [ke(r.text, r.mode)]);
    if (r.family === "bin") {
      var a = ar(r, e);
      a === "bold-italic" && t.setAttribute("mathvariant", a);
    } else r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false");
    return t;
  }
});
var rn = {
  mi: "italic",
  mn: "normal",
  mtext: "normal"
};
a0({
  type: "mathord",
  htmlBuilder(r, e) {
    return rt(r, e, "mathord");
  },
  mathmlBuilder(r, e) {
    var t = new A("mi", [ke(r.text, r.mode, e)]), a = ar(r, e) || "italic";
    return a !== rn[t.type] && t.setAttribute("mathvariant", a), t;
  }
});
a0({
  type: "textord",
  htmlBuilder(r, e) {
    return rt(r, e, "textord");
  },
  mathmlBuilder(r, e) {
    var t = ke(r.text, r.mode, e), a = ar(r, e) || "normal", n;
    return r.mode === "text" ? n = new A("mtext", [t]) : /[0-9]/.test(r.text) ? n = new A("mn", [t]) : r.text === "\\prime" ? n = new A("mo", [t]) : n = new A("mi", [t]), a !== rn[n.type] && n.setAttribute("mathvariant", a), n;
  }
});
var Dt = {
  "\\nobreak": "nobreak",
  "\\allowbreak": "allowbreak"
}, Rt = {
  " ": {},
  "\\ ": {},
  "~": {
    className: "nobreak"
  },
  "\\space": {},
  "\\nobreakspace": {
    className: "nobreak"
  }
};
a0({
  type: "spacing",
  htmlBuilder(r, e) {
    if (Rt.hasOwnProperty(r.text)) {
      var t = Rt[r.text].className || "";
      if (r.mode === "text") {
        var a = rt(r, e, "textord");
        return a.classes.push(t), a;
      } else
        return S(["mspace", t], [er(r.text, r.mode, e)], e);
    } else {
      if (Dt.hasOwnProperty(r.text))
        return S(["mspace", Dt[r.text]], [], e);
      throw new k('Unknown type of space "' + r.text + '"');
    }
  },
  mathmlBuilder(r, e) {
    var t;
    if (Rt.hasOwnProperty(r.text))
      t = new A("mtext", [new ae("\xA0")]);
    else {
      if (Dt.hasOwnProperty(r.text))
        return new A("mspace");
      throw new k('Unknown type of space "' + r.text + '"');
    }
    return t;
  }
});
var _r = () => {
  var r = new A("mtd", []);
  return r.setAttribute("width", "50%"), r;
};
a0({
  type: "tag",
  mathmlBuilder(r, e) {
    var t = new A("mtable", [new A("mtr", [_r(), new A("mtd", [Ze(r.body, e)]), _r(), new A("mtd", [Ze(r.tag, e)])])]);
    return t.setAttribute("width", "100%"), t;
  }
});
var jr = {
  "\\text": void 0,
  "\\textrm": "textrm",
  "\\textsf": "textsf",
  "\\texttt": "texttt",
  "\\textnormal": "textrm"
}, Zr = {
  "\\textbf": "textbf",
  "\\textmd": "textmd"
}, is = {
  "\\textit": "textit",
  "\\textup": "textup"
}, Jr = (r, e) => {
  var t = r.font;
  if (t) {
    if (jr[t])
      return e.withTextFontFamily(jr[t]);
    if (Zr[t])
      return e.withTextFontWeight(Zr[t]);
    if (t === "\\emph")
      return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
  } else return e;
  return e.withTextFontShape(is[t]);
};
E({
  type: "text",
  names: [
    // Font families
    "\\text",
    "\\textrm",
    "\\textsf",
    "\\texttt",
    "\\textnormal",
    // Font weights
    "\\textbf",
    "\\textmd",
    // Font Shapes
    "\\textit",
    "\\textup",
    "\\emph"
  ],
  props: {
    numArgs: 1,
    argTypes: ["text"],
    allowedInArgument: !0,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t,
      funcName: a
    } = r, n = e[0];
    return {
      type: "text",
      mode: t.mode,
      body: ee(n),
      font: a
    };
  },
  htmlBuilder(r, e) {
    var t = Jr(r, e), a = se(r.body, t, !0);
    return S(["mord", "text"], a, t);
  },
  mathmlBuilder(r, e) {
    var t = Jr(r, e);
    return Ze(r.body, t);
  }
});
E({
  type: "underline",
  names: ["\\underline"],
  props: {
    numArgs: 1,
    allowedInText: !0
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "underline",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = H(r.body, e), a = f0("underline-line", e), n = e.fontMetrics().defaultRuleThickness, i = U({
      positionType: "top",
      positionData: t.height,
      children: [{
        type: "kern",
        size: n
      }, {
        type: "elem",
        elem: a
      }, {
        type: "kern",
        size: 3 * n
      }, {
        type: "elem",
        elem: t
      }]
    });
    return S(["mord", "underline"], [i], e);
  },
  mathmlBuilder(r, e) {
    var t = new A("mo", [new ae("\u203E")]);
    t.setAttribute("stretchy", "true");
    var a = new A("munder", [Y(r.body, e), t]);
    return a.setAttribute("accentunder", "true"), a;
  }
});
E({
  type: "vcenter",
  names: ["\\vcenter"],
  props: {
    numArgs: 1,
    argTypes: ["original"],
    // In LaTeX, \vcenter can act only on a box.
    allowedInText: !1
  },
  handler(r, e) {
    var {
      parser: t
    } = r;
    return {
      type: "vcenter",
      mode: t.mode,
      body: e[0]
    };
  },
  htmlBuilder(r, e) {
    var t = H(r.body, e), a = e.fontMetrics().axisHeight, n = 0.5 * (t.height - a - (t.depth + a));
    return U({
      positionType: "shift",
      positionData: n,
      children: [{
        type: "elem",
        elem: t
      }]
    });
  },
  mathmlBuilder(r, e) {
    return new A("mpadded", [Y(r.body, e)], ["vcenter"]);
  }
});
E({
  type: "verb",
  names: ["\\verb"],
  props: {
    numArgs: 0,
    allowedInText: !0
  },
  handler(r, e, t) {
    throw new k("\\verb ended by end of line instead of matching delimiter");
  },
  htmlBuilder(r, e) {
    for (var t = Qr(r), a = [], n = e.havingStyle(e.style.text()), i = 0; i < t.length; i++) {
      var l = t[i];
      l === "~" && (l = "\\textasciitilde"), a.push(me(l, "Typewriter-Regular", r.mode, n, ["mord", "texttt"]));
    }
    return S(["mord", "text"].concat(n.sizingClasses(e)), Sa(a), n);
  },
  mathmlBuilder(r, e) {
    var t = new ae(Qr(r)), a = new A("mtext", [t]);
    return a.setAttribute("mathvariant", "monospace"), a;
  }
});
var Qr = (r) => r.body.replace(/ /g, r.star ? "\u2423" : "\xA0"), Ye = Ma, an = `[ \r
	]`, ss = "\\\\[a-zA-Z@]+", os = "\\\\[^\uD800-\uDFFF]", ls = "(" + ss + ")" + an + "*", us = `\\\\(
|[ \r	]+
?)[ \r	]*`, $t = "[\u0300-\u036F]", cs = new RegExp($t + "+$"), hs = "(" + an + "+)|" + // whitespace
(us + "|") + // \whitespace
"([!-\\[\\]-\u2027\u202A-\uD7FF\uF900-\uFFFF]" + // single codepoint
($t + "*") + // ...plus accents
"|[\uD800-\uDBFF][\uDC00-\uDFFF]" + // surrogate pair
($t + "*") + // ...plus accents
"|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + // \verb unstarred
("|" + ls) + // \macroName + spaces
("|" + os + ")");
class ea {
  // Category codes. The lexer only supports comment characters (14) for now.
  // MacroExpander additionally distinguishes active (13).
  constructor(e, t) {
    this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = e, this.settings = t, this.tokenRegex = new RegExp(hs, "g"), this.catcodes = {
      "%": 14,
      // comment character
      "~": 13
      // active character
    };
  }
  setCatcode(e, t) {
    this.catcodes[e] = t;
  }
  /**
   * This function lexes a single token.
   */
  lex() {
    var e = this.input, t = this.tokenRegex.lastIndex;
    if (t === e.length)
      return new be("EOF", new ve(this, t, t));
    var a = this.tokenRegex.exec(e);
    if (a === null || a.index !== t)
      throw new k("Unexpected character: '" + e[t] + "'", new be(e[t], new ve(this, t, t + 1)));
    var n = a[6] || a[3] || (a[2] ? "\\ " : " ");
    if (this.catcodes[n] === 14) {
      var i = e.indexOf(`
`, this.tokenRegex.lastIndex);
      return i === -1 ? (this.tokenRegex.lastIndex = e.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = i + 1, this.lex();
    }
    return new be(n, new ve(this, t, this.tokenRegex.lastIndex));
  }
}
class ms {
  /**
   * Both arguments are optional.  The first argument is an object of
   * built-in mappings which never change.  The second argument is an object
   * of initial (global-level) mappings, which will constantly change
   * according to any global/top-level `set`s done.
   */
  constructor(e, t) {
    e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = t, this.builtins = e, this.undefStack = [];
  }
  /**
   * Start a new nested group, affecting future local `set`s.
   */
  beginGroup() {
    this.undefStack.push({});
  }
  /**
   * End current nested group, restoring values before the group began.
   */
  endGroup() {
    if (this.undefStack.length === 0)
      throw new k("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
    var e = this.undefStack.pop();
    for (var t in e)
      e.hasOwnProperty(t) && (e[t] == null ? delete this.current[t] : this.current[t] = e[t]);
  }
  /**
   * Ends all currently nested groups (if any), restoring values before the
   * groups began.  Useful in case of an error in the middle of parsing.
   */
  endGroups() {
    for (; this.undefStack.length > 0; )
      this.endGroup();
  }
  /**
   * Detect whether `name` has a definition.  Equivalent to
   * `get(name) != null`.
   */
  has(e) {
    return this.current.hasOwnProperty(e) || this.builtins.hasOwnProperty(e);
  }
  /**
   * Get the current value of a name, or `undefined` if there is no value.
   *
   * Note: Do not use `if (namespace.get(...))` to detect whether a macro
   * is defined, as the definition may be the empty string which evaluates
   * to `false` in JavaScript.  Use `if (namespace.get(...) != null)` or
   * `if (namespace.has(...))`.
   */
  get(e) {
    return this.current.hasOwnProperty(e) ? this.current[e] : this.builtins[e];
  }
  /**
   * Set the current value of a name, and optionally set it globally too.
   * Local set() sets the current value and (when appropriate) adds an undo
   * operation to the undo stack.  Global set() may change the undo
   * operation at every level, so takes time linear in their number.
   * A value of undefined means to delete existing definitions.
   */
  set(e, t, a) {
    if (a === void 0 && (a = !1), a) {
      for (var n = 0; n < this.undefStack.length; n++)
        delete this.undefStack[n][e];
      this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
    } else {
      var i = this.undefStack[this.undefStack.length - 1];
      i && !i.hasOwnProperty(e) && (i[e] = this.current[e]);
    }
    t == null ? delete this.current[e] : this.current[e] = t;
  }
}
var ds = Wa;
m("\\noexpand", function(r) {
  var e = r.popToken();
  return r.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), {
    tokens: [e],
    numArgs: 0
  };
});
m("\\expandafter", function(r) {
  var e = r.popToken();
  return r.expandOnce(!0), {
    tokens: [e],
    numArgs: 0
  };
});
m("\\@firstoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[0],
    numArgs: 0
  };
});
m("\\@secondoftwo", function(r) {
  var e = r.consumeArgs(2);
  return {
    tokens: e[1],
    numArgs: 0
  };
});
m("\\@ifnextchar", function(r) {
  var e = r.consumeArgs(3);
  r.consumeSpaces();
  var t = r.future();
  return e[0].length === 1 && e[0][0].text === t.text ? {
    tokens: e[1],
    numArgs: 0
  } : {
    tokens: e[2],
    numArgs: 0
  };
});
m("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
m("\\TextOrMath", function(r) {
  var e = r.consumeArgs(2);
  return r.mode === "text" ? {
    tokens: e[0],
    numArgs: 0
  } : {
    tokens: e[1],
    numArgs: 0
  };
});
var ta = {
  0: 0,
  1: 1,
  2: 2,
  3: 3,
  4: 4,
  5: 5,
  6: 6,
  7: 7,
  8: 8,
  9: 9,
  a: 10,
  A: 10,
  b: 11,
  B: 11,
  c: 12,
  C: 12,
  d: 13,
  D: 13,
  e: 14,
  E: 14,
  f: 15,
  F: 15
};
m("\\char", function(r) {
  var e = r.popToken(), t, a = "";
  if (e.text === "'")
    t = 8, e = r.popToken();
  else if (e.text === '"')
    t = 16, e = r.popToken();
  else if (e.text === "`")
    if (e = r.popToken(), e.text[0] === "\\")
      a = e.text.charCodeAt(1);
    else {
      if (e.text === "EOF")
        throw new k("\\char` missing argument");
      a = e.text.charCodeAt(0);
    }
  else
    t = 10;
  if (t) {
    if (a = ta[e.text], a == null || a >= t)
      throw new k("Invalid base-" + t + " digit " + e.text);
    for (var n; (n = ta[r.future().text]) != null && n < t; )
      a *= t, a += n, r.popToken();
  }
  return "\\@char{" + a + "}";
});
var hr = (r, e, t, a) => {
  var n = r.consumeArg().tokens;
  if (n.length !== 1)
    throw new k("\\newcommand's first argument must be a macro name");
  var i = n[0].text, l = r.isDefined(i);
  if (l && !e)
    throw new k("\\newcommand{" + i + "} attempting to redefine " + (i + "; use \\renewcommand"));
  if (!l && !t)
    throw new k("\\renewcommand{" + i + "} when command " + i + " does not yet exist; use \\newcommand");
  var u = 0;
  if (n = r.consumeArg().tokens, n.length === 1 && n[0].text === "[") {
    for (var h = "", f = r.expandNextToken(); f.text !== "]" && f.text !== "EOF"; )
      h += f.text, f = r.expandNextToken();
    if (!h.match(/^\s*[0-9]+\s*$/))
      throw new k("Invalid number of arguments: " + h);
    u = parseInt(h), n = r.consumeArg().tokens;
  }
  return l && a || r.macros.set(i, {
    tokens: n,
    numArgs: u
  }), "";
};
m("\\newcommand", (r) => hr(r, !1, !0, !1));
m("\\renewcommand", (r) => hr(r, !0, !1, !1));
m("\\providecommand", (r) => hr(r, !0, !0, !0));
m("\\message", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.log(e.reverse().map((t) => t.text).join("")), "";
});
m("\\errmessage", (r) => {
  var e = r.consumeArgs(1)[0];
  return console.error(e.reverse().map((t) => t.text).join("")), "";
});
m("\\show", (r) => {
  var e = r.popToken(), t = e.text;
  return console.log(e, r.macros.get(t), Ye[t], K.math[t], K.text[t]), "";
});
m("\\bgroup", "{");
m("\\egroup", "}");
m("~", "\\nobreakspace");
m("\\lq", "`");
m("\\rq", "'");
m("\\aa", "\\r a");
m("\\AA", "\\r A");
m("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`\xA9}");
m("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
m("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`\xAE}");
m("\u212C", "\\mathscr{B}");
m("\u2130", "\\mathscr{E}");
m("\u2131", "\\mathscr{F}");
m("\u210B", "\\mathscr{H}");
m("\u2110", "\\mathscr{I}");
m("\u2112", "\\mathscr{L}");
m("\u2133", "\\mathscr{M}");
m("\u211B", "\\mathscr{R}");
m("\u212D", "\\mathfrak{C}");
m("\u210C", "\\mathfrak{H}");
m("\u2128", "\\mathfrak{Z}");
m("\\Bbbk", "\\Bbb{k}");
m("\xB7", "\\cdotp");
m("\\llap", "\\mathllap{\\textrm{#1}}");
m("\\rlap", "\\mathrlap{\\textrm{#1}}");
m("\\clap", "\\mathclap{\\textrm{#1}}");
m("\\mathstrut", "\\vphantom{(}");
m("\\underbar", "\\underline{\\text{#1}}");
m("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char"338}');
m("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`\u2260}}");
m("\\ne", "\\neq");
m("\u2260", "\\neq");
m("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`\u2209}}");
m("\u2209", "\\notin");
m("\u2258", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`\u2258}}");
m("\u2259", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`\u2258}}");
m("\u225A", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`\u225A}}");
m("\u225B", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`\u225B}}");
m("\u225D", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`\u225D}}");
m("\u225E", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`\u225E}}");
m("\u225F", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`\u225F}}");
m("\u27C2", "\\perp");
m("\u203C", "\\mathclose{!\\mkern-0.8mu!}");
m("\u220C", "\\notni");
m("\u231C", "\\ulcorner");
m("\u231D", "\\urcorner");
m("\u231E", "\\llcorner");
m("\u231F", "\\lrcorner");
m("\xA9", "\\copyright");
m("\xAE", "\\textregistered");
m("\uFE0F", "\\textregistered");
m("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
m("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
m("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
m("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
m("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
m("\u22EE", "\\vdots");
m("\\varGamma", "\\mathit{\\Gamma}");
m("\\varDelta", "\\mathit{\\Delta}");
m("\\varTheta", "\\mathit{\\Theta}");
m("\\varLambda", "\\mathit{\\Lambda}");
m("\\varXi", "\\mathit{\\Xi}");
m("\\varPi", "\\mathit{\\Pi}");
m("\\varSigma", "\\mathit{\\Sigma}");
m("\\varUpsilon", "\\mathit{\\Upsilon}");
m("\\varPhi", "\\mathit{\\Phi}");
m("\\varPsi", "\\mathit{\\Psi}");
m("\\varOmega", "\\mathit{\\Omega}");
m("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
m("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
m("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
m("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
m("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
m("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
m("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
m("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var ra = {
  ",": "\\dotsc",
  "\\not": "\\dotsb",
  // \keybin@ checks for the following:
  "+": "\\dotsb",
  "=": "\\dotsb",
  "<": "\\dotsb",
  ">": "\\dotsb",
  "-": "\\dotsb",
  "*": "\\dotsb",
  ":": "\\dotsb",
  // Symbols whose definition starts with \DOTSB:
  "\\DOTSB": "\\dotsb",
  "\\coprod": "\\dotsb",
  "\\bigvee": "\\dotsb",
  "\\bigwedge": "\\dotsb",
  "\\biguplus": "\\dotsb",
  "\\bigcap": "\\dotsb",
  "\\bigcup": "\\dotsb",
  "\\prod": "\\dotsb",
  "\\sum": "\\dotsb",
  "\\bigotimes": "\\dotsb",
  "\\bigoplus": "\\dotsb",
  "\\bigodot": "\\dotsb",
  "\\bigsqcup": "\\dotsb",
  "\\And": "\\dotsb",
  "\\longrightarrow": "\\dotsb",
  "\\Longrightarrow": "\\dotsb",
  "\\longleftarrow": "\\dotsb",
  "\\Longleftarrow": "\\dotsb",
  "\\longleftrightarrow": "\\dotsb",
  "\\Longleftrightarrow": "\\dotsb",
  "\\mapsto": "\\dotsb",
  "\\longmapsto": "\\dotsb",
  "\\hookrightarrow": "\\dotsb",
  "\\doteq": "\\dotsb",
  // Symbols whose definition starts with \mathbin:
  "\\mathbin": "\\dotsb",
  // Symbols whose definition starts with \mathrel:
  "\\mathrel": "\\dotsb",
  "\\relbar": "\\dotsb",
  "\\Relbar": "\\dotsb",
  "\\xrightarrow": "\\dotsb",
  "\\xleftarrow": "\\dotsb",
  // Symbols whose definition starts with \DOTSI:
  "\\DOTSI": "\\dotsi",
  "\\int": "\\dotsi",
  "\\oint": "\\dotsi",
  "\\iint": "\\dotsi",
  "\\iiint": "\\dotsi",
  "\\iiiint": "\\dotsi",
  "\\idotsint": "\\dotsi",
  // Symbols whose definition starts with \DOTSX:
  "\\DOTSX": "\\dotsx"
}, ps = /* @__PURE__ */ new Set(["bin", "rel"]);
m("\\dots", function(r) {
  var e = "\\dotso", t = r.expandAfterFuture().text;
  return t in ra ? e = ra[t] : (t.slice(0, 4) === "\\not" || t in K.math && ps.has(K.math[t].group)) && (e = "\\dotsb"), e;
});
var mr = {
  // \rightdelim@ checks for the following:
  ")": !0,
  "]": !0,
  "\\rbrack": !0,
  "\\}": !0,
  "\\rbrace": !0,
  "\\rangle": !0,
  "\\rceil": !0,
  "\\rfloor": !0,
  "\\rgroup": !0,
  "\\rmoustache": !0,
  "\\right": !0,
  "\\bigr": !0,
  "\\biggr": !0,
  "\\Bigr": !0,
  "\\Biggr": !0,
  // \extra@ also tests for the following:
  $: !0,
  // \extrap@ checks for the following:
  ";": !0,
  ".": !0,
  ",": !0
};
m("\\dotso", function(r) {
  var e = r.future().text;
  return e in mr ? "\\ldots\\," : "\\ldots";
});
m("\\dotsc", function(r) {
  var e = r.future().text;
  return e in mr && e !== "," ? "\\ldots\\," : "\\ldots";
});
m("\\cdots", function(r) {
  var e = r.future().text;
  return e in mr ? "\\@cdots\\," : "\\@cdots";
});
m("\\dotsb", "\\cdots");
m("\\dotsm", "\\cdots");
m("\\dotsi", "\\!\\cdots");
m("\\dotsx", "\\ldots\\,");
m("\\DOTSI", "\\relax");
m("\\DOTSB", "\\relax");
m("\\DOTSX", "\\relax");
m("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
m("\\,", "\\tmspace+{3mu}{.1667em}");
m("\\thinspace", "\\,");
m("\\>", "\\mskip{4mu}");
m("\\:", "\\tmspace+{4mu}{.2222em}");
m("\\medspace", "\\:");
m("\\;", "\\tmspace+{5mu}{.2777em}");
m("\\thickspace", "\\;");
m("\\!", "\\tmspace-{3mu}{.1667em}");
m("\\negthinspace", "\\!");
m("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
m("\\negthickspace", "\\tmspace-{5mu}{.277em}");
m("\\enspace", "\\kern.5em ");
m("\\enskip", "\\hskip.5em\\relax");
m("\\quad", "\\hskip1em\\relax");
m("\\qquad", "\\hskip2em\\relax");
m("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
m("\\tag@paren", "\\tag@literal{({#1})}");
m("\\tag@literal", (r) => {
  if (r.macros.get("\\df@tag"))
    throw new k("Multiple \\tag");
  return "\\gdef\\df@tag{\\text{#1}}";
});
m("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
m("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
m("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
m("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
m("\\newline", "\\\\\\relax");
m("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var nn = M(Oe["Main-Regular"][84][1] - 0.7 * Oe["Main-Regular"][65][1]);
m("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + nn + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
m("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + nn + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
m("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
m("\\@hspace", "\\hskip #1\\relax");
m("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
m("\\ordinarycolon", ":");
m("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
m("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
m("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
m("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
m("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
m("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
m("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
m("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
m("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
m("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
m("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
m("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
m("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
m("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
m("\u2237", "\\dblcolon");
m("\u2239", "\\eqcolon");
m("\u2254", "\\coloneqq");
m("\u2255", "\\eqqcolon");
m("\u2A74", "\\Coloneqq");
m("\\ratio", "\\vcentcolon");
m("\\coloncolon", "\\dblcolon");
m("\\colonequals", "\\coloneqq");
m("\\coloncolonequals", "\\Coloneqq");
m("\\equalscolon", "\\eqqcolon");
m("\\equalscoloncolon", "\\Eqqcolon");
m("\\colonminus", "\\coloneq");
m("\\coloncolonminus", "\\Coloneq");
m("\\minuscolon", "\\eqcolon");
m("\\minuscoloncolon", "\\Eqcolon");
m("\\coloncolonapprox", "\\Colonapprox");
m("\\coloncolonsim", "\\Colonsim");
m("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
m("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
m("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
m("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
m("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`\u220C}}");
m("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
m("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
m("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
m("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
m("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
m("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
m("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
m("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
m("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{\u2269}");
m("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{\u2268}");
m("\\ngeqq", "\\html@mathml{\\@ngeqq}{\u2271}");
m("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{\u2271}");
m("\\nleqq", "\\html@mathml{\\@nleqq}{\u2270}");
m("\\nleqslant", "\\html@mathml{\\@nleqslant}{\u2270}");
m("\\nshortmid", "\\html@mathml{\\@nshortmid}{\u2224}");
m("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{\u2226}");
m("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{\u2288}");
m("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{\u2289}");
m("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{\u228A}");
m("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{\u2ACB}");
m("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{\u228B}");
m("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{\u2ACC}");
m("\\imath", "\\html@mathml{\\@imath}{\u0131}");
m("\\jmath", "\\html@mathml{\\@jmath}{\u0237}");
m("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`\u27E6}}");
m("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`\u27E7}}");
m("\u27E6", "\\llbracket");
m("\u27E7", "\\rrbracket");
m("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`\u2983}}");
m("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`\u2984}}");
m("\u2983", "\\lBrace");
m("\u2984", "\\rBrace");
m("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`\u29B5}}");
m("\u29B5", "\\minuso");
m("\\darr", "\\downarrow");
m("\\dArr", "\\Downarrow");
m("\\Darr", "\\Downarrow");
m("\\lang", "\\langle");
m("\\rang", "\\rangle");
m("\\uarr", "\\uparrow");
m("\\uArr", "\\Uparrow");
m("\\Uarr", "\\Uparrow");
m("\\N", "\\mathbb{N}");
m("\\R", "\\mathbb{R}");
m("\\Z", "\\mathbb{Z}");
m("\\alef", "\\aleph");
m("\\alefsym", "\\aleph");
m("\\Alpha", "\\mathrm{A}");
m("\\Beta", "\\mathrm{B}");
m("\\bull", "\\bullet");
m("\\Chi", "\\mathrm{X}");
m("\\clubs", "\\clubsuit");
m("\\cnums", "\\mathbb{C}");
m("\\Complex", "\\mathbb{C}");
m("\\Dagger", "\\ddagger");
m("\\diamonds", "\\diamondsuit");
m("\\empty", "\\emptyset");
m("\\Epsilon", "\\mathrm{E}");
m("\\Eta", "\\mathrm{H}");
m("\\exist", "\\exists");
m("\\harr", "\\leftrightarrow");
m("\\hArr", "\\Leftrightarrow");
m("\\Harr", "\\Leftrightarrow");
m("\\hearts", "\\heartsuit");
m("\\image", "\\Im");
m("\\infin", "\\infty");
m("\\Iota", "\\mathrm{I}");
m("\\isin", "\\in");
m("\\Kappa", "\\mathrm{K}");
m("\\larr", "\\leftarrow");
m("\\lArr", "\\Leftarrow");
m("\\Larr", "\\Leftarrow");
m("\\lrarr", "\\leftrightarrow");
m("\\lrArr", "\\Leftrightarrow");
m("\\Lrarr", "\\Leftrightarrow");
m("\\Mu", "\\mathrm{M}");
m("\\natnums", "\\mathbb{N}");
m("\\Nu", "\\mathrm{N}");
m("\\Omicron", "\\mathrm{O}");
m("\\plusmn", "\\pm");
m("\\rarr", "\\rightarrow");
m("\\rArr", "\\Rightarrow");
m("\\Rarr", "\\Rightarrow");
m("\\real", "\\Re");
m("\\reals", "\\mathbb{R}");
m("\\Reals", "\\mathbb{R}");
m("\\Rho", "\\mathrm{P}");
m("\\sdot", "\\cdot");
m("\\sect", "\\S");
m("\\spades", "\\spadesuit");
m("\\sub", "\\subset");
m("\\sube", "\\subseteq");
m("\\supe", "\\supseteq");
m("\\Tau", "\\mathrm{T}");
m("\\thetasym", "\\vartheta");
m("\\weierp", "\\wp");
m("\\Zeta", "\\mathrm{Z}");
m("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
m("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
m("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
m("\\bra", "\\mathinner{\\langle{#1}|}");
m("\\ket", "\\mathinner{|{#1}\\rangle}");
m("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
m("\\Bra", "\\left\\langle#1\\right|");
m("\\Ket", "\\left|#1\\right\\rangle");
var sn = (r) => (e) => {
  var t = e.consumeArg().tokens, a = e.consumeArg().tokens, n = e.consumeArg().tokens, i = e.consumeArg().tokens, l = e.macros.get("|"), u = e.macros.get("\\|");
  e.macros.beginGroup();
  var h = (b) => (y) => {
    r && (y.macros.set("|", l), n.length && y.macros.set("\\|", u));
    var x = b;
    if (!b && n.length) {
      var T = y.future();
      T.text === "|" && (y.popToken(), x = !0);
    }
    return {
      tokens: x ? n : a,
      numArgs: 0
    };
  };
  e.macros.set("|", h(!1)), n.length && e.macros.set("\\|", h(!0));
  var f = e.consumeArg().tokens, v = e.expandTokens([
    ...i,
    ...f,
    ...t
    // reversed
  ]);
  return e.macros.endGroup(), {
    tokens: v.reverse(),
    numArgs: 0
  };
};
m("\\bra@ket", sn(!1));
m("\\bra@set", sn(!0));
m("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
m("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
m("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
m("\\angln", "{\\angl n}");
m("\\blue", "\\textcolor{##6495ed}{#1}");
m("\\orange", "\\textcolor{##ffa500}{#1}");
m("\\pink", "\\textcolor{##ff00af}{#1}");
m("\\red", "\\textcolor{##df0030}{#1}");
m("\\green", "\\textcolor{##28ae7b}{#1}");
m("\\gray", "\\textcolor{gray}{#1}");
m("\\purple", "\\textcolor{##9d38bd}{#1}");
m("\\blueA", "\\textcolor{##ccfaff}{#1}");
m("\\blueB", "\\textcolor{##80f6ff}{#1}");
m("\\blueC", "\\textcolor{##63d9ea}{#1}");
m("\\blueD", "\\textcolor{##11accd}{#1}");
m("\\blueE", "\\textcolor{##0c7f99}{#1}");
m("\\tealA", "\\textcolor{##94fff5}{#1}");
m("\\tealB", "\\textcolor{##26edd5}{#1}");
m("\\tealC", "\\textcolor{##01d1c1}{#1}");
m("\\tealD", "\\textcolor{##01a995}{#1}");
m("\\tealE", "\\textcolor{##208170}{#1}");
m("\\greenA", "\\textcolor{##b6ffb0}{#1}");
m("\\greenB", "\\textcolor{##8af281}{#1}");
m("\\greenC", "\\textcolor{##74cf70}{#1}");
m("\\greenD", "\\textcolor{##1fab54}{#1}");
m("\\greenE", "\\textcolor{##0d923f}{#1}");
m("\\goldA", "\\textcolor{##ffd0a9}{#1}");
m("\\goldB", "\\textcolor{##ffbb71}{#1}");
m("\\goldC", "\\textcolor{##ff9c39}{#1}");
m("\\goldD", "\\textcolor{##e07d10}{#1}");
m("\\goldE", "\\textcolor{##a75a05}{#1}");
m("\\redA", "\\textcolor{##fca9a9}{#1}");
m("\\redB", "\\textcolor{##ff8482}{#1}");
m("\\redC", "\\textcolor{##f9685d}{#1}");
m("\\redD", "\\textcolor{##e84d39}{#1}");
m("\\redE", "\\textcolor{##bc2612}{#1}");
m("\\maroonA", "\\textcolor{##ffbde0}{#1}");
m("\\maroonB", "\\textcolor{##ff92c6}{#1}");
m("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
m("\\maroonD", "\\textcolor{##ca337c}{#1}");
m("\\maroonE", "\\textcolor{##9e034e}{#1}");
m("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
m("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
m("\\purpleC", "\\textcolor{##aa87ff}{#1}");
m("\\purpleD", "\\textcolor{##7854ab}{#1}");
m("\\purpleE", "\\textcolor{##543b78}{#1}");
m("\\mintA", "\\textcolor{##f5f9e8}{#1}");
m("\\mintB", "\\textcolor{##edf2df}{#1}");
m("\\mintC", "\\textcolor{##e0e5cc}{#1}");
m("\\grayA", "\\textcolor{##f6f7f7}{#1}");
m("\\grayB", "\\textcolor{##f0f1f2}{#1}");
m("\\grayC", "\\textcolor{##e3e5e6}{#1}");
m("\\grayD", "\\textcolor{##d6d8da}{#1}");
m("\\grayE", "\\textcolor{##babec2}{#1}");
m("\\grayF", "\\textcolor{##888d93}{#1}");
m("\\grayG", "\\textcolor{##626569}{#1}");
m("\\grayH", "\\textcolor{##3b3e40}{#1}");
m("\\grayI", "\\textcolor{##21242c}{#1}");
m("\\kaBlue", "\\textcolor{##314453}{#1}");
m("\\kaGreen", "\\textcolor{##71B307}{#1}");
var on = {
  "^": !0,
  // Parser.js
  _: !0,
  // Parser.js
  "\\limits": !0,
  // Parser.js
  "\\nolimits": !0
  // Parser.js
};
class fs {
  constructor(e, t, a) {
    this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new ms(ds, t.macros), this.mode = a, this.stack = [];
  }
  /**
   * Feed a new input string to the same MacroExpander
   * (with existing macros etc.).
   */
  feed(e) {
    this.lexer = new ea(e, this.settings);
  }
  /**
   * Switches between "text" and "math" modes.
   */
  switchMode(e) {
    this.mode = e;
  }
  /**
   * Start a new group nesting within all namespaces.
   */
  beginGroup() {
    this.macros.beginGroup();
  }
  /**
   * End current group nesting within all namespaces.
   */
  endGroup() {
    this.macros.endGroup();
  }
  /**
   * Ends all currently nested groups (if any), restoring values before the
   * groups began.  Useful in case of an error in the middle of parsing.
   */
  endGroups() {
    this.macros.endGroups();
  }
  /**
   * Returns the topmost token on the stack, without expanding it.
   * Similar in behavior to TeX's `\futurelet`.
   */
  future() {
    return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
  }
  /**
   * Remove and return the next unexpanded token.
   */
  popToken() {
    return this.future(), this.stack.pop();
  }
  /**
   * Add a given token to the token stack.  In particular, this get be used
   * to put back a token returned from one of the other methods.
   */
  pushToken(e) {
    this.stack.push(e);
  }
  /**
   * Append an array of tokens to the token stack.
   */
  pushTokens(e) {
    this.stack.push(...e);
  }
  /**
   * Find an macro argument without expanding tokens and append the array of
   * tokens to the token stack. Uses Token as a container for the result.
   */
  scanArgument(e) {
    var t, a, n;
    if (e) {
      if (this.consumeSpaces(), this.future().text !== "[")
        return null;
      t = this.popToken(), {
        tokens: n,
        end: a
      } = this.consumeArg(["]"]);
    } else
      ({
        tokens: n,
        start: t,
        end: a
      } = this.consumeArg());
    return this.pushToken(new be("EOF", a.loc)), this.pushTokens(n), new be("", ve.range(t, a));
  }
  /**
   * Consume all following space tokens, without expansion.
   */
  consumeSpaces() {
    for (; ; ) {
      var e = this.future();
      if (e.text === " ")
        this.stack.pop();
      else
        break;
    }
  }
  /**
   * Consume an argument from the token stream, and return the resulting array
   * of tokens and start/end token.
   */
  consumeArg(e) {
    var t = [], a = e && e.length > 0;
    a || this.consumeSpaces();
    var n = this.future(), i, l = 0, u = 0;
    do {
      if (i = this.popToken(), t.push(i), i.text === "{")
        ++l;
      else if (i.text === "}") {
        if (--l, l === -1)
          throw new k("Extra }", i);
      } else if (i.text === "EOF")
        throw new k("Unexpected end of input in a macro argument, expected '" + (e && a ? e[u] : "}") + "'", i);
      if (e && a)
        if ((l === 0 || l === 1 && e[u] === "{") && i.text === e[u]) {
          if (++u, u === e.length) {
            t.splice(-u, u);
            break;
          }
        } else
          u = 0;
    } while (l !== 0 || a);
    return n.text === "{" && t[t.length - 1].text === "}" && (t.pop(), t.shift()), t.reverse(), {
      tokens: t,
      start: n,
      end: i
    };
  }
  /**
   * Consume the specified number of (delimited) arguments from the token
   * stream and return the resulting array of arguments.
   */
  consumeArgs(e, t) {
    if (t) {
      if (t.length !== e + 1)
        throw new k("The length of delimiters doesn't match the number of args!");
      for (var a = t[0], n = 0; n < a.length; n++) {
        var i = this.popToken();
        if (a[n] !== i.text)
          throw new k("Use of the macro doesn't match its definition", i);
      }
    }
    for (var l = [], u = 0; u < e; u++)
      l.push(this.consumeArg(t && t[u + 1]).tokens);
    return l;
  }
  /**
   * Increment `expansionCount` by the specified amount.
   * Throw an error if it exceeds `maxExpand`.
   */
  countExpansion(e) {
    if (this.expansionCount += e, this.expansionCount > this.settings.maxExpand)
      throw new k("Too many expansions: infinite loop or need to increase maxExpand setting");
  }
  /**
   * Expand the next token only once if possible.
   *
   * If the token is expanded, the resulting tokens will be pushed onto
   * the stack in reverse order, and the number of such tokens will be
   * returned.  This number might be zero or positive.
   *
   * If not, the return value is `false`, and the next token remains at the
   * top of the stack.
   *
   * In either case, the next token will be on the top of the stack,
   * or the stack will be empty (in case of empty expansion
   * and no other tokens).
   *
   * Used to implement `expandAfterFuture` and `expandNextToken`.
   *
   * If expandableOnly, only expandable tokens are expanded and
   * an undefined control sequence results in an error.
   */
  expandOnce(e) {
    var t = this.popToken(), a = t.text, n = t.noexpand ? null : this._getExpansion(a);
    if (n == null || e && n.unexpandable) {
      if (e && n == null && a[0] === "\\" && !this.isDefined(a))
        throw new k("Undefined control sequence: " + a);
      return this.pushToken(t), !1;
    }
    this.countExpansion(1);
    var i = n.tokens, l = this.consumeArgs(n.numArgs, n.delimiters);
    if (n.numArgs) {
      i = i.slice();
      for (var u = i.length - 1; u >= 0; --u) {
        var h = i[u];
        if (h.text === "#") {
          if (u === 0)
            throw new k("Incomplete placeholder at end of macro body", h);
          if (h = i[--u], h.text === "#")
            i.splice(u + 1, 1);
          else if (/^[1-9]$/.test(h.text))
            i.splice(u, 2, ...l[+h.text - 1]);
          else
            throw new k("Not a valid argument number", h);
        }
      }
    }
    return this.pushTokens(i), i.length;
  }
  /**
   * Expand the next token only once (if possible), and return the resulting
   * top token on the stack (without removing anything from the stack).
   * Similar in behavior to TeX's `\expandafter\futurelet`.
   * Equivalent to expandOnce() followed by future().
   */
  expandAfterFuture() {
    return this.expandOnce(), this.future();
  }
  /**
   * Recursively expand first token, then return first non-expandable token.
   */
  expandNextToken() {
    for (; ; )
      if (this.expandOnce() === !1) {
        var e = this.stack.pop();
        return e.treatAsRelax && (e.text = "\\relax"), e;
      }
    throw new Error();
  }
  /**
   * Fully expand the given macro name and return the resulting list of
   * tokens, or return `undefined` if no such macro is defined.
   */
  expandMacro(e) {
    return this.macros.has(e) ? this.expandTokens([new be(e)]) : void 0;
  }
  /**
   * Fully expand the given token stream and return the resulting list of
   * tokens.  Note that the input tokens are in reverse order, but the
   * output tokens are in forward order.
   */
  expandTokens(e) {
    var t = [], a = this.stack.length;
    for (this.pushTokens(e); this.stack.length > a; )
      if (this.expandOnce(!0) === !1) {
        var n = this.stack.pop();
        n.treatAsRelax && (n.noexpand = !1, n.treatAsRelax = !1), t.push(n);
      }
    return this.countExpansion(t.length), t;
  }
  /**
   * Fully expand the given macro name and return the result as a string,
   * or return `undefined` if no such macro is defined.
   */
  expandMacroAsText(e) {
    var t = this.expandMacro(e);
    return t && t.map((a) => a.text).join("");
  }
  /**
   * Returns the expanded macro as a reversed array of tokens and a macro
   * argument count.  Or returns `null` if no such macro.
   */
  _getExpansion(e) {
    var t = this.macros.get(e);
    if (t == null)
      return t;
    if (e.length === 1) {
      var a = this.lexer.catcodes[e];
      if (a != null && a !== 13)
        return;
    }
    var n = typeof t == "function" ? t(this) : t;
    if (typeof n == "string") {
      var i = 0;
      if (n.includes("#"))
        for (var l = n.replace(/##/g, ""); l.includes("#" + (i + 1)); )
          ++i;
      for (var u = new ea(n, this.settings), h = [], f = u.lex(); f.text !== "EOF"; )
        h.push(f), f = u.lex();
      h.reverse();
      var v = {
        tokens: h,
        numArgs: i
      };
      return v;
    }
    return n;
  }
  /**
   * Determine whether a command is currently "defined" (has some
   * functionality), meaning that it's a macro (in the current group),
   * a function, a symbol, or one of the special commands listed in
   * `implicitCommands`.
   */
  isDefined(e) {
    return this.macros.has(e) || Ye.hasOwnProperty(e) || K.math.hasOwnProperty(e) || K.text.hasOwnProperty(e) || on.hasOwnProperty(e);
  }
  /**
   * Determine whether a command is expandable.
   */
  isExpandable(e) {
    var t = this.macros.get(e);
    return t != null ? typeof t == "string" || typeof t == "function" || !t.unexpandable : Ye.hasOwnProperty(e) && !Ye[e].primitive;
  }
}
var aa = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, V0 = Object.freeze({
  "\u208A": "+",
  "\u208B": "-",
  "\u208C": "=",
  "\u208D": "(",
  "\u208E": ")",
  "\u2080": "0",
  "\u2081": "1",
  "\u2082": "2",
  "\u2083": "3",
  "\u2084": "4",
  "\u2085": "5",
  "\u2086": "6",
  "\u2087": "7",
  "\u2088": "8",
  "\u2089": "9",
  "\u2090": "a",
  "\u2091": "e",
  "\u2095": "h",
  "\u1D62": "i",
  "\u2C7C": "j",
  "\u2096": "k",
  "\u2097": "l",
  "\u2098": "m",
  "\u2099": "n",
  "\u2092": "o",
  "\u209A": "p",
  "\u1D63": "r",
  "\u209B": "s",
  "\u209C": "t",
  "\u1D64": "u",
  "\u1D65": "v",
  "\u2093": "x",
  "\u1D66": "\u03B2",
  "\u1D67": "\u03B3",
  "\u1D68": "\u03C1",
  "\u1D69": "\u03D5",
  "\u1D6A": "\u03C7",
  "\u207A": "+",
  "\u207B": "-",
  "\u207C": "=",
  "\u207D": "(",
  "\u207E": ")",
  "\u2070": "0",
  "\xB9": "1",
  "\xB2": "2",
  "\xB3": "3",
  "\u2074": "4",
  "\u2075": "5",
  "\u2076": "6",
  "\u2077": "7",
  "\u2078": "8",
  "\u2079": "9",
  "\u1D2C": "A",
  "\u1D2E": "B",
  "\u1D30": "D",
  "\u1D31": "E",
  "\u1D33": "G",
  "\u1D34": "H",
  "\u1D35": "I",
  "\u1D36": "J",
  "\u1D37": "K",
  "\u1D38": "L",
  "\u1D39": "M",
  "\u1D3A": "N",
  "\u1D3C": "O",
  "\u1D3E": "P",
  "\u1D3F": "R",
  "\u1D40": "T",
  "\u1D41": "U",
  "\u2C7D": "V",
  "\u1D42": "W",
  "\u1D43": "a",
  "\u1D47": "b",
  "\u1D9C": "c",
  "\u1D48": "d",
  "\u1D49": "e",
  "\u1DA0": "f",
  "\u1D4D": "g",
  \u02B0: "h",
  "\u2071": "i",
  \u02B2: "j",
  "\u1D4F": "k",
  \u02E1: "l",
  "\u1D50": "m",
  \u207F: "n",
  "\u1D52": "o",
  "\u1D56": "p",
  \u02B3: "r",
  \u02E2: "s",
  "\u1D57": "t",
  "\u1D58": "u",
  "\u1D5B": "v",
  \u02B7: "w",
  \u02E3: "x",
  \u02B8: "y",
  "\u1DBB": "z",
  "\u1D5D": "\u03B2",
  "\u1D5E": "\u03B3",
  "\u1D5F": "\u03B4",
  "\u1D60": "\u03D5",
  "\u1D61": "\u03C7",
  "\u1DBF": "\u03B8"
}), Ft = {
  "\u0301": {
    text: "\\'",
    math: "\\acute"
  },
  "\u0300": {
    text: "\\`",
    math: "\\grave"
  },
  "\u0308": {
    text: '\\"',
    math: "\\ddot"
  },
  "\u0303": {
    text: "\\~",
    math: "\\tilde"
  },
  "\u0304": {
    text: "\\=",
    math: "\\bar"
  },
  "\u0306": {
    text: "\\u",
    math: "\\breve"
  },
  "\u030C": {
    text: "\\v",
    math: "\\check"
  },
  "\u0302": {
    text: "\\^",
    math: "\\hat"
  },
  "\u0307": {
    text: "\\.",
    math: "\\dot"
  },
  "\u030A": {
    text: "\\r",
    math: "\\mathring"
  },
  "\u030B": {
    text: "\\H"
  },
  "\u0327": {
    text: "\\c"
  }
}, na = {
  \u00E1: "a\u0301",
  \u00E0: "a\u0300",
  \u00E4: "a\u0308",
  \u01DF: "a\u0308\u0304",
  \u00E3: "a\u0303",
  \u0101: "a\u0304",
  \u0103: "a\u0306",
  \u1EAF: "a\u0306\u0301",
  \u1EB1: "a\u0306\u0300",
  \u1EB5: "a\u0306\u0303",
  \u01CE: "a\u030C",
  \u00E2: "a\u0302",
  \u1EA5: "a\u0302\u0301",
  \u1EA7: "a\u0302\u0300",
  \u1EAB: "a\u0302\u0303",
  \u0227: "a\u0307",
  \u01E1: "a\u0307\u0304",
  \u00E5: "a\u030A",
  \u01FB: "a\u030A\u0301",
  \u1E03: "b\u0307",
  \u0107: "c\u0301",
  \u1E09: "c\u0327\u0301",
  \u010D: "c\u030C",
  \u0109: "c\u0302",
  \u010B: "c\u0307",
  \u00E7: "c\u0327",
  \u010F: "d\u030C",
  \u1E0B: "d\u0307",
  \u1E11: "d\u0327",
  \u00E9: "e\u0301",
  \u00E8: "e\u0300",
  \u00EB: "e\u0308",
  \u1EBD: "e\u0303",
  \u0113: "e\u0304",
  \u1E17: "e\u0304\u0301",
  \u1E15: "e\u0304\u0300",
  \u0115: "e\u0306",
  \u1E1D: "e\u0327\u0306",
  \u011B: "e\u030C",
  \u00EA: "e\u0302",
  \u1EBF: "e\u0302\u0301",
  \u1EC1: "e\u0302\u0300",
  \u1EC5: "e\u0302\u0303",
  \u0117: "e\u0307",
  \u0229: "e\u0327",
  \u1E1F: "f\u0307",
  \u01F5: "g\u0301",
  \u1E21: "g\u0304",
  \u011F: "g\u0306",
  \u01E7: "g\u030C",
  \u011D: "g\u0302",
  \u0121: "g\u0307",
  \u0123: "g\u0327",
  \u1E27: "h\u0308",
  \u021F: "h\u030C",
  \u0125: "h\u0302",
  \u1E23: "h\u0307",
  \u1E29: "h\u0327",
  \u00ED: "i\u0301",
  \u00EC: "i\u0300",
  \u00EF: "i\u0308",
  \u1E2F: "i\u0308\u0301",
  \u0129: "i\u0303",
  \u012B: "i\u0304",
  \u012D: "i\u0306",
  \u01D0: "i\u030C",
  \u00EE: "i\u0302",
  \u01F0: "j\u030C",
  \u0135: "j\u0302",
  \u1E31: "k\u0301",
  \u01E9: "k\u030C",
  \u0137: "k\u0327",
  \u013A: "l\u0301",
  \u013E: "l\u030C",
  \u013C: "l\u0327",
  \u1E3F: "m\u0301",
  \u1E41: "m\u0307",
  \u0144: "n\u0301",
  \u01F9: "n\u0300",
  \u00F1: "n\u0303",
  \u0148: "n\u030C",
  \u1E45: "n\u0307",
  \u0146: "n\u0327",
  \u00F3: "o\u0301",
  \u00F2: "o\u0300",
  \u00F6: "o\u0308",
  \u022B: "o\u0308\u0304",
  \u00F5: "o\u0303",
  \u1E4D: "o\u0303\u0301",
  \u1E4F: "o\u0303\u0308",
  \u022D: "o\u0303\u0304",
  \u014D: "o\u0304",
  \u1E53: "o\u0304\u0301",
  \u1E51: "o\u0304\u0300",
  \u014F: "o\u0306",
  \u01D2: "o\u030C",
  \u00F4: "o\u0302",
  \u1ED1: "o\u0302\u0301",
  \u1ED3: "o\u0302\u0300",
  \u1ED7: "o\u0302\u0303",
  \u022F: "o\u0307",
  \u0231: "o\u0307\u0304",
  \u0151: "o\u030B",
  \u1E55: "p\u0301",
  \u1E57: "p\u0307",
  \u0155: "r\u0301",
  \u0159: "r\u030C",
  \u1E59: "r\u0307",
  \u0157: "r\u0327",
  \u015B: "s\u0301",
  \u1E65: "s\u0301\u0307",
  \u0161: "s\u030C",
  \u1E67: "s\u030C\u0307",
  \u015D: "s\u0302",
  \u1E61: "s\u0307",
  \u015F: "s\u0327",
  \u1E97: "t\u0308",
  \u0165: "t\u030C",
  \u1E6B: "t\u0307",
  \u0163: "t\u0327",
  \u00FA: "u\u0301",
  \u00F9: "u\u0300",
  \u00FC: "u\u0308",
  \u01D8: "u\u0308\u0301",
  \u01DC: "u\u0308\u0300",
  \u01D6: "u\u0308\u0304",
  \u01DA: "u\u0308\u030C",
  \u0169: "u\u0303",
  \u1E79: "u\u0303\u0301",
  \u016B: "u\u0304",
  \u1E7B: "u\u0304\u0308",
  \u016D: "u\u0306",
  \u01D4: "u\u030C",
  \u00FB: "u\u0302",
  \u016F: "u\u030A",
  \u0171: "u\u030B",
  \u1E7D: "v\u0303",
  \u1E83: "w\u0301",
  \u1E81: "w\u0300",
  \u1E85: "w\u0308",
  \u0175: "w\u0302",
  \u1E87: "w\u0307",
  \u1E98: "w\u030A",
  \u1E8D: "x\u0308",
  \u1E8B: "x\u0307",
  \u00FD: "y\u0301",
  \u1EF3: "y\u0300",
  \u00FF: "y\u0308",
  \u1EF9: "y\u0303",
  \u0233: "y\u0304",
  \u0177: "y\u0302",
  \u1E8F: "y\u0307",
  \u1E99: "y\u030A",
  \u017A: "z\u0301",
  \u017E: "z\u030C",
  \u1E91: "z\u0302",
  \u017C: "z\u0307",
  \u00C1: "A\u0301",
  \u00C0: "A\u0300",
  \u00C4: "A\u0308",
  \u01DE: "A\u0308\u0304",
  \u00C3: "A\u0303",
  \u0100: "A\u0304",
  \u0102: "A\u0306",
  \u1EAE: "A\u0306\u0301",
  \u1EB0: "A\u0306\u0300",
  \u1EB4: "A\u0306\u0303",
  \u01CD: "A\u030C",
  \u00C2: "A\u0302",
  \u1EA4: "A\u0302\u0301",
  \u1EA6: "A\u0302\u0300",
  \u1EAA: "A\u0302\u0303",
  \u0226: "A\u0307",
  \u01E0: "A\u0307\u0304",
  \u00C5: "A\u030A",
  \u01FA: "A\u030A\u0301",
  \u1E02: "B\u0307",
  \u0106: "C\u0301",
  \u1E08: "C\u0327\u0301",
  \u010C: "C\u030C",
  \u0108: "C\u0302",
  \u010A: "C\u0307",
  \u00C7: "C\u0327",
  \u010E: "D\u030C",
  \u1E0A: "D\u0307",
  \u1E10: "D\u0327",
  \u00C9: "E\u0301",
  \u00C8: "E\u0300",
  \u00CB: "E\u0308",
  \u1EBC: "E\u0303",
  \u0112: "E\u0304",
  \u1E16: "E\u0304\u0301",
  \u1E14: "E\u0304\u0300",
  \u0114: "E\u0306",
  \u1E1C: "E\u0327\u0306",
  \u011A: "E\u030C",
  \u00CA: "E\u0302",
  \u1EBE: "E\u0302\u0301",
  \u1EC0: "E\u0302\u0300",
  \u1EC4: "E\u0302\u0303",
  \u0116: "E\u0307",
  \u0228: "E\u0327",
  \u1E1E: "F\u0307",
  \u01F4: "G\u0301",
  \u1E20: "G\u0304",
  \u011E: "G\u0306",
  \u01E6: "G\u030C",
  \u011C: "G\u0302",
  \u0120: "G\u0307",
  \u0122: "G\u0327",
  \u1E26: "H\u0308",
  \u021E: "H\u030C",
  \u0124: "H\u0302",
  \u1E22: "H\u0307",
  \u1E28: "H\u0327",
  \u00CD: "I\u0301",
  \u00CC: "I\u0300",
  \u00CF: "I\u0308",
  \u1E2E: "I\u0308\u0301",
  \u0128: "I\u0303",
  \u012A: "I\u0304",
  \u012C: "I\u0306",
  \u01CF: "I\u030C",
  \u00CE: "I\u0302",
  \u0130: "I\u0307",
  \u0134: "J\u0302",
  \u1E30: "K\u0301",
  \u01E8: "K\u030C",
  \u0136: "K\u0327",
  \u0139: "L\u0301",
  \u013D: "L\u030C",
  \u013B: "L\u0327",
  \u1E3E: "M\u0301",
  \u1E40: "M\u0307",
  \u0143: "N\u0301",
  \u01F8: "N\u0300",
  \u00D1: "N\u0303",
  \u0147: "N\u030C",
  \u1E44: "N\u0307",
  \u0145: "N\u0327",
  \u00D3: "O\u0301",
  \u00D2: "O\u0300",
  \u00D6: "O\u0308",
  \u022A: "O\u0308\u0304",
  \u00D5: "O\u0303",
  \u1E4C: "O\u0303\u0301",
  \u1E4E: "O\u0303\u0308",
  \u022C: "O\u0303\u0304",
  \u014C: "O\u0304",
  \u1E52: "O\u0304\u0301",
  \u1E50: "O\u0304\u0300",
  \u014E: "O\u0306",
  \u01D1: "O\u030C",
  \u00D4: "O\u0302",
  \u1ED0: "O\u0302\u0301",
  \u1ED2: "O\u0302\u0300",
  \u1ED6: "O\u0302\u0303",
  \u022E: "O\u0307",
  \u0230: "O\u0307\u0304",
  \u0150: "O\u030B",
  \u1E54: "P\u0301",
  \u1E56: "P\u0307",
  \u0154: "R\u0301",
  \u0158: "R\u030C",
  \u1E58: "R\u0307",
  \u0156: "R\u0327",
  \u015A: "S\u0301",
  \u1E64: "S\u0301\u0307",
  \u0160: "S\u030C",
  \u1E66: "S\u030C\u0307",
  \u015C: "S\u0302",
  \u1E60: "S\u0307",
  \u015E: "S\u0327",
  \u0164: "T\u030C",
  \u1E6A: "T\u0307",
  \u0162: "T\u0327",
  \u00DA: "U\u0301",
  \u00D9: "U\u0300",
  \u00DC: "U\u0308",
  \u01D7: "U\u0308\u0301",
  \u01DB: "U\u0308\u0300",
  \u01D5: "U\u0308\u0304",
  \u01D9: "U\u0308\u030C",
  \u0168: "U\u0303",
  \u1E78: "U\u0303\u0301",
  \u016A: "U\u0304",
  \u1E7A: "U\u0304\u0308",
  \u016C: "U\u0306",
  \u01D3: "U\u030C",
  \u00DB: "U\u0302",
  \u016E: "U\u030A",
  \u0170: "U\u030B",
  \u1E7C: "V\u0303",
  \u1E82: "W\u0301",
  \u1E80: "W\u0300",
  \u1E84: "W\u0308",
  \u0174: "W\u0302",
  \u1E86: "W\u0307",
  \u1E8C: "X\u0308",
  \u1E8A: "X\u0307",
  \u00DD: "Y\u0301",
  \u1EF2: "Y\u0300",
  \u0178: "Y\u0308",
  \u1EF8: "Y\u0303",
  \u0232: "Y\u0304",
  \u0176: "Y\u0302",
  \u1E8E: "Y\u0307",
  \u0179: "Z\u0301",
  \u017D: "Z\u030C",
  \u1E90: "Z\u0302",
  \u017B: "Z\u0307",
  \u03AC: "\u03B1\u0301",
  \u1F70: "\u03B1\u0300",
  \u1FB1: "\u03B1\u0304",
  \u1FB0: "\u03B1\u0306",
  \u03AD: "\u03B5\u0301",
  \u1F72: "\u03B5\u0300",
  \u03AE: "\u03B7\u0301",
  \u1F74: "\u03B7\u0300",
  \u03AF: "\u03B9\u0301",
  \u1F76: "\u03B9\u0300",
  \u03CA: "\u03B9\u0308",
  \u0390: "\u03B9\u0308\u0301",
  \u1FD2: "\u03B9\u0308\u0300",
  \u1FD1: "\u03B9\u0304",
  \u1FD0: "\u03B9\u0306",
  \u03CC: "\u03BF\u0301",
  \u1F78: "\u03BF\u0300",
  \u03CD: "\u03C5\u0301",
  \u1F7A: "\u03C5\u0300",
  \u03CB: "\u03C5\u0308",
  \u03B0: "\u03C5\u0308\u0301",
  \u1FE2: "\u03C5\u0308\u0300",
  \u1FE1: "\u03C5\u0304",
  \u1FE0: "\u03C5\u0306",
  \u03CE: "\u03C9\u0301",
  \u1F7C: "\u03C9\u0300",
  \u038E: "\u03A5\u0301",
  \u1FEA: "\u03A5\u0300",
  \u03AB: "\u03A5\u0308",
  \u1FE9: "\u03A5\u0304",
  \u1FE8: "\u03A5\u0306",
  \u038F: "\u03A9\u0301",
  \u1FFA: "\u03A9\u0300"
};
class ut {
  constructor(e, t) {
    this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new fs(e, t, this.mode), this.settings = t, this.leftrightDepth = 0;
  }
  /**
   * Checks a result to make sure it has the right type, and throws an
   * appropriate error otherwise.
   */
  expect(e, t) {
    if (t === void 0 && (t = !0), this.fetch().text !== e)
      throw new k("Expected '" + e + "', got '" + this.fetch().text + "'", this.fetch());
    t && this.consume();
  }
  /**
   * Discards the current lookahead token, considering it consumed.
   */
  consume() {
    this.nextToken = null;
  }
  /**
   * Return the current lookahead token, or if there isn't one (at the
   * beginning, or if the previous lookahead token was consume()d),
   * fetch the next token as the new lookahead token and return it.
   */
  fetch() {
    return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken;
  }
  /**
   * Switches between "text" and "math" modes.
   */
  switchMode(e) {
    this.mode = e, this.gullet.switchMode(e);
  }
  /**
   * Main parsing function, which parses an entire input.
   */
  parse() {
    this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
    try {
      var e = this.parseExpression(!1);
      return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
    } finally {
      this.gullet.endGroups();
    }
  }
  /**
   * Fully parse a separate sequence of tokens as a separate job.
   * Tokens should be specified in reverse order, as in a MacroDefinition.
   */
  subparse(e) {
    var t = this.nextToken;
    this.consume(), this.gullet.pushToken(new be("}")), this.gullet.pushTokens(e);
    var a = this.parseExpression(!1);
    return this.expect("}"), this.nextToken = t, a;
  }
  /**
   * Parses an "expression", which is a list of atoms.
   *
   * `breakOnInfix`: Should the parsing stop when we hit infix nodes? This
   *                 happens when functions have higher precedence than infix
   *                 nodes in implicit parses.
   *
   * `breakOnTokenText`: The text of the token that the expression should end
   *                     with, or `null` if something else should end the
   *                     expression.
   */
  parseExpression(e, t) {
    for (var a = []; ; ) {
      this.mode === "math" && this.consumeSpaces();
      var n = this.fetch();
      if (ut.endOfExpression.has(n.text) || t && n.text === t || e && Ye[n.text] && Ye[n.text].infix)
        break;
      var i = this.parseAtom(t);
      if (i) {
        if (i.type === "internal")
          continue;
      } else break;
      a.push(i);
    }
    return this.mode === "text" && this.formLigatures(a), this.handleInfixNodes(a);
  }
  /**
   * Rewrites infix operators such as \over with corresponding commands such
   * as \frac.
   *
   * There can only be one infix operator per group.  If there's more than one
   * then the expression is ambiguous.  This can be resolved by adding {}.
   */
  handleInfixNodes(e) {
    for (var t = -1, a, n = 0; n < e.length; n++)
      if (e[n].type === "infix") {
        if (t !== -1)
          throw new k("only one infix operator per group", e[n].token);
        t = n, a = e[n].replaceWith;
      }
    if (t !== -1 && a) {
      var i, l, u = e.slice(0, t), h = e.slice(t + 1);
      u.length === 1 && u[0].type === "ordgroup" ? i = u[0] : i = {
        type: "ordgroup",
        mode: this.mode,
        body: u
      }, h.length === 1 && h[0].type === "ordgroup" ? l = h[0] : l = {
        type: "ordgroup",
        mode: this.mode,
        body: h
      };
      var f;
      return a === "\\\\abovefrac" ? f = this.callFunction(a, [i, e[t], l], []) : f = this.callFunction(a, [i, l], []), [f];
    } else
      return e;
  }
  /**
   * Handle a subscript or superscript with nice errors.
   */
  handleSupSubscript(e) {
    var t = this.fetch(), a = t.text;
    this.consume(), this.consumeSpaces();
    var n;
    do {
      var i;
      n = this.parseGroup(e);
    } while (((i = n) == null ? void 0 : i.type) === "internal");
    if (!n)
      throw new k("Expected group after '" + a + "'", t);
    return n;
  }
  /**
   * Converts the textual input of an unsupported command into a text node
   * contained within a color node whose color is determined by errorColor
   */
  formatUnsupportedCmd(e) {
    for (var t = [], a = 0; a < e.length; a++)
      t.push({
        type: "textord",
        mode: "text",
        text: e[a]
      });
    var n = {
      type: "text",
      mode: this.mode,
      body: t
    }, i = {
      type: "color",
      mode: this.mode,
      color: this.settings.errorColor,
      body: [n]
    };
    return i;
  }
  /**
   * Parses a group with optional super/subscripts.
   */
  parseAtom(e) {
    var t = this.parseGroup("atom", e);
    if (t?.type === "internal" || this.mode === "text")
      return t;
    for (var a, n; ; ) {
      this.consumeSpaces();
      var i = this.fetch();
      if (i.text === "\\limits" || i.text === "\\nolimits") {
        if (t && t.type === "op") {
          var l = i.text === "\\limits";
          t.limits = l, t.alwaysHandleSupSub = !0;
        } else if (t && t.type === "operatorname")
          t.alwaysHandleSupSub && (t.limits = i.text === "\\limits");
        else
          throw new k("Limit controls must follow a math operator", i);
        this.consume();
      } else if (i.text === "^") {
        if (a)
          throw new k("Double superscript", i);
        a = this.handleSupSubscript("superscript");
      } else if (i.text === "_") {
        if (n)
          throw new k("Double subscript", i);
        n = this.handleSupSubscript("subscript");
      } else if (i.text === "'") {
        if (a)
          throw new k("Double superscript", i);
        var u = {
          type: "textord",
          mode: this.mode,
          text: "\\prime"
        }, h = [u];
        for (this.consume(); this.fetch().text === "'"; )
          h.push(u), this.consume();
        this.fetch().text === "^" && h.push(this.handleSupSubscript("superscript")), a = {
          type: "ordgroup",
          mode: this.mode,
          body: h
        };
      } else if (V0[i.text]) {
        var f = aa.test(i.text), v = [];
        for (v.push(new be(V0[i.text])), this.consume(); ; ) {
          var b = this.fetch().text;
          if (!V0[b] || aa.test(b) !== f)
            break;
          v.unshift(new be(V0[b])), this.consume();
        }
        var y = this.subparse(v);
        f ? n = {
          type: "ordgroup",
          mode: "math",
          body: y
        } : a = {
          type: "ordgroup",
          mode: "math",
          body: y
        };
      } else
        break;
    }
    return a || n ? {
      type: "supsub",
      mode: this.mode,
      base: t,
      sup: a,
      sub: n
    } : t;
  }
  /**
   * Parses an entire function, including its base and all of its arguments.
   */
  parseFunction(e, t) {
    var a = this.fetch(), n = a.text, i = Ye[n];
    if (!i)
      return null;
    if (this.consume(), t && t !== "atom" && !i.allowedInArgument)
      throw new k("Got function '" + n + "' with no arguments" + (t ? " as " + t : ""), a);
    if (this.mode === "text" && !i.allowedInText)
      throw new k("Can't use function '" + n + "' in text mode", a);
    if (this.mode === "math" && i.allowedInMath === !1)
      throw new k("Can't use function '" + n + "' in math mode", a);
    var {
      args: l,
      optArgs: u
    } = this.parseArguments(n, i);
    return this.callFunction(n, l, u, a, e);
  }
  /**
   * Call a function handler with a suitable context and arguments.
   */
  callFunction(e, t, a, n, i) {
    var l = {
      funcName: e,
      parser: this,
      token: n,
      breakOnTokenText: i
    }, u = Ye[e];
    if (u && u.handler)
      return u.handler(l, t, a);
    throw new k("No function handler for " + e);
  }
  /**
   * Parses the arguments of a function or environment
   */
  parseArguments(e, t) {
    var a = t.numArgs + t.numOptionalArgs;
    if (a === 0)
      return {
        args: [],
        optArgs: []
      };
    for (var n = [], i = [], l = 0; l < a; l++) {
      var u = t.argTypes && t.argTypes[l], h = l < t.numOptionalArgs;
      (t.primitive && u == null || // \sqrt expands into primitive if optional argument doesn't exist
      t.type === "sqrt" && l === 1 && i[0] == null) && (u = "primitive");
      var f = this.parseGroupOfType("argument to '" + e + "'", u, h);
      if (h)
        i.push(f);
      else if (f != null)
        n.push(f);
      else
        throw new k("Null argument, please report this as a bug");
    }
    return {
      args: n,
      optArgs: i
    };
  }
  /**
   * Parses a group when the mode is changing.
   */
  parseGroupOfType(e, t, a) {
    switch (t) {
      case "color":
        return this.parseColorGroup(a);
      case "size":
        return this.parseSizeGroup(a);
      case "url":
        return this.parseUrlGroup(a);
      case "math":
      case "text":
        return this.parseArgumentGroup(a, t);
      case "hbox": {
        var n = this.parseArgumentGroup(a, "text");
        return n != null ? {
          type: "styling",
          mode: n.mode,
          body: [n],
          style: "text"
          // simulate \textstyle
        } : null;
      }
      case "raw": {
        var i = this.parseStringGroup("raw", a);
        return i != null ? {
          type: "raw",
          mode: "text",
          string: i.text
        } : null;
      }
      case "primitive": {
        if (a)
          throw new k("A primitive argument cannot be optional");
        var l = this.parseGroup(e);
        if (l == null)
          throw new k("Expected group as " + e, this.fetch());
        return l;
      }
      case "original":
      case null:
      case void 0:
        return this.parseArgumentGroup(a);
      default:
        throw new k("Unknown group type as " + e, this.fetch());
    }
  }
  /**
   * Discard any space tokens, fetching the next non-space token.
   */
  consumeSpaces() {
    for (; this.fetch().text === " "; )
      this.consume();
  }
  /**
   * Parses a group, essentially returning the string formed by the
   * brace-enclosed tokens plus some position information.
   */
  parseStringGroup(e, t) {
    var a = this.gullet.scanArgument(t);
    if (a == null)
      return null;
    for (var n = "", i; (i = this.fetch()).text !== "EOF"; )
      n += i.text, this.consume();
    return this.consume(), a.text = n, a;
  }
  /**
   * Parses a regex-delimited group: the largest sequence of tokens
   * whose concatenated strings match `regex`. Returns the string
   * formed by the tokens plus some position information.
   */
  parseRegexGroup(e, t) {
    for (var a = this.fetch(), n = a, i = "", l; (l = this.fetch()).text !== "EOF" && e.test(i + l.text); )
      n = l, i += n.text, this.consume();
    if (i === "")
      throw new k("Invalid " + t + ": '" + a.text + "'", a);
    return a.range(n, i);
  }
  /**
   * Parses a color description.
   */
  parseColorGroup(e) {
    var t = this.parseStringGroup("color", e);
    if (t == null)
      return null;
    var a = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(t.text);
    if (!a)
      throw new k("Invalid color: '" + t.text + "'", t);
    var n = a[0];
    return /^[0-9a-f]{6}$/i.test(n) && (n = "#" + n), {
      type: "color-token",
      mode: this.mode,
      color: n
    };
  }
  /**
   * Parses a size specification, consisting of magnitude and unit.
   */
  parseSizeGroup(e) {
    var t, a = !1;
    if (this.gullet.consumeSpaces(), !e && this.gullet.future().text !== "{" ? t = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : t = this.parseStringGroup("size", e), !t)
      return null;
    !e && t.text.length === 0 && (t.text = "0pt", a = !0);
    var n = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t.text);
    if (!n)
      throw new k("Invalid size: '" + t.text + "'", t);
    var i = {
      number: +(n[1] + n[2]),
      // sign + magnitude, cast to number
      unit: n[3]
    };
    if (!va(i))
      throw new k("Invalid unit: '" + i.unit + "'", t);
    return {
      type: "size",
      mode: this.mode,
      value: i,
      isBlank: a
    };
  }
  /**
   * Parses an URL, checking escaped letters and allowed protocols,
   * and setting the catcode of % as an active character (as in \hyperref).
   */
  parseUrlGroup(e) {
    this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
    var t = this.parseStringGroup("url", e);
    if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), t == null)
      return null;
    var a = t.text.replace(/\\([#$%&~_^{}])/g, "$1");
    return {
      type: "url",
      mode: this.mode,
      url: a
    };
  }
  /**
   * Parses an argument with the mode specified.
   */
  parseArgumentGroup(e, t) {
    var a = this.gullet.scanArgument(e);
    if (a == null)
      return null;
    var n = this.mode;
    t && this.switchMode(t), this.gullet.beginGroup();
    var i = this.parseExpression(!1, "EOF");
    this.expect("EOF"), this.gullet.endGroup();
    var l = {
      type: "ordgroup",
      mode: this.mode,
      loc: a.loc,
      body: i
    };
    return t && this.switchMode(n), l;
  }
  /**
   * Parses an ordinary group, which is either a single nucleus (like "x")
   * or an expression in braces (like "{x+y}") or an implicit group, a group
   * that starts at the current position, and ends right before a higher explicit
   * group ends, or at EOF.
   */
  parseGroup(e, t) {
    var a = this.fetch(), n = a.text, i;
    if (n === "{" || n === "\\begingroup") {
      this.consume();
      var l = n === "{" ? "}" : "\\endgroup";
      this.gullet.beginGroup();
      var u = this.parseExpression(!1, l), h = this.fetch();
      this.expect(l), this.gullet.endGroup(), i = {
        type: "ordgroup",
        mode: this.mode,
        loc: ve.range(a, h),
        body: u,
        // A group formed by \begingroup...\endgroup is a semi-simple group
        // which doesn't affect spacing in math mode, i.e., is transparent.
        // https://tex.stackexchange.com/questions/1930/when-should-one-
        // use-begingroup-instead-of-bgroup
        semisimple: n === "\\begingroup" || void 0
      };
    } else if (i = this.parseFunction(t, e) || this.parseSymbol(), i == null && n[0] === "\\" && !on.hasOwnProperty(n)) {
      if (this.settings.throwOnError)
        throw new k("Undefined control sequence: " + n, a);
      i = this.formatUnsupportedCmd(n), this.consume();
    }
    return i;
  }
  /**
   * Form ligature-like combinations of characters for text mode.
   * This includes inputs like "--", "---", "``" and "''".
   * The result will simply replace multiple textord nodes with a single
   * character in each value by a single textord node having multiple
   * characters in its value.  The representation is still ASCII source.
   * The group will be modified in place.
   */
  formLigatures(e) {
    for (var t = e.length - 1, a = 0; a < t; ++a) {
      var n = e[a], i = n.text;
      i === "-" && e[a + 1].text === "-" && (a + 1 < t && e[a + 2].text === "-" ? (e.splice(a, 3, {
        type: "textord",
        mode: "text",
        loc: ve.range(n, e[a + 2]),
        text: "---"
      }), t -= 2) : (e.splice(a, 2, {
        type: "textord",
        mode: "text",
        loc: ve.range(n, e[a + 1]),
        text: "--"
      }), t -= 1)), (i === "'" || i === "`") && e[a + 1].text === i && (e.splice(a, 2, {
        type: "textord",
        mode: "text",
        loc: ve.range(n, e[a + 1]),
        text: i + i
      }), t -= 1);
    }
  }
  /**
   * Parse a single symbol out of the string. Here, we handle single character
   * symbols and special functions like \verb.
   */
  parseSymbol() {
    var e = this.fetch(), t = e.text;
    if (/^\\verb[^a-zA-Z]/.test(t)) {
      this.consume();
      var a = t.slice(5), n = a.charAt(0) === "*";
      if (n && (a = a.slice(1)), a.length < 2 || a.charAt(0) !== a.slice(-1))
        throw new k(`\\verb assertion failed --
                    please report what input caused this bug`);
      return a = a.slice(1, -1), {
        type: "verb",
        mode: "text",
        body: a,
        star: n
      };
    }
    na.hasOwnProperty(t[0]) && !K[this.mode][t[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + t[0] + '" used in math mode', e), t = na[t[0]] + t.slice(1));
    var i = cs.exec(t);
    i && (t = t.substring(0, i.index), t === "i" ? t = "\u0131" : t === "j" && (t = "\u0237"));
    var l;
    if (K[this.mode][t]) {
      this.settings.strict && this.mode === "math" && Lt.includes(t) && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + t[0] + '" used in math mode', e);
      var u = K[this.mode][t].group, h = ve.range(e), f;
      if (ci.hasOwnProperty(u)) {
        var v = u;
        f = {
          type: "atom",
          mode: this.mode,
          family: v,
          loc: h,
          text: t
        };
      } else
        f = {
          type: u,
          mode: this.mode,
          loc: h,
          text: t
        };
      l = f;
    } else if (t.charCodeAt(0) >= 128)
      this.settings.strict && (fa(t.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + t[0] + '" used in math mode', e) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + t[0] + '"' + (" (" + t.charCodeAt(0) + ")"), e)), l = {
        type: "textord",
        mode: "text",
        loc: ve.range(e),
        text: t
      };
    else
      return null;
    if (this.consume(), i)
      for (var b = 0; b < i[0].length; b++) {
        var y = i[0][b];
        if (!Ft[y])
          throw new k("Unknown accent ' " + y + "'", e);
        var x = Ft[y][this.mode] || Ft[y].text;
        if (!x)
          throw new k("Accent " + y + " unsupported in " + this.mode + " mode", e);
        l = {
          type: "accent",
          mode: this.mode,
          loc: ve.range(e),
          label: x,
          isStretchy: !1,
          isShifty: !0,
          // $FlowFixMe
          base: l
        };
      }
    return l;
  }
}
ut.endOfExpression = /* @__PURE__ */ new Set(["}", "\\endgroup", "\\end", "\\right", "&"]);
var vs = function(e, t) {
  if (!(typeof e == "string" || e instanceof String))
    throw new TypeError("KaTeX can only parse string typed expression");
  var a = new ut(e, t);
  delete a.gullet.macros.current["\\df@tag"];
  var n = a.parse();
  if (delete a.gullet.macros.current["\\current@color"], delete a.gullet.macros.current["\\color"], a.gullet.macros.get("\\df@tag")) {
    if (!t.displayMode)
      throw new k("\\tag works only in display equations");
    n = [{
      type: "tag",
      mode: "text",
      body: n,
      tag: a.subparse([new be("\\df@tag")])
    }];
  }
  return n;
};
typeof document < "u" && document.compatMode !== "CSS1Compat" && typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype.");
var gs = function(e, t) {
  var a = ys(e, t).toMarkup();
  return a;
}, bs = function(e, t, a) {
  if (a.throwOnError || !(e instanceof k))
    throw e;
  var n = S(["katex-error"], [new Me(t)]);
  return n.setAttribute("title", e.toString()), n.setAttribute("style", "color:" + a.errorColor), n;
}, ys = function(e, t) {
  var a = new Pn(t);
  try {
    var n = vs(e, a);
    return Ei(n, e, a);
  } catch (i) {
    return bs(i, e, a);
  }
};
const xs = {
  "+": "+",
  "-": "-",
  "=": "=",
  "<": "<",
  ">": ">",
  // Relations
  "\u2264": "\\le",
  "\u2265": "\\ge",
  "\u2260": "\\ne",
  "\u2248": "\\approx",
  "\u223C": "\\sim",
  "\u2243": "\\simeq",
  "\u2245": "\\cong",
  "\u2261": "\\equiv",
  "\u221D": "\\propto",
  "\u226A": "\\ll",
  "\u226B": "\\gg",
  "\u227A": "\\prec",
  "\u227B": "\\succ",
  "\u2288": "\\nsubseteq",
  "\u2289": "\\nsupseteq",
  "\u2225": "\\parallel",
  "\u2226": "\\nparallel",
  "\u2250": "\\doteq",
  "\u22A7": "\\models",
  // Arithmetic
  "\xB1": "\\pm",
  "\u2213": "\\mp",
  "\xF7": "\\div",
  "\xD7": "\\times",
  "\xB7": "\\cdot",
  "\u2217": "\\ast",
  "\u22C6": "\\star",
  "\u2218": "\\circ",
  "\u2022": "\\bullet",
  "\u2299": "\\odot",
  "\u2295": "\\oplus",
  "\u2297": "\\otimes",
  "\u2020": "\\dagger",
  "\u2021": "\\ddagger",
  // Large operators
  "\u221E": "\\infty",
  "\u2211": "\\sum",
  "\u220F": "\\prod",
  "\u2210": "\\coprod",
  "\u222B": "\\int",
  "\u222C": "\\iint",
  "\u222D": "\\iiint",
  "\u222E": "\\oint",
  "\u22C3": "\\bigcup",
  "\u22C2": "\\bigcap",
  "\u2A01": "\\bigoplus",
  "\u2A02": "\\bigotimes",
  "\u2A04": "\\biguplus",
  "\u2A06": "\\bigsqcup",
  "\u22C1": "\\bigvee",
  "\u22C0": "\\bigwedge",
  // Calculus
  "\u2202": "\\partial",
  "\u2207": "\\nabla",
  // Set theory / logic
  "\u2208": "\\in",
  "\u2209": "\\notin",
  "\u220B": "\\ni",
  "\u2282": "\\subset",
  "\u2286": "\\subseteq",
  "\u2283": "\\supset",
  "\u2287": "\\supseteq",
  "\u222A": "\\cup",
  "\u2229": "\\cap",
  "\u2216": "\\setminus",
  "\u2227": "\\land",
  "\u2228": "\\lor",
  "\xAC": "\\neg",
  "\u22A5": "\\perp",
  "\u22A4": "\\top",
  "\u2205": "\\emptyset",
  "\u2200": "\\forall",
  "\u2203": "\\exists",
  "\u2204": "\\nexists",
  "\u2234": "\\therefore",
  "\u2235": "\\because",
  "\u2220": "\\angle",
  // Arrows
  "\u2192": "\\to",
  "\u2190": "\\leftarrow",
  "\u2194": "\\leftrightarrow",
  "\u21D2": "\\Rightarrow",
  "\u21D0": "\\Leftarrow",
  "\u21D4": "\\Leftrightarrow",
  "\u21A6": "\\mapsto",
  "\u21AA": "\\hookrightarrow",
  "\u21A9": "\\hookleftarrow",
  "\u2191": "\\uparrow",
  "\u2193": "\\downarrow",
  "\u2195": "\\updownarrow",
  "\u27F6": "\\longrightarrow",
  "\u27F5": "\\longleftarrow",
  "\u27F7": "\\longleftrightarrow",
  "\u2197": "\\nearrow",
  "\u2198": "\\searrow",
  "\u2199": "\\swarrow",
  "\u2196": "\\nwarrow",
  "\u21C0": "\\rightharpoonup",
  "\u21BC": "\\leftharpoonup",
  "\u27F9": "\\implies",
  "\u27F8": "\\impliedby",
  "\u27FA": "\\iff",
  // Delimiters
  "\u27E8": "\\langle",
  "\u27E9": "\\rangle",
  "\u230A": "\\lfloor",
  "\u230B": "\\rfloor",
  "\u2308": "\\lceil",
  "\u2309": "\\rceil",
  "\u2016": "\\Vert",
  // Dots
  "\u22EF": "\\cdots",
  "\u22EE": "\\vdots",
  "\u2026": "\\ldots",
  "\u22F1": "\\ddots"
}, ia = {
  \u03B1: "\\alpha",
  \u03B2: "\\beta",
  \u03B3: "\\gamma",
  \u03B4: "\\delta",
  \u03B5: "\\epsilon",
  \u03B6: "\\zeta",
  \u03B7: "\\eta",
  \u03B8: "\\theta",
  \u03D1: "\\vartheta",
  \u03B9: "\\iota",
  \u03BA: "\\kappa",
  \u03BB: "\\lambda",
  \u03BC: "\\mu",
  \u03BD: "\\nu",
  \u03BE: "\\xi",
  \u03C0: "\\pi",
  \u03D6: "\\varpi",
  \u03C1: "\\rho",
  \u03F1: "\\varrho",
  \u03C3: "\\sigma",
  \u03C2: "\\varsigma",
  \u03C4: "\\tau",
  \u03C5: "\\upsilon",
  \u03A5: "\\Upsilon",
  \u03C6: "\\phi",
  \u03C7: "\\chi",
  \u03C8: "\\psi",
  \u03C9: "\\omega",
  \u0393: "\\Gamma",
  \u0394: "\\Delta",
  \u0398: "\\Theta",
  \u039B: "\\Lambda",
  \u039E: "\\Xi",
  \u03A0: "\\Pi",
  \u03A3: "\\Sigma",
  \u03A6: "\\Phi",
  \u03A8: "\\Psi",
  \u03A9: "\\Omega"
};
function dr(r) {
  return r.replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&amp;", "&").replaceAll("&quot;", '"').replaceAll("&#39;", "'").replaceAll("&nbsp;", " ");
}
function Ee(r) {
  return r.replace(/\s+/g, " ").trim();
}
function ws(r) {
  return r.replaceAll("\\", "\\textbackslash{}").replaceAll("{", "\\{").replaceAll("}", "\\}").replaceAll("_", "\\_").replaceAll("^", "\\^{}").replaceAll("#", "\\#").replaceAll("%", "\\%").replaceAll("&", "\\&").replaceAll("$", "\\$");
}
function Ss(r) {
  const e = /<annotation[^>]*encoding=["'](?:application\/x-tex|application\/tex|tex|latex)["'][^>]*>([\s\S]*?)<\/annotation>/i, t = r.match(e);
  return t?.[1] ? dr(t[1]).trim() : null;
}
function As(r) {
  const e = r.trim().replace(/^</, "").replace(/>$/, "").trim();
  if (!e || e.startsWith("/") || e.startsWith("!"))
    return null;
  const t = e.endsWith("/"), a = t ? e.slice(0, -1).trim() : e, n = a.match(/^([a-zA-Z0-9:_-]+)/);
  if (!n)
    return null;
  const i = n[1];
  if (!i)
    return null;
  const l = i.toLowerCase(), u = {}, h = a.slice(n[0].length), f = /([a-zA-Z_:][a-zA-Z0-9:_.-]*)\s*=\s*["']([^"']*)["']/g;
  for (const v of h.matchAll(f)) {
    const b = v[1]?.toLowerCase();
    b && (u[b] = dr(v[2] ?? ""));
  }
  return { name: l, attributes: u, selfClosing: t };
}
function ks(r) {
  const e = { name: "root", attributes: {}, children: [], text: "" }, t = [e], a = r.match(/<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<\/?[^>]+>|[^<]+/g) ?? [];
  for (const n of a) {
    if (!n || n.startsWith("<!--") || n.startsWith("<?"))
      continue;
    if (n.startsWith("</")) {
      t.length > 1 && t.pop();
      continue;
    }
    if (n.startsWith("<")) {
      const u = As(n);
      if (!u)
        continue;
      const h = {
        name: u.name,
        attributes: u.attributes,
        children: [],
        text: ""
      };
      t[t.length - 1]?.children.push(h), u.selfClosing || t.push(h);
      continue;
    }
    const i = dr(n);
    if (!Ee(i))
      continue;
    const l = t[t.length - 1];
    l && l.children.push({
      name: "#text",
      attributes: {},
      children: [],
      text: i
    });
  }
  return e.children.find((n) => n.name === "math" || n.name === "semantics") ?? e.children[0] ?? null;
}
function A0(r) {
  return Ee(r.children.map(W).join(" ")).trim();
}
function Ts(r) {
  return r.children.filter((e) => e.name !== "annotation" && e.name !== "annotation-xml");
}
function Ms(r) {
  const e = r.children.filter((a) => a.name === "mtr");
  return e.length === 0 ? A0(r) : e.map((a) => a.children.filter((i) => i.name === "mtd").map((i) => A0(i)).join(" & ")).join(" \\\\ ");
}
function W(r) {
  if (r.name === "#text")
    return Ee(r.text);
  if (r.name === "annotation")
    return (r.attributes.encoding ?? "").toLowerCase().includes("tex") ? Ee(r.children.map(W).join("")) : "";
  if (r.name === "annotation-xml")
    return "";
  switch (r.name) {
    case "math":
    case "semantics":
      return Ee(Ts(r).map(W).join(" "));
    case "mrow":
    case "mstyle":
      return r.children.map(W).join(" ");
    case "mi": {
      const e = Ee(r.children.map(W).join(""));
      return ia[e] ?? e;
    }
    case "mn":
      return Ee(r.children.map(W).join(""));
    case "mo": {
      const e = Ee(r.children.map(W).join(""));
      return xs[e] ?? ia[e] ?? e;
    }
    case "mtext": {
      const e = Ee(r.children.map(W).join(" "));
      return e ? `\\text{${ws(e)}}` : "";
    }
    case "mfrac": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "";
      return `\\frac{${e}}{${t}}`;
    }
    case "msqrt":
      return `\\sqrt{${A0(r)}}`;
    case "mroot": {
      const e = r.children[0] ? W(r.children[0]) : "";
      return `\\sqrt[${r.children[1] ? W(r.children[1]) : ""}]{${e}}`;
    }
    case "msup": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "";
      return `${e}^{${t}}`;
    }
    case "msub": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "";
      return `${e}_{${t}}`;
    }
    case "msubsup": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "", a = r.children[2] ? W(r.children[2]) : "";
      return `${e}_{${t}}^{${a}}`;
    }
    case "munder": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "";
      return `${e}_{${t}}`;
    }
    case "mover": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "";
      return `${e}^{${t}}`;
    }
    case "munderover": {
      const e = r.children[0] ? W(r.children[0]) : "", t = r.children[1] ? W(r.children[1]) : "", a = r.children[2] ? W(r.children[2]) : "";
      return `${e}_{${t}}^{${a}}`;
    }
    case "mtable":
      return `\\begin{matrix} ${Ms(r)} \\end{matrix}`;
    case "mtr":
    case "mtd":
      return A0(r);
    default:
      return A0(r);
  }
}
function Cs(r) {
  const e = r.trim();
  if (e.startsWith("<math"))
    return e;
  const t = e.match(/<math[\s>][\s\S]*<\/math>/);
  return t ? t[0] : `<math xmlns="http://www.w3.org/1998/Math/MathML">${e}</math>`;
}
function Es(r) {
  const e = r.trim();
  if (!e)
    return {
      ok: !1,
      error: "LaTeX is empty."
    };
  try {
    const t = gs(e, {
      output: "mathml",
      throwOnError: !0,
      strict: !1
    });
    return {
      ok: !0,
      value: Cs(t)
    };
  } catch (t) {
    return {
      ok: !1,
      error: t instanceof Error ? t.message : "Failed to convert LaTeX to MathML."
    };
  }
}
function zs(r) {
  const e = r.trim();
  if (!e)
    return {
      ok: !1,
      error: "MathML is empty."
    };
  const t = Ss(e);
  if (t)
    return { ok: !0, value: t };
  try {
    const a = ks(e);
    if (!a)
      return {
        ok: !1,
        error: "Could not parse MathML."
      };
    const n = Ee(W(a));
    return n ? {
      ok: !0,
      value: n
    } : {
      ok: !1,
      error: "MathML conversion produced an empty LaTeX result."
    };
  } catch (a) {
    return {
      ok: !1,
      error: a instanceof Error ? a.message : "Failed to convert MathML to LaTeX."
    };
  }
}
function Ds(r) {
  const e = [];
  let t = "", a = 0;
  const n = [];
  for (let i = 0; i < r.length; ) {
    const l = r.slice(i).match(/^\\begin\{([A-Za-z*]+)\}/);
    if (l) {
      n.push(l[1] ?? ""), t += l[0], i += l[0].length;
      continue;
    }
    const u = r.slice(i).match(/^\\end\{([A-Za-z*]+)\}/);
    if (u) {
      const v = u[1] ?? "";
      n[n.length - 1] === v && n.pop(), t += u[0], i += u[0].length;
      continue;
    }
    const h = r[i], f = r[i + 1];
    if (h === "{") {
      a += 1, t += h, i += 1;
      continue;
    }
    if (h === "}") {
      a = Math.max(0, a - 1), t += h, i += 1;
      continue;
    }
    if (h === "\\" && f === "\\" && a === 0 && n.length === 0) {
      for (e.push(t.trim()), t = "", i += 2; i < r.length && r[i] === " "; )
        i += 1;
      if (i < r.length && r[i] === "[") {
        const v = r.indexOf("]", i);
        v !== -1 && (i = v + 1);
      }
      continue;
    }
    t += h, i += 1;
  }
  return e.push(t.trim()), e.filter((i) => i.length > 0);
}
function Rs(r) {
  const e = r.trim();
  if (!e) {
    const n = x0("");
    return {
      ok: !0,
      value: n.ok ? n.value : d0()
    };
  }
  const t = Ds(e), a = [];
  for (const n of t) {
    const i = Es(n);
    if (!i.ok)
      return {
        ok: !1,
        error: i.error
      };
    const l = x0(i.value);
    if (!l.ok)
      return l;
    a.push(...l.value.rows);
  }
  return {
    ok: !0,
    value: d0(a)
  };
}
const Fs = {
  // Lowercase Greek
  "\\alpha": { value: "\u03B1", role: "identifier" },
  "\\beta": { value: "\u03B2", role: "identifier" },
  "\\gamma": { value: "\u03B3", role: "identifier" },
  "\\delta": { value: "\u03B4", role: "identifier" },
  "\\epsilon": { value: "\u03B5", role: "identifier" },
  "\\varepsilon": { value: "\u03B5", role: "identifier" },
  "\\zeta": { value: "\u03B6", role: "identifier" },
  "\\eta": { value: "\u03B7", role: "identifier" },
  "\\theta": { value: "\u03B8", role: "identifier" },
  "\\vartheta": { value: "\u03D1", role: "identifier" },
  "\\iota": { value: "\u03B9", role: "identifier" },
  "\\kappa": { value: "\u03BA", role: "identifier" },
  "\\lambda": { value: "\u03BB", role: "identifier" },
  "\\mu": { value: "\u03BC", role: "identifier" },
  "\\nu": { value: "\u03BD", role: "identifier" },
  "\\xi": { value: "\u03BE", role: "identifier" },
  "\\pi": { value: "\u03C0", role: "identifier" },
  "\\varpi": { value: "\u03D6", role: "identifier" },
  "\\rho": { value: "\u03C1", role: "identifier" },
  "\\varrho": { value: "\u03F1", role: "identifier" },
  "\\sigma": { value: "\u03C3", role: "identifier" },
  "\\varsigma": { value: "\u03C2", role: "identifier" },
  "\\tau": { value: "\u03C4", role: "identifier" },
  "\\upsilon": { value: "\u03C5", role: "identifier" },
  "\\phi": { value: "\u03C6", role: "identifier" },
  "\\varphi": { value: "\u03C6", role: "identifier" },
  "\\chi": { value: "\u03C7", role: "identifier" },
  "\\psi": { value: "\u03C8", role: "identifier" },
  "\\omega": { value: "\u03C9", role: "identifier" },
  // Uppercase Greek
  "\\Gamma": { value: "\u0393", role: "identifier" },
  "\\Delta": { value: "\u0394", role: "identifier" },
  "\\Theta": { value: "\u0398", role: "identifier" },
  "\\Lambda": { value: "\u039B", role: "identifier" },
  "\\Xi": { value: "\u039E", role: "identifier" },
  "\\Pi": { value: "\u03A0", role: "identifier" },
  "\\Sigma": { value: "\u03A3", role: "identifier" },
  "\\Upsilon": { value: "\u03A5", role: "identifier" },
  "\\Phi": { value: "\u03A6", role: "identifier" },
  "\\Psi": { value: "\u03A8", role: "identifier" },
  "\\Omega": { value: "\u03A9", role: "identifier" },
  // Relations
  "\\le": { value: "\u2264", role: "operator" },
  "\\leq": { value: "\u2264", role: "operator" },
  "\\ge": { value: "\u2265", role: "operator" },
  "\\geq": { value: "\u2265", role: "operator" },
  "\\ne": { value: "\u2260", role: "operator" },
  "\\neq": { value: "\u2260", role: "operator" },
  "\\approx": { value: "\u2248", role: "operator" },
  "\\sim": { value: "\u223C", role: "operator" },
  "\\simeq": { value: "\u2243", role: "operator" },
  "\\cong": { value: "\u2245", role: "operator" },
  "\\equiv": { value: "\u2261", role: "operator" },
  "\\propto": { value: "\u221D", role: "operator" },
  "\\ll": { value: "\u226A", role: "operator" },
  "\\gg": { value: "\u226B", role: "operator" },
  "\\prec": { value: "\u227A", role: "operator" },
  "\\succ": { value: "\u227B", role: "operator" },
  "\\nsubseteq": { value: "\u2288", role: "operator" },
  "\\nsupseteq": { value: "\u2289", role: "operator" },
  "\\parallel": { value: "\u2225", role: "operator" },
  "\\nparallel": { value: "\u2226", role: "operator" },
  "\\doteq": { value: "\u2250", role: "operator" },
  "\\models": { value: "\u22A7", role: "operator" },
  // Arithmetic
  "\\pm": { value: "\xB1", role: "operator" },
  "\\mp": { value: "\u2213", role: "operator" },
  "\\div": { value: "\xF7", role: "operator" },
  "\\times": { value: "\xD7", role: "operator" },
  "\\cdot": { value: "\xB7", role: "operator" },
  "\\ast": { value: "\u2217", role: "operator" },
  "\\star": { value: "\u22C6", role: "operator" },
  "\\circ": { value: "\u2218", role: "operator" },
  "\\bullet": { value: "\u2022", role: "operator" },
  "\\odot": { value: "\u2299", role: "operator" },
  "\\oplus": { value: "\u2295", role: "operator" },
  "\\otimes": { value: "\u2297", role: "operator" },
  "\\dagger": { value: "\u2020", role: "operator" },
  "\\ddagger": { value: "\u2021", role: "operator" },
  // Large operators
  "\\infty": { value: "\u221E", role: "operator" },
  "\\sum": { value: "\u2211", role: "operator" },
  "\\prod": { value: "\u220F", role: "operator" },
  "\\coprod": { value: "\u2210", role: "operator" },
  "\\int": { value: "\u222B", role: "operator" },
  "\\iint": { value: "\u222C", role: "operator" },
  "\\iiint": { value: "\u222D", role: "operator" },
  "\\oint": { value: "\u222E", role: "operator" },
  "\\bigcup": { value: "\u22C3", role: "operator" },
  "\\bigcap": { value: "\u22C2", role: "operator" },
  "\\bigoplus": { value: "\u2A01", role: "operator" },
  "\\bigotimes": { value: "\u2A02", role: "operator" },
  "\\biguplus": { value: "\u2A04", role: "operator" },
  "\\bigsqcup": { value: "\u2A06", role: "operator" },
  "\\bigvee": { value: "\u22C1", role: "operator" },
  "\\bigwedge": { value: "\u22C0", role: "operator" },
  // Calculus / analysis
  "\\partial": { value: "\u2202", role: "operator" },
  "\\nabla": { value: "\u2207", role: "operator" },
  // Set theory / logic
  "\\in": { value: "\u2208", role: "operator" },
  "\\notin": { value: "\u2209", role: "operator" },
  "\\ni": { value: "\u220B", role: "operator" },
  "\\subset": { value: "\u2282", role: "operator" },
  "\\subseteq": { value: "\u2286", role: "operator" },
  "\\supset": { value: "\u2283", role: "operator" },
  "\\supseteq": { value: "\u2287", role: "operator" },
  "\\cup": { value: "\u222A", role: "operator" },
  "\\cap": { value: "\u2229", role: "operator" },
  "\\setminus": { value: "\u2216", role: "operator" },
  "\\land": { value: "\u2227", role: "operator" },
  "\\lor": { value: "\u2228", role: "operator" },
  "\\neg": { value: "\xAC", role: "operator" },
  "\\perp": { value: "\u22A5", role: "operator" },
  "\\top": { value: "\u22A4", role: "operator" },
  "\\bot": { value: "\u22A5", role: "operator" },
  "\\emptyset": { value: "\u2205", role: "operator" },
  "\\varnothing": { value: "\u2205", role: "operator" },
  "\\forall": { value: "\u2200", role: "operator" },
  "\\exists": { value: "\u2203", role: "operator" },
  "\\nexists": { value: "\u2204", role: "operator" },
  "\\therefore": { value: "\u2234", role: "operator" },
  "\\because": { value: "\u2235", role: "operator" },
  "\\angle": { value: "\u2220", role: "operator" },
  // Arrows
  "\\to": { value: "\u2192", role: "operator" },
  "\\rightarrow": { value: "\u2192", role: "operator" },
  "\\leftarrow": { value: "\u2190", role: "operator" },
  "\\gets": { value: "\u2190", role: "operator" },
  "\\leftrightarrow": { value: "\u2194", role: "operator" },
  "\\Rightarrow": { value: "\u21D2", role: "operator" },
  "\\Leftarrow": { value: "\u21D0", role: "operator" },
  "\\Leftrightarrow": { value: "\u21D4", role: "operator" },
  "\\mapsto": { value: "\u21A6", role: "operator" },
  "\\hookrightarrow": { value: "\u21AA", role: "operator" },
  "\\hookleftarrow": { value: "\u21A9", role: "operator" },
  "\\uparrow": { value: "\u2191", role: "operator" },
  "\\downarrow": { value: "\u2193", role: "operator" },
  "\\updownarrow": { value: "\u2195", role: "operator" },
  "\\longrightarrow": { value: "\u27F6", role: "operator" },
  "\\longleftarrow": { value: "\u27F5", role: "operator" },
  "\\longleftrightarrow": { value: "\u27F7", role: "operator" },
  "\\nearrow": { value: "\u2197", role: "operator" },
  "\\searrow": { value: "\u2198", role: "operator" },
  "\\swarrow": { value: "\u2199", role: "operator" },
  "\\nwarrow": { value: "\u2196", role: "operator" },
  "\\rightharpoonup": { value: "\u21C0", role: "operator" },
  "\\leftharpoonup": { value: "\u21BC", role: "operator" },
  "\\implies": { value: "\u27F9", role: "operator" },
  "\\impliedby": { value: "\u27F8", role: "operator" },
  "\\iff": { value: "\u27FA", role: "operator" },
  // Delimiters (single tokens)
  "\\vert": { value: "|", role: "operator" },
  "\\Vert": { value: "\u2016", role: "operator" },
  "\\langle": { value: "\u27E8", role: "operator" },
  "\\rangle": { value: "\u27E9", role: "operator" },
  "\\lparen": { value: "(", role: "operator" },
  "\\rparen": { value: ")", role: "operator" },
  "\\lbrack": { value: "[", role: "operator" },
  "\\rbrack": { value: "]", role: "operator" },
  "\\lbrace": { value: "{", role: "operator" },
  "\\rbrace": { value: "}", role: "operator" },
  "\\lfloor": { value: "\u230A", role: "operator" },
  "\\rfloor": { value: "\u230B", role: "operator" },
  "\\lceil": { value: "\u2308", role: "operator" },
  "\\rceil": { value: "\u2309", role: "operator" },
  // Dots
  "\\cdots": { value: "\u22EF", role: "operator" },
  "\\vdots": { value: "\u22EE", role: "operator" },
  "\\ldots": { value: "\u2026", role: "operator" },
  "\\ddots": { value: "\u22F1", role: "operator" },
  // Misc
  "\\%": { value: "%", role: "text" },
  // Functions
  "\\sin": { value: "sin", role: "function" },
  "\\cos": { value: "cos", role: "function" },
  "\\tan": { value: "tan", role: "function" },
  "\\cot": { value: "cot", role: "function" },
  "\\sec": { value: "sec", role: "function" },
  "\\csc": { value: "csc", role: "function" },
  "\\log": { value: "log", role: "function" },
  "\\ln": { value: "ln", role: "function" },
  "\\exp": { value: "exp", role: "function" },
  "\\lim": { value: "lim", role: "function" },
  "\\limsup": { value: "lim sup", role: "function" },
  "\\liminf": { value: "lim inf", role: "function" }
}, Is = /* @__PURE__ */ new Set(["+", "-", "=", "<", ">", "(", ")", "[", "]", "{", "}", "|", ",", ".", ":"]);
function ln(r) {
  return r.trim().replace(/^\$+|\$+$/g, "").trim();
}
function Xt(r) {
  const e = ln(r);
  if (!e)
    return null;
  const t = Fs[e];
  return t ? Se(t.value, t.role) : e.length === 1 ? Se(e) : /^[a-zA-Z]+$/.test(e) ? Se(e, e.length > 1 ? "function" : "identifier") : null;
}
function Bs(r) {
  const e = ln(r);
  if (!e)
    return [];
  const t = [];
  for (let a = 0; a < e.length; ) {
    const n = e[a];
    if (!n)
      break;
    if (/\s/.test(n)) {
      a += 1;
      continue;
    }
    if (n === "\\") {
      const l = e.slice(a).match(/^\\[A-Za-z]+/);
      if (!l?.[0])
        return null;
      const u = Xt(l[0]);
      if (!u)
        return null;
      t.push(u), a += l[0].length;
      continue;
    }
    if (/[0-9]/.test(n)) {
      let l = a + 1;
      for (; l < e.length && /[0-9]/.test(e[l] ?? ""); )
        l += 1;
      t.push(Se(e.slice(a, l), "number")), a = l;
      continue;
    }
    if (/[a-zA-Z]/.test(n)) {
      t.push(Se(n, "identifier")), a += 1;
      continue;
    }
    if (Is.has(n)) {
      t.push(Se(n, "operator")), a += 1;
      continue;
    }
    const i = Xt(n);
    if (i) {
      t.push(i), a += 1;
      continue;
    }
    return null;
  }
  return t;
}
function Ns(r) {
  const a = (r.match(/\\begin\{[A-Za-z]+\}(?:\{[^}]*\})?\s*([\s\S]*?)\s*\\end\{/)?.[1] ?? "").split(/\\\\/).map((i) => i.trim()).filter(Boolean), n = Math.max(
    1,
    ...a.map((i) => i.split("&").map((l) => l.trim()).filter(Boolean).length)
  );
  return {
    rows: Math.max(1, a.length || 1),
    cols: n
  };
}
function qs(r) {
  return r.resizableGrid?.env ? r.resizableGrid.env : (r.template?.match(/\\begin\{([A-Za-z]+)\}/) ?? r.latex.match(/\\begin\{([A-Za-z]+)\}/))?.[1] ?? null;
}
function Os(r) {
  if (r.canvasOperation)
    return r.canvasOperation;
  const t = (r.template ? da(r.template, r.placeholderFill ?? "x").text : null) ?? r.latex;
  if (r.resizableGrid || r.semanticKind === "matrix" || /\\begin\{(?:p|b|B|v|V)?matrix|\\begin\{array/.test(t)) {
    const n = qs(r) ?? "matrix", i = Ns(t);
    return {
      type: "insert-matrix",
      rows: i.rows,
      cols: i.cols,
      environment: n
    };
  }
  if (r.semanticKind === "fraction" || /\\(?:d|t|c)?frac/.test(t))
    return { type: "insert-fraction" };
  if (r.semanticKind === "root" || /\\sqrt/.test(t))
    return { type: "insert-root", indexed: t.includes("[") };
  if (r.semanticKind === "delimiter" && r.latex.length === 2)
    return {
      type: "insert-delimited",
      left: r.latex[0] ?? "(",
      right: r.latex[1] ?? ")"
    };
  if (t.length === 1)
    return {
      type: "insert-token",
      token: Se(t)
    };
  const a = Xt(t);
  return a ? {
    type: "insert-token",
    token: a
  } : null;
}
function Ls(r) {
  if (r.mathmlTemplate) {
    const n = x0(r.mathmlTemplate);
    if (n.ok)
      return n.value;
  }
  if (r.mathmlFragment) {
    const n = x0(r.mathmlFragment);
    if (n.ok)
      return n.value;
  }
  if (r.sampleMathml && !r.sampleMathml.includes('mathcolor="#cc0000"')) {
    const n = x0(r.sampleMathml);
    if (n.ok)
      return n.value;
  }
  const e = r.template ? da(r.template, r.placeholderFill ?? "x").text : r.latex, t = Bs(e);
  if (t)
    return d0([le(t)]);
  const a = Rs(e);
  return a.ok ? a.value : null;
}
function Ps(r) {
  const [e, t] = r.split(",", 2), n = (e ?? "").match(/data:([^;]+);base64/)?.[1] ?? "image/png", i = atob(t ?? ""), l = new Uint8Array(i.length);
  for (let u = 0; u < i.length; u += 1)
    l[u] = i.charCodeAt(u);
  return new Blob([l], { type: n });
}
function un() {
  if (typeof ClipboardItem > "u")
    return !1;
  const r = ClipboardItem;
  return typeof r.supports != "function" ? !0 : r.supports("image/svg+xml");
}
function Hs(r, e) {
  return r === "image-svg" && un() && e.svgBlob && e.svgDataUrl ? [
    {
      mimeType: "image/svg+xml",
      blob: e.svgBlob,
      dataUrl: e.svgDataUrl
    },
    ...e.pngBlob && e.pngDataUrl ? [
      {
        mimeType: "image/png",
        blob: e.pngBlob,
        dataUrl: e.pngDataUrl
      }
    ] : []
  ] : e.pngBlob && e.pngDataUrl ? [
    {
      mimeType: "image/png",
      blob: e.pngBlob,
      dataUrl: e.pngDataUrl
    }
  ] : [];
}
function Gs(r, e) {
  if (!e)
    return !1;
  const t = "nodeType" in e && e.nodeType === 1 ? e : null;
  return t ? t === r || r.contains(t) : e.parentElement !== null && (e.parentElement === r || r.contains(e.parentElement));
}
function Wt(r, e, t = Date.now()) {
  return !r || !e || !Gs(r, e.commonAncestorContainer) ? null : {
    target: r,
    range: e.cloneRange(),
    capturedAt: t
  };
}
function Us(r, e, t = Date.now()) {
  return !r || !e || e.rangeCount === 0 ? null : Wt(r, e.getRangeAt(0), t);
}
function sa(r, e, t, a = Date.now()) {
  const n = Us(e, t, a);
  return n || (!r?.target.isConnected || e && r.target !== e ? null : r);
}
function Vs(r, e) {
  if (!r || !e || !r.target.isConnected)
    return !1;
  try {
    return e.removeAllRanges(), e.addRange(r.range), !0;
  } catch {
    return !1;
  }
}
function cn(r) {
  return !r || r.closest(".notion-page-content") ? !1 : !!r.closest(".notion-app-inner");
}
const Yt = /* @__PURE__ */ new WeakMap();
let oe = null, oa = !1, It = null;
function hn() {
  oa || (document.addEventListener(
    "keydown",
    (r) => {
      if (r.key !== "Tab")
        return;
      const e = document.activeElement;
      if (!e)
        return;
      if (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement) {
        const l = Yt.get(e);
        if (!l || l.slots.length === 0)
          return;
        r.preventDefault();
        const u = r.shiftKey ? -1 : 1;
        l.index = (l.index + u + l.slots.length) % l.slots.length;
        const h = l.slots[l.index];
        if (!h)
          return;
        e.setSelectionRange(h.start, h.end);
        return;
      }
      if (!oe || !(e instanceof HTMLElement) || !oe.root.contains(e))
        return;
      if (!oe.textNode.isConnected || oe.slots.length === 0) {
        oe = null;
        return;
      }
      r.preventDefault();
      const t = r.shiftKey ? -1 : 1;
      oe.index = (oe.index + t + oe.slots.length) % oe.slots.length;
      const a = oe.slots[oe.index];
      if (!a)
        return;
      const n = window.getSelection();
      if (!n)
        return;
      const i = document.createRange();
      i.setStart(oe.textNode, Math.min(a.start, oe.textNode.length)), i.setEnd(oe.textNode, Math.min(a.end, oe.textNode.length)), n.removeAllRanges(), n.addRange(i);
    },
    !0
  ), oa = !0);
}
function mn(r) {
  return r.isContentEditable ? r : r.closest("[contenteditable='true']") ?? r;
}
function $s(r, e, t) {
  if (t.length === 0) {
    Yt.delete(r);
    return;
  }
  const a = t.map((i) => ({
    ...i,
    start: i.start + e,
    end: i.end + e
  }));
  Yt.set(r, {
    slots: a,
    index: 0
  });
  const n = a[0];
  n && r.setSelectionRange(n.start, n.end);
}
function Xs(r, e) {
  const t = r.selectionStart ?? r.value.length, a = r.selectionEnd ?? t;
  if (r.setRangeText(e.text, t, a, "end"), $s(r, t, e.slots), e.slots.length === 0) {
    const n = t + e.text.length;
    r.setSelectionRange(n, n);
  }
  return r.dispatchEvent(new InputEvent("input", { bubbles: !0, data: e.text })), !0;
}
function Ws(r, e) {
  const t = mn(r);
  t.focus();
  const a = window.getSelection();
  if (!a)
    return { inserted: !1 };
  if (a.rangeCount === 0) {
    const v = document.createRange();
    v.selectNodeContents(t), v.collapse(!1), a.addRange(v);
  }
  const n = a.getRangeAt(0);
  n.deleteContents();
  const i = document.createTextNode(e.text);
  n.insertNode(i);
  const l = document.createRange();
  l.setStart(i, 0), l.setEnd(i, i.length);
  const u = Wt(t, l), h = document.createRange();
  if (e.slots.length > 0) {
    const v = e.slots[0];
    if (!v)
      return { inserted: !1 };
    h.setStart(i, Math.min(v.start, i.length)), h.setEnd(i, Math.min(v.end, i.length)), oe = {
      root: t,
      textNode: i,
      slots: e.slots,
      index: 0
    };
  } else
    h.setStart(i, i.length), h.collapse(!0), oe = null;
  a.removeAllRanges(), a.addRange(h);
  const f = Wt(t, h);
  return t.dispatchEvent(new InputEvent("input", { bubbles: !0, data: e.text })), {
    inserted: !0,
    insertedSelectionSnapshot: u,
    postInsertSelectionSnapshot: f
  };
}
function Ys(r, e) {
  const t = mn(r);
  t.focus();
  const a = window.getSelection();
  if (!a)
    return !1;
  if (a.rangeCount === 0) {
    const u = document.createRange();
    u.selectNodeContents(t), u.collapse(!1), a.addRange(u);
  }
  const n = a.getRangeAt(0);
  n.deleteContents();
  const i = document.createElement("img");
  i.src = e, i.alt = "KaTeX expression", i.style.maxWidth = "100%", i.style.height = "auto", i.style.verticalAlign = "middle", n.insertNode(i);
  const l = document.createRange();
  return l.setStartAfter(i), l.collapse(!0), a.removeAllRanges(), a.addRange(l), oe = null, t.dispatchEvent(new InputEvent("input", { bubbles: !0 })), !0;
}
async function Ks(r) {
  if (!navigator.clipboard?.writeText)
    return !1;
  try {
    return await navigator.clipboard.writeText(r), !0;
  } catch {
    return !1;
  }
}
async function la(r, e, t, a) {
  hn();
  const n = js(r, e);
  return dn(n, t, a);
}
async function _s(r, e, t) {
  return hn(), dn({
    text: r,
    slots: []
  }, e, t);
}
function js(r, e) {
  return {
    text: An(r, e),
    slots: []
  };
}
async function dn(r, e, t) {
  let a = !1, n, i;
  if (e instanceof HTMLInputElement || e instanceof HTMLTextAreaElement)
    a = Xs(e, r);
  else if (e.isContentEditable || e.closest("[contenteditable='true']")) {
    const u = Ws(e, r);
    a = u.inserted, n = u.insertedSelectionSnapshot, i = u.postInsertSelectionSnapshot;
  }
  return a ? {
    ok: !0,
    context: t,
    ...n !== void 0 ? { insertedSelectionSnapshot: n } : {},
    ...i !== void 0 ? { postInsertSelectionSnapshot: i } : {}
  } : await Ks(r.text) ? {
    ok: !0,
    usedClipboard: !0,
    context: t
  } : {
    ok: !1,
    error: "Unable to insert into the current editable field.",
    context: t
  };
}
function ua() {
  const r = Array.from(
    document.querySelectorAll('[role="menu"], [role="listbox"], .notion-scroller.vertical, .notion-overlay-container')
  );
  for (let e = 0; e < r.length; e++) {
    const t = r[e], a = Array.from(
      t.querySelectorAll('[role="option"], [role="menuitem"], .notion-scroller [style*="cursor: pointer"]')
    );
    for (let n = 0; n < a.length; n++) {
      const i = a[n], l = i.textContent?.toLowerCase() ?? "";
      if (l.includes("block equation") || l.includes("equation"))
        return i;
    }
  }
  return null;
}
function ca(r) {
  r.dispatchEvent(
    new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: !0, cancelable: !0 })
  ), r.dispatchEvent(
    new KeyboardEvent("keyup", { key: "Enter", code: "Enter", keyCode: 13, bubbles: !0, cancelable: !0 })
  );
}
function c0(r) {
  return new Promise((e) => setTimeout(e, r));
}
async function Zs(r, e = {}) {
  let t = r;
  e.focusTarget !== !1 && t.focus();
  const a = window.getSelection(), n = Bt(t, a, e.selectionSnapshot ?? null);
  if (e.onTrace?.({ selectionRestoreOk: n.selectionRestoreOk }), !n.normalized)
    return { ok: !1, failureStep: "selection_normalization_failed" };
  if (e.returnBefore !== !1) {
    ca(t), await c0(e.preReturnDelayMs ?? 120);
    const u = e.resolveTargetAfterReturn?.();
    if (Z0(u) && (t = u, t.focus()), e.onTrace?.({ postReturnTargetKind: Kt(t) }), !Bt(t, a, null).normalized)
      return { ok: !1, failureStep: "post_return_selection_lost" };
  } else
    e.onTrace?.({ postReturnTargetKind: Kt(t) });
  e.onTrace?.({ slashInsertAttempted: !0 });
  let i = document.execCommand("insertText", !1, "/equation");
  if (!i) {
    if (e.onTrace?.({ slashInsertRetried: !0 }), t.focus(), !Bt(t, a, null).normalized)
      return { ok: !1, failureStep: "slash_retry_selection_lost" };
    if (await c0(50), i = document.execCommand("insertText", !1, "/equation"), !i)
      return { ok: !1, failureStep: "slash_insert_failed" };
  }
  await c0(e.menuDelayMs ?? 150);
  let l = ua();
  if (l || (await c0(e.menuDelayMs ?? 150), l = ua()), e.onTrace?.({ menuItemFound: !!l }), l)
    l.click();
  else {
    const u = document.activeElement ?? t;
    ca(u);
  }
  return await c0(e.postCommitDelayMs ?? 150), { ok: !0 };
}
async function Js(r, e, t, a = {}) {
  It = {};
  const n = (v) => {
    It = {
      ...It ?? {},
      ...v
    }, a.onTrace?.(v);
  }, i = Qs(t?.target), l = e1(r, i);
  if (n({ entryTargetKind: Kt(l) }), !l)
    return n({ lastFailureStep: "no_body_target" }), {
      ok: !1,
      reason: "Place your cursor in the page body before pasting."
    };
  const u = await Zs(l, {
    focusTarget: !1,
    returnBefore: !0,
    selectionSnapshot: t ?? null,
    onTrace: n,
    resolveTargetAfterReturn: () => {
      const v = e();
      return Z0(v.target) ? v.target : l;
    }
  });
  if (!u.ok)
    return n({ lastFailureStep: u.failureStep ?? "create_equation_failed" }), {
      ok: !1,
      reason: "Failed to create a Notion equation block."
    };
  const h = a.pollAttempts ?? 12, f = a.pollDelayMs ?? 120;
  for (let v = 0; v < h; v += 1) {
    await c0(f);
    const b = e();
    if (b.target && b.context.inMathEditor)
      return n({ mathEditorOpened: !0 }), {
        ok: !0,
        target: b.target,
        context: b.context
      };
  }
  return n({
    mathEditorOpened: !1,
    lastFailureStep: "math_editor_poll_timeout"
  }), {
    ok: !1,
    reason: "Notion did not open a block equation."
  };
}
function Qs(r) {
  return !r || typeof r != "object" || !("isConnected" in r) || !("contains" in r) || !("closest" in r) ? null : r;
}
function Kt(r) {
  return r ? r.isConnected ? cn(r) ? "title" : "body" : "disconnected" : "missing";
}
function Z0(r) {
  return !!(r?.isConnected && !cn(r));
}
function e1(r, e) {
  return Z0(r) ? r : Z0(e) ? e : null;
}
function _t(r, e) {
  if (!e || e.rangeCount === 0)
    return !1;
  const a = e.getRangeAt(0).commonAncestorContainer;
  if (a === r)
    return !0;
  if (typeof Element < "u" && a instanceof Element)
    return r.contains(a);
  const n = "parentElement" in a ? a.parentElement : null;
  return n !== null && (n === r || r.contains(n));
}
function t1(r, e) {
  if (!e || typeof document.createRange != "function")
    return !1;
  try {
    const t = document.createRange();
    return t.selectNodeContents(r), t.collapse(!1), e.removeAllRanges(), e.addRange(t), _t(r, e);
  } catch {
    return !1;
  }
}
function Bt(r, e, t) {
  r.focus();
  let a = _t(r, e);
  return !a && t?.target === r && (Vs(t, e), a = _t(r, e)), a ? {
    selectionRestoreOk: !0,
    normalized: !0
  } : {
    selectionRestoreOk: !1,
    normalized: t1(r, e)
  };
}
function ha(r, e, t) {
  return e.isContentEditable || e.closest("[contenteditable='true']") ? Ys(e, r) ? { ok: !0, context: t } : {
    ok: !1,
    error: "Unable to insert image into the current editable field.",
    context: t
  } : {
    ok: !1,
    error: "Current editor does not support direct image insertion.",
    context: t
  };
}
function r1(r, e) {
  return r ? "raw" : e;
}
const k0 = "katex-canvas-dock", ma = "katex-canvas-dock-style", pn = "katexCanvasSessionV1", a1 = "src/canvas-frame/index.html", n1 = "canvas_boot", jt = "__katexSidebarCanvasDock", i1 = `
#${k0} {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 2147483647;
  height: 360px;
  border-top: 1px solid #86a5c7;
  box-shadow: 0 -8px 24px rgba(8, 22, 45, 0.26);
  background: #f8fbff;
  display: none;
}

#${k0}[data-open="true"] {
  display: block;
}

#${k0} .canvas-dock-frame {
  display: block;
  width: 100%;
  height: 100%;
  border: 0;
  background: #f8fbff;
}
`;
function s1() {
  if (document.getElementById(ma))
    return;
  if (!document.head)
    throw new Error("Failed to mount Canvas dock: missing document.head");
  const r = document.createElement("style");
  r.id = ma, r.textContent = i1, document.head.appendChild(r);
}
function o1() {
  try {
    const r = sessionStorage.getItem(pn);
    if (!r)
      return { mathml: "", latexExport: "", pasteMode: "display" };
    const e = JSON.parse(r);
    return {
      mathml: typeof e.mathml == "string" ? e.mathml : "",
      latexExport: typeof e.latexExport == "string" ? e.latexExport : "",
      pasteMode: e.pasteMode === "inline" ? "inline" : "display",
      ...e.editorKind === "fallback" ? { editorKind: "fallback" } : e.editorKind ? { editorKind: "canvas-core" } : {}
    };
  } catch {
    return { mathml: "", latexExport: "", pasteMode: "display" };
  }
}
function l1(r) {
  try {
    sessionStorage.setItem(pn, JSON.stringify(r));
  } catch {
  }
}
async function u1(r, e = "image/png") {
  if (!navigator.clipboard?.write || typeof ClipboardItem > "u")
    return !1;
  try {
    return await navigator.clipboard.write([new ClipboardItem({ [e]: r })]), !0;
  } catch {
    return !1;
  }
}
async function Nt(r, e) {
  const t = Hs(r, e);
  for (const a of t)
    if (await u1(a.blob, a.mimeType))
      return { copied: !0, mimeType: a.mimeType };
  return { copied: !1 };
}
class c1 {
  resolveTargetRef;
  frameOrigin;
  frameUrl;
  boundFrameMessageHandler;
  root = null;
  frame = null;
  frameReady = !1;
  pendingFrameReady = null;
  pendingOperationAcks = /* @__PURE__ */ new Map();
  pendingStateResponses = /* @__PURE__ */ new Map();
  pendingExportResponses = /* @__PURE__ */ new Map();
  currentBootId;
  lastFrameEvent;
  lastInsertRequestId;
  lastInsertDispatch;
  lastOpenNoopReuse = !1;
  pasteMode = "display";
  exportFormat = "latex";
  lastFeedback = "";
  mathml = "";
  latexExport = "";
  editorKind;
  directEditing;
  editorDiagnostics;
  lastResolvedTarget = null;
  savedSelectionSnapshot = null;
  constructor(e) {
    this.resolveTargetRef = e, this.frameOrigin = new URL(chrome.runtime.getURL("")).origin, this.frameUrl = chrome.runtime.getURL(a1);
    const t = o1();
    this.mathml = t.mathml, this.latexExport = t.latexExport, this.pasteMode = t.pasteMode, this.editorKind = t.editorKind, this.boundFrameMessageHandler = (a) => {
      this.handleFrameMessage(a);
    }, window.addEventListener("message", this.boundFrameMessageHandler);
  }
  buildFrameUrl() {
    const e = typeof crypto < "u" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
    this.currentBootId = e;
    const t = new URL(this.frameUrl);
    return t.searchParams.set(n1, e), t.toString();
  }
  isCanvasFrameUrl(e) {
    if (!e)
      return !1;
    try {
      const t = new URL(e), a = new URL(this.frameUrl);
      return t.origin === a.origin && t.pathname === a.pathname;
    } catch {
      return !1;
    }
  }
  async open() {
    return this.root?.dataset.open === "true" && this.frameReady && this.currentBootId && this.frame?.contentWindow ? (this.lastOpenNoopReuse = !0, { ok: !0, state: this.getCanvasState() }) : (this.lastOpenNoopReuse = !1, this.captureResolvedTarget(), await this.ensureMounted(), await this.ensureFrameReady(), this.root ? (this.root.dataset.open = "true", (!this.lastFeedback || this.lastFeedback === "Canvas closed.") && this.syncFeedbackToFrame("Canvas ready."), { ok: !0, state: this.getCanvasState() }) : { ok: !1, reason: "Failed to initialize Canvas dock." });
  }
  close() {
    return this.root && (this.root.dataset.open = "false"), this.setFeedback("Canvas closed."), this.postMessageToFrame({ type: P.CLOSE }), { ok: !0, state: this.getCanvasState() };
  }
  async getState() {
    return await this.ensureMounted(), await this.ensureFrameReady(), await this.refreshStateFromFrame(), { ok: !0, state: this.getCanvasState() };
  }
  async insertSymbol(e) {
    const t = await this.open();
    if (!t.ok)
      return t;
    await this.refreshStateFromFrame();
    const a = Os(e);
    if (a) {
      const l = await this.dispatchOperation(a, "apply-operation");
      return this.applyFrameSnapshot(l), this.syncFeedbackToFrame(`Added ${e.label} to Canvas.`), { ok: !0, state: this.getCanvasState() };
    }
    const n = Ls(e);
    if (n) {
      const l = await this.dispatchOperation(
        {
          type: "replace-selection",
          content: n
        },
        "replace-selection"
      );
      return this.applyFrameSnapshot(l), this.syncFeedbackToFrame(`Added ${e.label} to Canvas.`), { ok: !0, state: this.getCanvasState() };
    }
    const i = `Canvas could not insert ${e.label} structurally yet.`;
    return this.lastInsertDispatch = "failed", this.syncFeedbackToFrame(i), { ok: !1, reason: i, state: this.getCanvasState() };
  }
  async setMathml(e) {
    const t = await this.open();
    if (!t.ok)
      return t;
    const a = this.createRequestId("set-mathml");
    this.mathml = e;
    const n = zs(e);
    this.latexExport = n.ok ? n.value : this.latexExport, this.persistSession();
    const i = await this.dispatchMessageForAck({
      type: P.SET_MATHML,
      payload: { requestId: a, mathml: e }
    });
    return this.applyFrameSnapshot(i), this.syncFeedbackToFrame("Loaded MathML into Canvas."), { ok: !0, state: this.getCanvasState() };
  }
  async importLatex(e) {
    const t = await this.open();
    if (!t.ok)
      return t;
    const a = this.createRequestId("import-latex"), n = await this.dispatchMessageForAck({
      type: P.IMPORT_LATEX,
      payload: { requestId: a, latex: e }
    });
    return this.applyFrameSnapshot(n), this.syncFeedbackToFrame("Imported LaTeX into Canvas."), { ok: !0, state: this.getCanvasState() };
  }
  async importMathml(e) {
    const t = await this.open();
    if (!t.ok)
      return t;
    const a = this.createRequestId("import-mathml"), n = await this.dispatchMessageForAck({
      type: P.IMPORT_MATHML,
      payload: { requestId: a, mathml: e }
    });
    return this.applyFrameSnapshot(n), this.syncFeedbackToFrame("Imported MathML into Canvas."), { ok: !0, state: this.getCanvasState() };
  }
  async pasteLatex() {
    const e = this.latexExport.trim();
    if (!e) {
      const u = "Canvas has no LaTeX export.";
      return this.syncFeedbackToFrame(u), { ok: !1, reason: u, state: this.getCanvasState() };
    }
    const { target: t, context: a, selectionSnapshot: n } = this.resolveInsertTarget();
    if (!t) {
      const u = "Focus an editable field before using Paste LaTeX.";
      return this.syncFeedbackToFrame(u), { ok: !1, reason: u, state: this.getCanvasState() };
    }
    this.savedSelectionSnapshot = sa(
      n ?? this.savedSelectionSnapshot,
      t,
      window.getSelection()
    );
    const i = r1(a.inMathEditor, this.pasteMode);
    if (!a.inMathEditor && a.host === "notion" && this.pasteMode === "display") {
      const u = await Js(
        t,
        () => {
          const h = this.resolveInsertTarget();
          return {
            target: h.target,
            context: h.context
          };
        },
        this.savedSelectionSnapshot
      );
      if (!u.ok) {
        const h = u.reason;
        return this.syncFeedbackToFrame(h), { ok: !1, reason: h, state: this.getCanvasState() };
      }
      return await la(e, "raw", u.target, u.context), this.savedSelectionSnapshot = null, this.exportFormat = "latex", this.syncFeedbackToFrame("Pasted LaTeX into block equation."), { ok: !0, state: this.getCanvasState() };
    }
    const l = await la(e, i, t, a);
    if (!l.ok) {
      const u = l.error ?? "Failed to paste LaTeX.";
      return this.syncFeedbackToFrame(u), { ok: !1, reason: u, state: this.getCanvasState() };
    }
    return this.exportFormat = "latex", this.syncFeedbackToFrame(i === "raw" ? "Pasted raw LaTeX into math editor." : "Pasted LaTeX into focused editor."), { ok: !0, state: this.getCanvasState() };
  }
  async pasteMathml() {
    const e = this.mathml.trim();
    if (!e) {
      const i = "Canvas has no MathML content.";
      return this.syncFeedbackToFrame(i), { ok: !1, reason: i, state: this.getCanvasState() };
    }
    const { target: t, context: a } = this.resolveInsertTarget();
    if (!t) {
      const i = "Focus an editable field before using Paste MathML.";
      return this.syncFeedbackToFrame(i), { ok: !1, reason: i, state: this.getCanvasState() };
    }
    const n = await _s(e, t, a);
    if (!n.ok) {
      const i = n.error ?? "Failed to paste MathML.";
      return this.syncFeedbackToFrame(i), { ok: !1, reason: i, state: this.getCanvasState() };
    }
    return this.exportFormat = "mathml", this.syncFeedbackToFrame("Pasted MathML into focused editor."), { ok: !0, state: this.getCanvasState() };
  }
  async pasteImagePng() {
    try {
      await this.ensureMounted(), await this.ensureFrameReady();
      const e = await this.requestFrameExport("image-png", !0), t = await Nt("image-png", e), { target: a, context: n } = this.resolveInsertTarget();
      if (a && e.pngDataUrl ? ha(e.pngDataUrl, a, n).ok : !1)
        return this.exportFormat = "image-png", this.syncFeedbackToFrame("Pasted PNG into focused editor."), {
          ok: !0,
          insertedDirectly: !0,
          copiedToClipboard: t.copied,
          state: this.getCanvasState()
        };
      if (t.copied)
        return this.exportFormat = "image-png", this.syncFeedbackToFrame("PNG copied. Press Cmd/Ctrl+V."), {
          ok: !0,
          insertedDirectly: !1,
          copiedToClipboard: !0,
          fallbackPasteHint: !0,
          state: this.getCanvasState()
        };
      const l = "Could not paste image directly or copy PNG to clipboard.";
      return this.syncFeedbackToFrame(l), {
        ok: !1,
        reason: l,
        insertedDirectly: !1,
        copiedToClipboard: !1,
        state: this.getCanvasState()
      };
    } catch (e) {
      const t = e instanceof Error ? e.message : "Failed to render PNG.";
      return this.syncFeedbackToFrame(t), { ok: !1, reason: t, state: this.getCanvasState() };
    }
  }
  async copyImagePngToClipboard() {
    try {
      await this.ensureMounted(), await this.ensureFrameReady();
      const e = await this.requestFrameExport("image-png", !0);
      if ((await Nt("image-png", e)).copied)
        return this.exportFormat = "image-png", this.syncFeedbackToFrame("PNG copied. Press Cmd/Ctrl+V."), {
          ok: !0,
          insertedDirectly: !1,
          copiedToClipboard: !0,
          fallbackPasteHint: !0,
          state: this.getCanvasState()
        };
      const a = "Could not copy PNG to clipboard.";
      return this.syncFeedbackToFrame(a), {
        ok: !1,
        reason: a,
        insertedDirectly: !1,
        copiedToClipboard: !1,
        state: this.getCanvasState()
      };
    } catch (e) {
      const t = e instanceof Error ? e.message : "Failed to render PNG.";
      return this.syncFeedbackToFrame(t), { ok: !1, reason: t, state: this.getCanvasState() };
    }
  }
  async pasteImageSvg() {
    try {
      await this.ensureMounted(), await this.ensureFrameReady();
      const { target: e, context: t } = this.resolveInsertTarget(), a = !!e, n = !un(), i = await this.requestFrameExport("image-svg", !1), l = a || n ? await this.requestFrameExport("image-png", !0) : void 0, u = {
        ...i,
        ...l ?? {}
      }, h = await Nt("image-svg", u);
      if (e && u.pngDataUrl ? ha(u.pngDataUrl, e, t).ok : !1)
        return this.exportFormat = "image-svg", this.syncFeedbackToFrame("Pasted SVG export into focused editor."), {
          ok: !0,
          insertedDirectly: !0,
          copiedToClipboard: h.copied,
          state: this.getCanvasState()
        };
      if (h.copied)
        return this.exportFormat = "image-svg", this.syncFeedbackToFrame(
          h.mimeType === "image/svg+xml" ? "SVG copied. Press Cmd/Ctrl+V." : "SVG copied as PNG for compatibility. Press Cmd/Ctrl+V."
        ), {
          ok: !0,
          insertedDirectly: !1,
          copiedToClipboard: !0,
          fallbackPasteHint: !0,
          state: this.getCanvasState()
        };
      const v = "Could not copy SVG image or produce a PNG fallback.";
      return this.syncFeedbackToFrame(v), {
        ok: !1,
        reason: v,
        insertedDirectly: !1,
        copiedToClipboard: !1,
        state: this.getCanvasState()
      };
    } catch (e) {
      const t = e instanceof Error ? e.message : "Failed to render SVG as image.";
      return this.syncFeedbackToFrame(t), { ok: !1, reason: t, state: this.getCanvasState() };
    }
  }
  async dispatchOperation(e, t) {
    const a = this.createRequestId(t);
    return this.lastInsertRequestId = a, this.lastInsertDispatch = t, this.dispatchMessageForAck({
      type: P.APPLY_OPERATION,
      payload: { requestId: a, operation: e }
    });
  }
  createRequestId(e) {
    return typeof crypto < "u" && "randomUUID" in crypto ? `${e}-${crypto.randomUUID()}` : `${e}-${Date.now()}-${Math.random()}`;
  }
  async dispatchMessageForAck(e, t = 2e3) {
    const a = e.payload?.requestId;
    return a ? new Promise((n, i) => {
      const l = window.setTimeout(() => {
        this.pendingOperationAcks.delete(a), i(new Error(`Canvas operation ack timed out for ${a}.`));
      }, t);
      this.pendingOperationAcks.set(a, {
        resolve: (u) => {
          window.clearTimeout(l), this.pendingOperationAcks.delete(a), n(u);
        },
        reject: (u) => {
          window.clearTimeout(l), this.pendingOperationAcks.delete(a), i(u);
        }
      }), this.postMessageToFrame(e);
    }) : (this.postMessageToFrame(e), this.getCanvasState());
  }
  async refreshStateFromFrame(e = 1200) {
    const t = this.createRequestId("request-state"), a = await new Promise((n, i) => {
      const l = window.setTimeout(() => {
        this.pendingStateResponses.delete(t), i(new Error(`Canvas state request timed out for ${t}.`));
      }, e);
      this.pendingStateResponses.set(t, {
        resolve: (u) => {
          window.clearTimeout(l), this.pendingStateResponses.delete(t), n(u);
        },
        reject: (u) => {
          window.clearTimeout(l), this.pendingStateResponses.delete(t), i(u);
        }
      }), this.postMessageToFrame({
        type: P.REQUEST_STATE,
        payload: { requestId: t }
      });
    });
    this.applyFrameSnapshot(a);
  }
  materializeFrameExportAssets(e) {
    if (e.error)
      throw new Error(e.error);
    const t = {};
    if (e.svgText && e.svgDataUrl && (t.svgText = e.svgText, t.svgDataUrl = e.svgDataUrl, t.svgBlob = new Blob([e.svgText], { type: "image/svg+xml" })), e.pngDataUrl && (t.pngDataUrl = e.pngDataUrl, t.pngBlob = Ps(e.pngDataUrl)), !t.svgDataUrl && !t.pngDataUrl)
      throw new Error("Canvas frame export returned no usable image asset.");
    return t;
  }
  async requestFrameExport(e, t, a = 2500) {
    const n = this.createRequestId(`export-${e}`);
    return new Promise((i, l) => {
      const u = window.setTimeout(() => {
        this.pendingExportResponses.delete(n), l(new Error(`Canvas export request timed out for ${n}.`));
      }, a);
      this.pendingExportResponses.set(n, {
        resolve: (h) => {
          window.clearTimeout(u), this.pendingExportResponses.delete(n), i(h);
        },
        reject: (h) => {
          window.clearTimeout(u), this.pendingExportResponses.delete(n), l(h);
        }
      }), this.postMessageToFrame({
        type: P.EXPORT_REQUEST,
        payload: {
          requestId: n,
          format: e,
          includePngFallback: t
        }
      });
    });
  }
  async ensureMounted() {
    if (s1(), !document.body)
      throw new Error("Failed to mount Canvas dock: missing document.body");
    const e = document.getElementById(k0), t = e ?? document.createElement("div");
    t.id = k0, t.dataset.open = t.dataset.open ?? "false";
    let a = t.querySelector(".canvas-dock-frame");
    a || (a = document.createElement("iframe"), a.className = "canvas-dock-frame", a.setAttribute("title", "KaTeX Canvas"), a.setAttribute("allow", "clipboard-read; clipboard-write"), t.replaceChildren(a)), this.frame = a, (!e || !this.isCanvasFrameUrl(a.src) || !this.frameReady || !a.contentWindow) && (this.frameReady = !1, this.lastFrameEvent = void 0, a.src = this.buildFrameUrl()), t.parentElement !== document.body && document.body.appendChild(t), this.root = t;
  }
  async ensureFrameReady(e = 2500) {
    if (!(this.frameReady && this.frame?.contentWindow)) {
      if (this.pendingFrameReady)
        return new Promise((t, a) => {
          const n = this.pendingFrameReady;
          if (!n) {
            t();
            return;
          }
          const i = n.resolve, l = n.reject;
          n.resolve = () => {
            i(), t();
          }, n.reject = (u) => {
            l(u), a(u);
          };
        });
      await new Promise((t, a) => {
        const n = window.setTimeout(() => {
          this.pendingFrameReady = null, a(new Error("Canvas frame did not finish booting in this tab."));
        }, e);
        this.pendingFrameReady = {
          resolve: () => {
            window.clearTimeout(n), this.pendingFrameReady = null, t();
          },
          reject: (i) => {
            window.clearTimeout(n), this.pendingFrameReady = null, a(i);
          }
        };
      });
    }
  }
  handleFrameMessage(e) {
    !this.frame || e.origin !== this.frameOrigin || e.source !== this.frame.contentWindow || xn(e.data) && this.processFrameMessage(e.data);
  }
  async processFrameMessage(e) {
    switch (e.type) {
      case P.READY:
        if (e.payload.bootId !== this.currentBootId)
          return;
        this.frameReady = !0, this.lastFrameEvent = "ready", this.pendingFrameReady?.resolve(), this.postMessageToFrame({
          type: P.INIT,
          payload: {
            ...this.getCanvasState(),
            bootId: this.currentBootId ?? "unknown",
            seed: !0
          }
        });
        return;
      case P.SNAPSHOT:
        this.lastFrameEvent = "snapshot", this.applyFrameSnapshot(e.payload);
        return;
      case P.STATE_RESPONSE:
        this.applyFrameSnapshot(e.payload.state), this.pendingStateResponses.get(e.payload.requestId)?.resolve(e.payload.state);
        return;
      case P.EXPORT_RESPONSE:
        try {
          const t = this.materializeFrameExportAssets(e.payload);
          this.pendingExportResponses.get(e.payload.requestId)?.resolve(t);
        } catch (t) {
          this.pendingExportResponses.get(e.payload.requestId)?.reject(t instanceof Error ? t : new Error("Canvas export failed."));
        }
        return;
      case P.OPERATION_APPLIED:
        this.lastFrameEvent = "operation-applied", this.pendingOperationAcks.get(e.payload.requestId)?.resolve(e.payload.state);
        return;
      case P.ACTION_PASTE_LATEX:
        await this.pasteLatex();
        return;
      case P.ACTION_PASTE_MATHML:
        await this.pasteMathml();
        return;
      case P.ACTION_COPY_IMAGE_PNG:
        await this.copyImagePngToClipboard();
        return;
      case P.ACTION_PASTE_IMAGE_PNG:
        await this.pasteImagePng();
        return;
      case P.ACTION_PASTE_IMAGE_SVG:
        await this.pasteImageSvg();
        return;
      case P.ACTION_CLEAR:
        this.mathml = "", this.latexExport = "", this.persistSession(), this.postMessageToFrame({ type: P.CLEAR }), this.syncFeedbackToFrame("Canvas cleared.");
        return;
      case P.ACTION_CLOSE:
        this.close();
        return;
      case P.RENDER_STATUS:
        this.lastFrameEvent = "render-status", this.editorKind = e.payload.editorKind, this.directEditing = e.payload.directEditing, this.editorDiagnostics = e.payload.editorDiagnostics, this.persistSession();
        return;
      default:
        return;
    }
  }
  captureResolvedTarget() {
    const e = this.resolveTargetRef.current();
    e.target?.isConnected && (this.lastResolvedTarget = {
      target: e.target,
      context: e.context
    }), this.savedSelectionSnapshot = sa(
      this.savedSelectionSnapshot,
      e.target,
      window.getSelection()
    );
  }
  resolveInsertTarget() {
    const e = this.resolveTargetRef.current();
    return e.target?.isConnected ? (this.lastResolvedTarget = {
      target: e.target,
      context: e.context
    }, e) : this.lastResolvedTarget?.target.isConnected ? this.lastResolvedTarget : e;
  }
  postMessageToFrame(e) {
    this.frame?.contentWindow && this.frame.contentWindow.postMessage(e, this.frameOrigin);
  }
  getCanvasState() {
    const e = {
      open: this.root?.dataset.open === "true",
      mathml: this.mathml,
      latexExport: this.latexExport,
      pasteMode: this.pasteMode,
      exportFormat: this.exportFormat,
      bootDiagnostics: {
        ...this.currentBootId ? { bootId: this.currentBootId } : {},
        ready: this.frameReady,
        openNoopReuse: this.lastOpenNoopReuse,
        ...this.lastFrameEvent ? { lastFrameEvent: this.lastFrameEvent } : {},
        ...this.lastInsertRequestId ? { lastInsertRequestId: this.lastInsertRequestId } : {},
        ...this.lastInsertDispatch ? { lastInsertDispatch: this.lastInsertDispatch } : {},
        ...this.resolveTargetRef.runtimeInstanceId ? { runtimeInstanceId: this.resolveTargetRef.runtimeInstanceId } : {}
      }
    };
    return this.lastFeedback && (e.lastFeedback = this.lastFeedback), this.editorKind && (e.editorKind = this.editorKind), typeof this.directEditing == "boolean" && (e.directEditing = this.directEditing), this.editorDiagnostics && (e.editorDiagnostics = this.editorDiagnostics), e;
  }
  setFeedback(e, t = !0) {
    this.lastFeedback = e, t && this.postMessageToFrame({
      type: P.SET_FEEDBACK,
      payload: { message: e }
    });
  }
  syncFeedbackToFrame(e) {
    this.setFeedback(e, !0);
  }
  applyFrameSnapshot(e) {
    this.mathml = e.mathml, this.latexExport = e.latexExport, this.pasteMode = e.pasteMode, this.exportFormat = e.exportFormat ?? this.exportFormat, this.editorKind = e.editorKind ?? this.editorKind, this.directEditing = typeof e.directEditing == "boolean" ? e.directEditing : this.directEditing, this.editorDiagnostics = e.editorDiagnostics ?? this.editorDiagnostics, e.lastFeedback && (this.lastFeedback = e.lastFeedback), e.bootDiagnostics?.lastFrameEvent && (this.lastFrameEvent = e.bootDiagnostics.lastFrameEvent), e.bootDiagnostics?.lastInsertRequestId && (this.lastInsertRequestId = e.bootDiagnostics.lastInsertRequestId), e.bootDiagnostics?.lastInsertDispatch && (this.lastInsertDispatch = e.bootDiagnostics.lastInsertDispatch), this.persistSession();
  }
  persistSession() {
    l1({
      mathml: this.mathml,
      latexExport: this.latexExport,
      pasteMode: this.pasteMode,
      ...this.editorKind ? { editorKind: this.editorKind } : {}
    });
  }
}
function h1() {
  return globalThis[jt];
}
function m1(r) {
  const e = globalThis;
  if (r) {
    e[jt] = r;
    return;
  }
  delete e[jt];
}
function d1(r, e) {
  const t = h1();
  if (t)
    return t.resolveTargetRef.current = r, e ? t.resolveTargetRef.runtimeInstanceId = e : delete t.resolveTargetRef.runtimeInstanceId, t.controller;
  const a = {
    current: r,
    ...e ? { runtimeInstanceId: e } : {}
  }, n = new c1(a);
  return m1({
    controller: n,
    resolveTargetRef: a
  }), n;
}
export {
  d1 as getCanvasDockController
};
